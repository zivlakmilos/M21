#include <iostream>
#include <algorithm>
#include <cmath>

#define MAXN 10005

int a[MAXN];
int b[MAXN];
int limits[MAXN];
int zbirb[MAXN];

int smart(int);
int bruteforce(int);

int main() {
    int n, sum=0;
    std::cin >> n;
    for(int i=0; i<n; i++)
        std::cin >> a[i];
    for(int i=0; i<n; i++)
        std::cin >> b[i];
    //if(n<=000) std::cout << bruteforce(n);
    //else std::cout << smart(n);
    std::cout << smart(n);
}

/**
 * <strikethrough>Ne radi... uglavnom</strikethrough>
 * RADIII ^_^
 * Ne smem ni da racunam koliko sam vremena potrosio na ovo
 * slozenost: O(2*(n log n)+n+2n+n) = O(n log n)
 */
int smart(int n) {
    int j=0, sum=0;
    std::sort(a, a+n); //O(n log n)
    std::sort(b, b+n); //O(n log n)
    zbirb[0]=0;
    for(int i=1; i<n+1; i++) {
        zbirb[i]=zbirb[i-1]+b[i-1];
    } //O(n)
    for(int i=0; i<n; i++) {
            for(; j<n /*never*/; j++) { //ok, ovde je mnogo pogodnije koristiti while
                if(a[i]<b[j]) {
                    limits[i]=j;
                    break;
                }
                if(j==n-1) {
                    limits[i]=n;
                    break;
                }
            }
    } //O(2n)
    for(int i=0; i<n; i++) { //O(n)
        //int zbira = a[i]*(2*(limits[i])-n);
        //int zbirb1, zbirb2;
        //zbirb2=zbirb[limits[i]];
        //zbirb1=zbirb[n]-zbirb2;
        sum+=std::abs(a[i]*(2*(limits[i])-n)+zbirb[n]-2*zbirb[limits[i]]); //fu
    }
    return sum;
}

/**
 * Za male primere
 *cisto kao podsecanje, dead code inace (gcc pls)
 */
int bruteforce(int n) {
    int sum=0;
    for(int i=0; i<n; i++) {
        for(int j=0; j<n; j++) {
            sum+=std::abs(a[i]-b[j]);
        }
    }
    return sum;
}
