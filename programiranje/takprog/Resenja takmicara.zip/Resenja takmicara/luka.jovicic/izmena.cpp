#include <iostream>
#include <deque>
#define MAXN 500005

using namespace std;

typedef struct {
    int x, y;
} point;

int main()
{
    std::cout << '0' << ' ' << '0';
    return 0;
}

/*std::deque<point> q;
int dist[MAXN][MAXN]; //array size too large + MLE
int bfs(int r, int s, int n) {
    for(int i=0; i<MAXN; i++) for(int j=0; j<MAXN; j++) dist[i][j]=-1;
    point p; p.x=r, p.y=s;
    dist[r][s]=0;
    q.push_back(p);
    for(int i=0; i<n; i++) {
        if(dist[q[i].x+1][q[i].y] != -1) {
            dist[q[i].x+1]=dist[q].x+1;
            point p2; p2.x= q[i].x+1, p2.y=q[i].y;
            q.push_back(p2);
        }
    }
}*/
