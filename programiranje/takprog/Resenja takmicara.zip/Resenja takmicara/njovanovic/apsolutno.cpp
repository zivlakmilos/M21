#include <stdio.h>
#include <algorithm>

using namespace std;

int n, a[100005], b[100005], curInd;
long long s=0, bSum[100005], aSum[100005], c;

bool sorF(int a, int b){
    if (a>b) return true;
    return false;
}

int main()
{
    scanf ("%d", &n);
    for (int i=0; i<n; i++) scanf ("%d", &a[i]);
    for (int i=0; i<n; i++) scanf ("%d", &b[i]);
    sort(a, a+n, sorF);
    sort(b, b+n, sorF);
    c=0;
    for (int i=n-1; i>=0; i--){
        bSum[i] = c + b[i];
        c = bSum[i];
    }
    c=0;
    for (int i=n-1; i>=0; i--){
        aSum[i] = c + a[i];
        c = aSum[i];
    }
    curInd=0;
    for (int i=0; i<n; i++){
        while (b[curInd] >= a[i]) curInd++;
        s = s + a[i]*(n-curInd) - bSum[curInd];
    }
    curInd=0;
    for (int i=0; i<n; i++){
        while (a[curInd] > b[i]) curInd++;
        s = s + b[i]*(n-curInd) - aSum[curInd];
    }
    printf ("%lld", s);
    return 0;
}
