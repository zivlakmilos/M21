#include <stdio.h>

long long n, m, k, trag[1005][3], maxi, maxj, maxD, curD, curDmin, dx, dy;

int main()
{
    scanf ("%lld %lld %lld", &n, &m, &k);
    for (int i=0; i<k; i++){
        scanf ("%lld %lld %lld", &trag[i][0], &trag[i][1], &trag[i][2]);
        trag[i][0]--;
        trag[i][1]--;
    }
    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            dx = i - trag[0][0]; if (dx<0) dx*=-1;
            dy = j - trag[0][1]; if (dy<0) dy*=-1;
            curDmin = (dx+dy)/trag[0][2];
            if ((dx+dy)%trag[0][2] > 0) curDmin++;
            for (int l=1; l<k; l++){
                dx = i - trag[l][0]; if (dx<0) dx*=-1;
                dy = j - trag[l][1]; if (dy<0) dy*=-1;
                curD = (dx+dy)/trag[l][2];
                if ((dx+dy)%trag[l][2] > 0) curD++;
                if (curD < curDmin) curDmin = curD;
            }
            if (curDmin > maxD){
                maxD = curDmin;
                maxi = i;
                maxj = j;
            }
        }
    }
    printf ("%lld %lld", maxi+1, maxj+1);
    return 0;
}
