#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <cstdio>

using namespace std;

int main()
{
    int n,m,k, x[1020], y[1020],raz1,raz2,raz3,raz4,max1,max2,max3,max4,a;
    long int v[1020];
    scanf("%d", &n);
    scanf("%d", &m);
    scanf("%d", &k);
    max1=0;
    max2=0;
    max3=0;
    max4=0;
    a=1;
    for (int i=1;i<=k;i++)
    {
        scanf("%d", &x[i]);
        scanf("%d", &y[i]);
        scanf("%ld", &v[i]);
    }
    for (int i=1;i<=k;i++)
    {
        raz1=n-x[i];
        raz2=x[i]-1;
        raz1=abs(raz1);
        raz2=abs(raz2);
        raz3=m-y[i];
        raz4=y[i]-1;
        raz3=abs(raz3);
        raz4=abs(raz4);

        if (raz1>max1)
            max1=raz1;
        if (raz2>max2)
            max2=raz2;
        if (raz3>max3)
            max3=raz3;
        if (raz4>max4)
            max4=raz4;


    }
    if (max1>=max2 && max3>=max4)
        {
            cout <<n <<' ' <<m;
        }
    if (max2>max1 && max4>max3)
    {
        cout <<a <<' ' <<a;
    }
    if (max1>=max2 && max4>=max3)
        cout <<n <<' ' <<a;
    if (max2>max1 && max3>max4)
        cout <<a <<' ' <<m;
    return 0;
}
