#include <iostream>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <cstdio>

using namespace std;

int main()
{
    long int n, a[100020], b[100020],c[100020],raz,br;
    long long sum;
    scanf("%ld",&n);
    br=0;
    for (int i=1;i<=n;i++)
        scanf("%ld",&a[i]);
    for (int i=1;i<=n;i++)
        scanf("%ld", &b[i]);
    sum=0;

      for (int i=1;i<=n;i++)
    {
        raz=a[i]-b[i];
        raz=abs(raz);
        sum=sum+raz;
    }

    for (int k=1;k<=n-1;k++)
    {
    br=0;
    int j=0;
    for (int i=n-j;i<=n;i++)
    {
        br++;
        for (j=1;j<=br;j++)
            c[j]=a[i];
        for (j=br+1;j<=n;j++)
            c[j]=a[j-br];

    }

    for (int i=1;i<=n;i++)
    {
        raz=c[i]-b[i];
        raz=abs(raz);
        sum=sum+raz;
    }
    for (int i=1;i<=n;i++)
        a[i]=c[i];
    }

    printf("%lld", sum);

    return 0;
}
