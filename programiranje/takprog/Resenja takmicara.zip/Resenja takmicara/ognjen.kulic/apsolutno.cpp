#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;

long n;
long long int r,a[100005],b[100005];

int main() {
 scanf("%d", &n);
 for (long i=1; i<=n; i++) {
  scanf("%lld", &a[i]);
  }
  r=0ll;
 for (long i=1; i<=n; i++) {
  scanf("%lld", &b[i]);
  for(long j=1; j<=n; j++) {
   r=r+abs(a[j]-b[i]);
   }
  }
 printf("%lld\n", r);
 return 0;
}
