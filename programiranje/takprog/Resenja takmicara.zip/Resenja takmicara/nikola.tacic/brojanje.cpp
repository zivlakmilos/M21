#include <cstdio>
#include <cstdlib>
#define x 1000000007

using namespace std;

    int a[1000005];
    int niz[1000005];
    int ld[1000005][5];

int main()
{
    int j,n,i,q,l,d,s;


    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",a+i);

    scanf("%d",&q);
    for(int i=1;i<=q;i++)
       scanf("%d",niz+i);

  for(i=1;i<=n;i++){
        j=i; l=-1; d=-1;
        while(a[j]<=a[i] && j<=n){
            d++;j++;}
        j=i;
        while(a[j]<=a[i] && j>=1){
            l++;j--;}
        ld[i][1]=a[i]; ld[i][2]=l; ld[i][3]=d;
    }
    for(i=1;i<=n;i++)
        printf("%d %d %d\n",ld[i][1],ld[i][2],ld[i][3]);
    for(i=1;i<=q;i++){
        s=0;
        for(j=1;j<=n;j++)
            if(ld[j][1]==niz[i])
                s=(s+1+ld[j][2]+ld[j][3]+ld[j][2]*ld[j][3])%x;
    printf("%d%c",s,'\n');
    }
    return 0;
}
