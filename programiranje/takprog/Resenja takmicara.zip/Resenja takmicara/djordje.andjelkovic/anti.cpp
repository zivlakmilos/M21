#include<cstdio>
#include<algorithm>
#include<queue>
#include<vector>
using namespace std;
int n,m,k;
vector<vector<int> >map;
struct tragac
{
	int brzina;
	int x, y;
};
bool kako(tragac x,tragac y)
{
	return x.brzina>y.brzina;
}
int nizX[4]={0,0,-1,1};
int nizY[4]={-1,1,0,0};
const int INF=2000000000;
tragac c[1000];
int main()
{
	int res=-1,solX,solY;
	scanf("%d%d%d",&n,&m,&k);
	vector<int>uzmi(m,INF);
	map.insert(map.begin(),n,uzmi);

	for(int i=0;i<k;i++)
	{
		scanf("%d%d%d",&c[i].y,&c[i].x,&c[i].brzina);
	}
	sort(c,c+k,kako);
	queue<int>bfs;
	for(int i=0;i<k;i++)
	{
		bfs.push(c[i].x);
		bfs.push(c[i].y);
		bfs.push(0);
		while(!bfs.empty())
		{
			int x=bfs.front();bfs.pop();
			int y=bfs.front();bfs.pop();
			int pot=bfs.front();bfs.pop();
			if((pot-1)/c[i].brzina+1<=map[y-1][x-1]||pot==0)
			{
				if(pot!=0)
					map[y-1][x-1]=(pot-1)/c[i].brzina+1;
				if(pot==0)
					map[y-1][x-1]=0;

				for(int j=0;j<4;j++)
				{
					if(y+nizY[j]-1>=0&&y+nizY[j]-1<n&&
					   x+nizX[j]-1>=0&&x+nizX[j]-1<m)
					{
						bfs.push(x+nizX[j]);
						bfs.push(y+nizY[j]);
						bfs.push(pot+1);
					}
				}
			}

		}
	}
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
				if(map[i][j]>res)
				{
					res=map[i][j];
					solX=j+1;
					solY=i+1;
				}
		}
	}
	printf("%d %d\n",solY,solX);
	return 0;
}