#include<iostream>
#include<algorithm>
#include<string>
#include<cmath>
using namespace std;
int n,x,y;
string str1;
int main()
{
	ios::sync_with_stdio(false);
	cin>>n>>x>>y;
	cin>>str1;
	int rx=0,ry=0,dist=2000000000;
	int tx=0,ty=0,tiy=0,tix=0;
	int tirx=0,tiry=0;
	for(int i=0;i<n;i++)
	{
		if(abs(tx-x)+abs(ty-y)<dist)
		{
			tirx=tix;
			tiry=tiy;
			rx=tx;
			ry=ty;
			dist=abs(tx-x)+abs(ty-y);
		}
		switch(str1[i])
		{
			case 'U':if(ty>=y){tiy++;}ty++;break;
			case 'D':if(ty<=y){tiy--;}ty--;break;
			case 'L':if(tx<=x){tix--;}tx--;break;
			case 'R':if(tx>=x){tix++;}tx++;break;
		}
	}
	tirx=abs(tirx);
	tiry=abs(tiry);
	tix=abs(tix);
	tiy=abs(tiy);
	if(tirx+tiry==0)
	{
		printf("%d ",dist);
	}
	else
	{
		if(rx-x==0&&ry-y>0)
		{
			printf("%d ",dist-tiry*2+tiry);
		}
		else if(ry-y==0&&rx-x>0)
		{
			printf("%d ",dist-tirx*2+tirx);
		}
		else
		{
			if(abs(rx-x)%2==0&&abs(ry-y)%2==0)
			{
				printf("%d ",(abs(rx-x)/2)+abs(ry-y)/2);
			}
			else
			{
				printf("%d ",(abs(rx-x)+abs(ry-y))/2+1);
			}
		}
	}

	dist=abs(tx-x)+abs(ty-y);
	if(tix+tiy==0)
	{
		printf("%d\n",dist);
	}
	else
	{
		if(tx-x==0&&ty-y>0)
		{
			printf("%d\n",dist-tiy*2+tiy);
		}
		else if(ty-y==0&&tx-x>0)
		{
			printf("%d\n",dist-tix*2+tix);
		}
		else
		{
			if(abs(tx-x)%2==0&&abs(ty-y)%2==0)
			{
				printf("%d\n",(abs(tx-x)/2)+abs(ty-y)/2);
			}
			else
			{
				printf("%d\n",(abs(tx-x)+abs(ty-y))/2+1);
			}
		}
	}
	return 0;
}