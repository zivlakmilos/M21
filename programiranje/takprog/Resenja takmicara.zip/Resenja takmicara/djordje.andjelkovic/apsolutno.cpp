#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int a[100000];
int b[100000];
long long zb[100000];
int n;
int main()
{
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n;i++)
	{
		scanf("%d",&b[i]);
	}
	sort(a,a+n);
	sort(b,b+n);
	for(int i=0;i<n;i++)
	{
		if(i>0)
			zb[i]=zb[i-1]+a[i];
		else
			zb[i]=a[i];
	}
	int ai=0;
	long long sol=0;
	for(int bi=0;bi<n;bi++)
	{
		long long deo1=0;
		long long deo2=0;
		while(b[bi]>a[ai]&&ai<n)
			ai++;
		if(ai<n)
		{
			deo2=deo2+zb[n-1];
			if(ai>0)
			{
				deo2=deo2-zb[ai-1];
			}
			deo2=deo2-(n-ai)*b[bi];
		}
		if(ai>0)
		{
			deo1=zb[ai-1];
			deo1=deo1-ai*b[bi];
		}
		sol=sol+abs(deo1-deo2);
	}
	printf("%lld\n",sol);
	return 0;
}