#include <iostream>
#include <stdlib.h>
#include <stdio.h>

using namespace std;

int main()
{
    long long N,r,s,s1,r1;
    scanf("%lld %lld %lld",&N,&r,&s);
    char Q[N+1];
    for(int i=0;i<N;i++)
        cin>>Q[i];
    long long A,B,tmpA;
    A=N+1;

    long long cU,cD,cL,cR;
    cU=cD=cL=cR=0;
    for(int i=0;i<N;i++){
        if (Q[i]=='U')
            cU++;
        if (Q[i]=='D')
            cD++;
        if (Q[i]=='R')
            cR++;
        if (Q[i]=='L')
            cL++;}
    r1=cR-cL;
    s1=cU-cD;
    B=(abs(s1-s))/2+(abs(r1-r))/2;

    for(int N2=1;N2<=N;N2++){
        cU=cD=cL=cR=0;
        if(N%2!=N2%2) continue;
        for(int i=0;i<N2;i++){

        if (Q[i]=='U')
            cU++;
        if (Q[i]=='D')
            cD++;
        if (Q[i]=='R')
            cR++;
        if (Q[i]=='L')
            cL++;}
        r1=cR-cL;
        s1=cU-cD;
        tmpA=(abs(s1-s))/2+(abs(r1-r))/2;
        if(A>tmpA)
            A=tmpA;
    };
    printf("%lld %lld",A,B);

    return 0;
}
