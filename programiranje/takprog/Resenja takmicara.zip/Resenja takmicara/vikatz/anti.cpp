#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <queue>

using namespace std;


int main()
{
    int N,M,K;
    scanf("%i %i %i",&N,&M,&K);
    long long speed[K];
    int traX[K],traY[K];
    for(int i=0;i<K;i++){
        scanf("%i %i %lld",&traX[i],&traY[i],&speed[i]);
    };


    long long krajnja[N][M];

    for(int i=0;i<N;i++)
        for(int j=0;j<M;j++)
            krajnja[i][j]=1000001;

    long long najveci=0;
    long long tragac[N][M];
    int finalX,finalY;

    queue<int> qx,qy;
    int i,j;
    long long potez,broj;
    int pot2;

    for(int traBr=0;traBr<K;traBr++){

        for(int i=0;i<N;i++)
            for(int j=0;j<M;j++)
                tragac[i][j]=0;

        tragac[traX[traBr]-1][traY[traBr]-1]=-1;
        qx.push(traX[traBr]-1);
        qy.push(traY[traBr]-1);
        potez=1;
        broj=1;
        while(!qx.empty()){
            i=qx.front();
            j=qy.front();
            qx.pop();
            qy.pop();

            if((i<N-1)&&(tragac[i+1][j]==0)){
                tragac[i+1][j]=tragac[i][j]+broj;
                qx.push(i+1);
                qy.push(j);
            };
            if((j<M-1)&&(tragac[i][j+1]==0)){
                tragac[i][j+1]=tragac[i][j]+broj;
                qx.push(i);
                qy.push(j+1);
            };
            if((i>0)&&(tragac[i-1][j]==0)){
                tragac[i-1][j]=tragac[i][j]+broj;
                qx.push(i-1);
                qy.push(j);
            };
            if((j>0)&&(tragac[i][j-1]==0)){
                tragac[i][j-1]=tragac[i][j]+broj;
                qx.push(i);
                qy.push(j-1);
            };
            potez++;
            if(potez%speed[traBr]==0)
                broj++;


        };

        for(int k=0;k<N;k++)
            for(int l=0;l<M;l++)
                krajnja[k][l]=min(krajnja[k][l],tragac[k][l]);
    };


    for(int k=0;k<N;k++)
        for(int l=0;l<M;l++)
            if(krajnja[k][l]>najveci){
                najveci=krajnja[k][l];
                finalX=k;
                finalY=l;
            };
    printf("%i %i",finalX+1,finalY+1);

    return 0;
}



