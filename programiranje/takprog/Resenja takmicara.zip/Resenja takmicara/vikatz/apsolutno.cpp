#include <iostream>
#include <stdlib.h>
#include <stdio.h>



using namespace std;


void zameni(long long niz[],long long i,long long j){
    long long tmp=niz[i];
    niz[i]=niz[j];
    niz[j]=tmp;
}


void pomeri(long long niz[],long long d){
    for(long long i=d-2; i>=0; i--){
        zameni(niz,i,i+1);
    };
}




int main()
{
    long long SSS=0;
    long long N;
    scanf("%lld",&N);
    long long A[N],B[N];
    for(long long i=0;i<N;i++){
        cin>>A[i];
    };

    for(long long i=0;i<N;i++){
        cin>>B[i];
    };


    for (long long sl=0;sl<N;sl++){
        for(int i=0;i<N;i++){
            SSS+=abs(A[i]-B[i]);
        };
        pomeri(A,N);
    };

    printf("%lld",SSS);

    return 0;
}
