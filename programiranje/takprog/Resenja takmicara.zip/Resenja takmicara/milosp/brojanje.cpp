#include <cstdio>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

struct vek {
    vector <int> pos;
};

struct par {
	int val;
	int pos;
};

bool cmp(par x, par y) {
    return (x.val > y.val);
}

int n, x, numSing, l, r, heapSize, q, mid;
int a[1000005];
int s[1000005];
int b[1000005];
int sleva[1000005];
int zdesna[1000005];
int sol[1000005];
par heap[1000005];
//bool o[1000005];
vector <vek> vekvek;
vek v;
int maks, minn;
map <int, int> mapa;
par p;

bool bin(int x) {
    l = 0;
    r = numSing;
/*
    if ((s[l] > x) || (s[r] < x)) {
        return false;
    }
*/
    while (l < r) {
        mid = (l + r)/2;
        if (s[mid] < x) {
            l = mid;
        }
        else if (s[mid] > x) {
            r = mid;
        }
        else {
            return true;
        }
    }
    return false;
}

int main() {
    scanf("%d", &n);

	numSing = 0;
    /*for (int i = 0; i < n; i++) {
        o[i] = false;
    }*/

    for (int i = 0; i < n; i++) {
        scanf("%d", a+i);

        b[i] = a[i];
    }

    sort(b, b+n);

	s[0] = b[0];
	numSing = 1;
    for (int i = 1; i < n; i++) {
        if (b[i-1] != b[i]) {
			s[numSing] = b[i];
			numSing++;
		}
    }

	for (int i = 0; i < numSing; i++) {
		printf("%d ", s[i]);
		mapa[s[i]] = i;
		vekvek.push_back(v);
	}

	for (int i = 0; i < n; i++) {
		vekvek[mapa[a[i]]].pos.push_back(i);
	}

	heapSize = 0;
	for (int i = 0; i < n; i++) {
		while ((heap[0].val < a[i]) && (heapSize > 0)) {
			pop_heap(heap, heap + heapSize, cmp);
			heapSize--;
		}
		p.val = a[i];
		p.pos = i;

		if (heapSize > 0) {
			sleva[i] = i - heap[0].pos;
		}
		else {
			sleva[i] = i+1;
		}

		heap[heapSize] = p;
		heapSize++;
		push_heap(heap, heap + heapSize, cmp);
	}


	heapSize = 0;
	for (int i = n-1; i >= 0; i--) {
		while ((heap[0].val < a[i]) && (heapSize > 0)) {
			pop_heap(heap, heap + heapSize, cmp);
			heapSize--;
		}
		p.val = a[i];
		p.pos = i;

		if (heapSize > 0) {
			zdesna[i] = heap[0].pos - i;
		}
		else {
			zdesna[i] = n-i;
		}

		heap[heapSize] = p;
		heapSize++;
		push_heap(heap, heap + heapSize, cmp);
	}

	for (int i = 0; i < numSing; i++) {
		for (int j = 0; j < vekvek[i].pos.size(); j++) {
			//printf("%d ", vekvek[i].pos[j]);
			sol[mapa[s[i]]] += sleva[vekvek[i].pos[j]]*zdesna[vekvek[i].pos[j]];
		}
//		printf("%d ", sol[i]);
	}

	scanf("%d", &q);

    //printf("\n");

	for (int i = 0; i < q; i++) {
        scanf("%d", &x);
        //if (bin(x)) {
            printf("%d\n", sol[mapa[x]]);
        //}
        /*else {
            printf("%d\n", 0);
        }*/
	}


    return 0;
}

