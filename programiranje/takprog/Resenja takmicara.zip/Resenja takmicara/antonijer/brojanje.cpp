#include <stdio.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cstring>

int N;
int Q;
int A[1000001];
int Al[1000001];
int Ad[1000001];

using namespace std;

int nadji_levi(int i)
{
    int s=i;
    for(int i1=i-1;i1>=0;)
    {
            if(A[i]>A[i1])
              {
              s=Al[i1];
              i1=s-1;
              }
            else
              {
              Al[i]=s;
              return 0;
              }
    }
    Al[i]=s;
    return 0;
}
int nadji_desni(int i)
{
    int s=i;
    for(int i1=0;i1<N;)
    {
            if(A[i]>A[i1])
              {
              s=Ad[i1];
              i1=s-1;
              }
            else
              {
              Ad[i]=s;
              return 0;
              }
    }
    Ad[i]=s;
    return 0;
}

int cigla(int i,int k)
{
    int s=0;
    int levo=i-Al[i];
    int desno=Ad[i]-i;
//    printf("Desno=%d Levo=%d\n",desno,levo);
    int j=i;
    while(Ad[Ad[j]+1]==k)
    {
                        
                       desno=Ad[Ad[j]+1]-i;
                          // printf("Desno=%d Levo=%d\n",desno,levo);
                       j=Ad[Ad[j]+1];
    }
    s=(levo+1)*(desno+1); 
    return s;
}

int main()
{
    scanf("%d",&N);
    for(int i=0;i<N;i++)//Znazslji ovaj for pozsljivaaa nadji_levi funkzsljiju;
    {
            scanf("%d",&A[i]);
            int razsljikaaa=nadji_levi(i);//<3 CIGLA;
    }
    for(int i=N-1;i>=0;i--)//Znazslji ovaj for pozsljivaaa nadji_levi funkzsljiju;
    {
            int razsljikaaa=nadji_desni(i);//<3 CIGLA;
    }
/*    for(int i=N-1;i>=0;i--)//Azsljiiii......iiiiii......iii glup szsljiii;
    {
            if(Ad[i]==0)
              Ad[i]=i;
            if(Ad[Al[i]-1]<i)
            Ad[Al[i]-1]=Ad[i];
              
    }
*/
    
    
    scanf("%d",&Q);
    for(int i5=0;i5<Q;i5++)
    {
            int k,s=0;
            scanf("%d",&k);
            for(int i=0;i<N;i++)
            {
                    if(A[i]==k)
                    s+=cigla(i,k);
            }
            printf("%d\n",s);
    }
    
    
    
    
    
//    for(int i=0;i<N;i++)
  //     printf("i=%d Al=%d Ad=%d\n",i,Al[i],Ad[i]);
    for(;;);
    return 0;
}
