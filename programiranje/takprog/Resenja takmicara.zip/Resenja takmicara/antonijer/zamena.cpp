#include <stdio.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cstring>

int N;
int A[100001];
int B[100001];
int Ai=0;

using namespace std;



int uporedi(int i, int j)
{
    int j1=10;
    for(int i1=0;i1<Ai;i1++)
    {
                        if((i/j1==j/j1)&&(i%(j1/10)==j%(j1/10)))
                          return (abs((i%j1)/(j1/10)-(j%j1)/(j1/10)));
                          j1=j1*10;
    }
    return 0;
}


int main()
{
    scanf("%d",&N);
    scanf("%d",&A[0]);
               int pom1=A[0];
               while(pom1!=0)
               {
                             pom1=pom1/10;
                             Ai++;
               }           
    for(int i=1;i<N;i++)
    {
                    scanf("%d",&A[i]);
    }
    //Kraj ucitavanja;
    for(int i=N-2;i>=0;i--)
    {
            for(int j=i+1;j<N;j++)
                       {
                                  int pom=uporedi(A[i],A[j]);
                                  if(pom!=0)
                                    if(pom+B[j]>B[i])
                                      B[i]=pom+B[j];
                       }
    }
    int max=0;
    for(int i=0;i<N;i++)
       if(B[i]>max)
         max=B[i];
    printf("%d",max);
    //Kraj if(N<=1000);


//    for(;;);
    return 0;
}
