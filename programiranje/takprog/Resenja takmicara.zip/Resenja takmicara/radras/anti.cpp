#include <cstdio>

using namespace std;

int abs(int a){
if(a<0) return -a;
else return a;
}

int tabla[1010][1010];

int main(){

int N, M, K, X[1010], Y[1010];
int V[1010];

scanf("%d %d %d", &N, &M, &K);

int i;

for(i=0;i<K;i++){scanf("%d %d %d", &X[i], &Y[i], &V[i]);
X[i]--;
Y[i]--;
}
int j, a, b, k, c;

for(j=0;j<N;j++){
    for(i=0;i<M;i++){
        if(j!=X[0]||i!=Y[0]){
                c=(abs(j-X[0])+abs(i-Y[0]));
                if(c<=V[0]){
                tabla[j][i]=1;
                }
                else{
                a=c/V[0];
                b=c%V[0];
                if(b==0){
                    tabla[j][i]=a;
                }
                else{
                    tabla[j][i]=a+1;
                }
                }
            }
        else{
            tabla[j][i]=0;
        }
    }
}



for(j=0;j<N;j++){
    for(i=0;i<M;i++){
        for(k=1;k<K;k++){
            if(tabla[j][i]!=0){
            if(j!=X[k]||i!=Y[k]){
                c=(abs(j-X[k])+abs(i-Y[k]));
                if(c<=V[k]){
                tabla[j][i]=1;
                }
                else{
                a=c/V[k];
                b=c%V[k];
                if(b==0){
                    if(tabla[j][i]>(a))tabla[j][i]=a;
                }
                else{
                    if(tabla[j][i]>(a+1))tabla[j][i]=a+1;
                }
                }
            }
            else tabla[j][i]=0;
        }
        }
    }
}

/*for(j=0;j<N;j++){
    for(i=0;i<M;i++){
        printf("%d ", tabla[j][i]);
    }
    printf("\n");
}*/

int p, q, m=1;


for(j=0;j<N;j++){
    for(i=0;i<M;i++){
        if(m<=tabla[j][i]){
            m=tabla[j][i];
            p=j;
            q=i;
        }
    }
}

printf("%d %d", p+1, q+1);

return 0;
}
