#include <cstdio>

using namespace std;

char q[500010];

int abs(int a){
if(a<0) return -a;
else return a;
}

int main(){

int N, i, r, s, x=0, y=0, A, B;

scanf("%d %d %d",&N, &r, &s);

scanf("%s", q);

int m=abs(r)+abs(s);
bool ok=false;

for(i=0;i<N;i++){
if(q[i]=='U')y++;
if(q[i]=='D')y--;
if(q[i]=='R')x++;
if(q[i]=='L')x--;
if(x==r&&y==s)ok=true;

if(m>(abs(r-x)+abs(s-y))){
    m=(abs(r-x)+abs(s-y));
}

}

B=(abs(x-r)+abs(y-s))/2;
if(ok)A=0;
else A=m/2+1;

printf("%d %d", A, B);

return 0;
}
