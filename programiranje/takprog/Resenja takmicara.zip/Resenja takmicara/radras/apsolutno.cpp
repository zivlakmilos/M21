#include <cstdio>

using namespace std;

int abs(int a){
if(a<0) return -a;
else return a;
}

int main(){

int i, N, A[100010], B[100010];

scanf("%d", &N);

for(i=0;i<N;i++)scanf("%d",&A[i]);
for(i=0;i<N;i++)scanf("%d",&B[i]);

long long int S=0;
int j=0;

for(j=0;j<N;j++){
for(i=0;i<N;i++){

S=S+abs(A[(j+i)%N]-B[i]);

}
}

printf("%lld", S);

return 0;
}
