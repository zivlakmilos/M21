#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;
/*struct num
{
    int pos;
    int val;
};

bool operator<(num *ran1,num *ran2)
{
    if (ran1->val < ran2->val) return true;
    if ((ran1->pos < ran2->pos) && (ran1->val==ran2->val)) return true;
}*/
int a[1000007],s[1000007];
long long comb[1000007];
int n,m,k;

int findl(int pos,int lim){
    int x=0;
    pos--;
    while((a[pos]<lim)&&(pos>=0)) {pos--;x++;}
    return x;
}

int findr(int pos,int lim)
{
    int x=0;
    pos++;
    while((a[pos]<=lim)&&(pos<n)) {pos++;x++;}
    return x;
}

long long cnt(int left,int right)
{
    if (left==0) {
    return right+1;}
    if (right==0) return left+1;
    return (left+1)*(right+1);
}

int bin_search(int x,int l, int r)
{
    if (l==r)
    {
        //cout << s[l]<<x<<"usao"<<endl;
        if (s[l]==x) return l;
        return -1;
    }
    int pos = s[(l+r)/2];
    if (pos==x) return (l+r)/2;
    if (x<pos) return bin_search(x,l,(l+r)/2);
    return bin_search(x,(l+r)/2+1,r);
}

//bool bul[1000007]={false};
int main()
{
    k=0;
    scanf("%i",&n);
    for (int i=0;i<n;i++)
    {
        bool bul=true;
        scanf("%i",&a[i]);
        if (i==0) s[0]=a[0];
        for (int j=0;j<=k;j++) if (s[j]==a[i]) bul=false;
        if (bul) {k++;s[k]=a[i];}
    }

    sort(s,s+k+1);
    for (int i=0;i<k+1;i++)
    {
        comb[i]=0;
        int j=0;
        int prepreka = -1;
        int dprep=-1;
        while (j<n)
        {
            if (a[j]>s[i])prepreka=j;
            if (a[j]==s[i])
            {
                //int l=findl(j,s[i]);
                int l,r;
                if (prepreka==-1)  l=j;
                else l=j-prepreka-1;
                if (dprep<j) r=findr(j,s[i]);
                else r=dprep;
                comb[i]+=cnt(l,r);
                //cout << comb[i]<< endl;
                if (comb[i]>=1000000007)comb[i]=comb[i]%1000000007;
                prepreka=j;
            }
            j++;
        }
    }
   // cout << "hola"<<endl;
   //for (int i=0;i<k+1;i++) cout << comb[i]<<"cao"<<endl;
    scanf("%i",&m);
    int b;
    for (int i=0;i<m;i++)
    {
        scanf("%i",&b);
        //int j=0;
        //while(s[j]<b)j++;
        int j= bin_search(b,0,k);
        //cout << j<< "ovaj";
        if (j!=-1) printf("%i\n",comb[j]);
        else printf("0");
    }
    return 0;
}

/*
5
1 2 3 4 3
3
2 3 4

6
1 7 3 7 1 8
2 7 8

10
1000000 1000000 1000000 1000000 1000000 1000000 1000000 1000000 1000000 1000000
1 1
*/
