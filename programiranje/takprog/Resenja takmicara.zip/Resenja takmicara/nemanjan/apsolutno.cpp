#include <cstdio>

using namespace std;

int abs(int br){
	if(br < 0){
		br *= -1;
	}

	return br;
}

int main(){
	int i, n;

	int tmp, polaz;

	unsigned long long int suma = 0;

	unsigned long long int poz = 0, neg = 0, bpoz = 0, bneg = 0;

	scanf("%d", &n);

	scanf("%d", &polaz);

	for(i = 1; i < n; i++){
		scanf("%d", &tmp);

		if(tmp - polaz >= 0){
			bpoz++;
			poz += tmp - polaz;
		}
		else
		{
			bneg++;
			neg += abs(tmp - polaz);
		}
	}

	for(i = 0; i < n; i++){
		scanf("%d", &tmp);

		if(tmp - polaz < 0){
			suma += abs(tmp - polaz) + abs(-1 * bneg * (tmp - polaz) - neg) + abs(-1 * bpoz * (tmp - polaz) + poz);
		}
		else
		{
			suma += abs(tmp - polaz) + abs(bneg * (tmp - polaz) + neg) + abs(bpoz * (tmp - polaz) - poz);
		}
	}

	printf("%lld", suma);

	return 0;
}
