#include <cstdio>

using namespace std;

int abs(int br){
	if(br < 0){
		br *= -1;
	}

	return br;
}

int min(int a, int b){
	if(a < b){
		return a;
	}

	return b;
}

int main(){
 	int x = 0, y = 0;
 	int L = 0, R = 0, D = 0, U = 0;
	int r, s;

	int minvisak = -1;

	int visak;

	int xr, yr;

	int n;

	char tmp;

	int razmak, minrazmak;

	scanf("%d %d %d", &n, &r, &s);

	for(int i = 0; i < n; i++){
		do{
			scanf("%c", &tmp);
		}while(tmp == '\r' || tmp == '\n');

		if(tmp == 'U'){
			U++;

			y++;
		}

		if(tmp == 'D'){
			D++;

			y--;
		}

		if(tmp == 'L'){
			L++;

			x--;
		}

		if(tmp == 'R'){
			R++;

			x++;
		}

		yr = y - s;
		xr = x - r;

		if(abs(0 - s) + abs(0 - r) - 1 < i){
			visak = 0;

			if(abs(U - D - yr) != 0){
				visak += abs(U - D - yr);
			}

			if(abs(R - L - xr) != 0){
				visak += abs(R - L - xr);
			}

			if(visak < minvisak || minvisak == -1){
				minvisak = visak;
			}
		}
	}

	printf("%d 3", minvisak);

	return 0;
}
