#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

const int MAXN=1000000014;

int n,m,k,x[1000014],y[1000014],v[1000014];
bool mat[1014][1014];

int rmat[1014][1014];

int tmat[1014][1014];

void merge(){
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
        rmat[i][j]=min(rmat[i][j],tmat[i][j]);
}

void dfs(int x,int y,int v,int col,int tmpv){
    tmat[x][y]=col;
    if(x-1>=0 && (tmat[x-1][y]>col || tmat[x-1][y]==0) && mat[x-1][y])
        if(tmpv>0)
            dfs(x-1,y,v,col,tmpv-1);
        else
            dfs(x-1,y,v,col+1,v-1);
    if(x+1<n && (tmat[x+1][y]>col || tmat[x+1][y]==0) && mat[x+1][y])
        if(tmpv>0)
            dfs(x+1,y,v,col,tmpv-1);
        else
            dfs(x+1,y,v,col+1,v-1);
    if(y-1>=0 && (tmat[x][y-1]>col || tmat[x][y-1]==0) && mat[x][y-1])
        if(tmpv>0)
            dfs(x,y-1,v,col,tmpv-1);
        else
            dfs(x,y-1,v,col+1,v-1);
    if(y+1<m && (tmat[x][y+1]>col || tmat[x][y+1]==0) && mat[x][y+1])
        if(tmpv>0)
            dfs(x,y+1,v,col,tmpv-1);
        else
            dfs(x,y+1,v,col+1,v-1);
}

void input(){
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++){
        char tmp[1014];
        scanf("%s",tmp);
        for(int j=0;j<m;j++)
            if(tmp[j]=='0')
                mat[i][j]=true;
    }
    scanf("%d",&k);
    for(int i=0;i<k;i++)
        scanf("%d%d%d",&x[i],&y[i],&v[i]);
}

void maxMat(){
    int ma=rmat[0][0],mai=0,maj=0;
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
        if(rmat[i][j]>ma){
            ma=rmat[i][j];
            mai=i;
            maj=j;
        }
    printf("%d %d\n",mai+1,maj+1);
}

void clearTMat(){
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
        if(!mat[i][j])
            tmat[i][j]=-MAXN;
        else
            tmat[i][j]=0;
}

int main(){
    input();
    clearTMat();
    dfs(x[0]-1,y[0]-1,v[0],1,v[0]);
    tmat[x[0]-1][y[0]-1]=0;
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
        rmat[i][j]=tmat[i][j];
    for(int i=1;i<k;i++){
        clearTMat();
        dfs(x[i]-1,y[i]-1,v[i],1,v[i]);
        tmat[x[i]-1][y[i]-1]=0;
        merge();
    }
    maxMat();
    return 0;
}
