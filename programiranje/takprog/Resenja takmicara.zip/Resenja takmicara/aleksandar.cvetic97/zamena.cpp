#include<cstdio>
#include<algorithm>

using namespace std;

int n,a[100014],ma;

bool pog(int a,int b){
    a=abs(a-b);
    while(a%10==0)
        a/=10;
    if(a<10)
        return true;
    return false;
}

int raz(int a,int b){
    a=abs(a-b);
    while(a%10==0)
        a/=10;
    return a;
}

int dfs(int p,int poe){
    int ma = poe;
    for(int i=p+1;i<n;i++)
        if(pog(a[p],a[i]))
            ma = max(ma,dfs(i,poe+raz(a[p],a[i])));
    return ma;
}

int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(int i=0;i<n;i++)
        ma = max(dfs(i,0),ma);
    printf("%d\n",ma);
    return 0;
}
