#include<cstdio>
#include<map>

using namespace std;

int n,q,a[1000014];

map<int,int> b,ll;

int lbound(int i){
    int s=i;
    while(s-1>=0 && a[s-1]<=a[i]){
        s--;
    }
    return s;
}

int rbound(int i){
    int s=i;
    while(s+1<n && a[s+1]<=a[i]){
        s++;
    }
    return s;
}

int func(int l,int r,int i){
    int len = r-l+1;
    int pos = min(i-l,r-i);
    int res = (pos+1)*len - pos*(pos+1);
    return res;
}

void pre(){
    for(int i=0;i<n;i++){
        int l = lbound(i);
        int r = rbound(i);
        int tmp = func(max(l,ll[a[i]]),r,i);
        b[a[i]]+=tmp;
        ll[a[i]] = i+1;
    }
}

int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    pre();
    scanf("%d",&q);
    for(int i=0;i<q;i++){
        int tmp;
        scanf("%d",&tmp);
        printf("%d\n",b[tmp]);
    }
    return 0;
}
