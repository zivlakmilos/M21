#include <cstdlib>
#include <cstdio>
#include <vector>
#include <iostream>
using namespace std;
struct polje
{
       int pb;
       int d;
       int pv;
};
polje pom;
vector<int> q [2];   
polje a[1002][1002];
int b[1002][1002];
int n,m,k,r;
void BFS()
{
     int f,l,y,x;
     l=q[0].size();
     while(f!=l)
     {
                y=q[0][f];
                x=q[1][f];
                if(y>=1 && y<=n && x>=1 && x<=m)
                {
                       if(a[y][x].pb==0 && (a[y+1][x].d==-1 || (a[y+1][x].d>a[y][x].d+1 || a[y+1][x].pv<a[y][x].pv)))
                       {
                       a[y+1][x].pb=a[y][x].pv-1;
                       a[y+1][x].pv=a[y][x].pv;
                       a[y+1][x].d=a[y][x].d+1;
                       if(a[y+1][x].d<b[y+1][x] || b[y+1][x]==-1)b[y+1][x]=a[y+1][x].d;
                       q[0].push_back(y+1);
                       q[1].push_back(x);
                       l++;
                       }
                       if(a[y][x].pb>0 && (a[y+1][x].d==-1 || (a[y+1][x].d>a[y][x].d || a[y+1][x].pv<a[y][x].pv)))
                       {
                       a[y+1][x].pb=a[y][x].pb-1;
                       a[y+1][x].pv=a[y][x].pv;
                       a[y+1][x].d=a[y][x].d;
                       if(a[y+1][x].d>b[y+1][x] || b[y+1][x]==-1)b[y+1][x]=a[y+1][x].d;
                       q[0].push_back(y+1);
                       q[1].push_back(x);
                       l++;
                       }
                       if(a[y][x].pb==0 && (a[y][x-1].d==-1 || (a[y][x-1].d>a[y][x].d+1 || a[y][x-1].pv<a[y][x].pv)))
                       {
                       a[y][x-1].pb=a[y][x].pv-1;
                       a[y][x-1].pv=a[y][x].pv;
                       a[y][x-1].d=a[y][x].d+1;
                       if(a[y][x-1].d<b[y][x-1] || b[y][x-1]==-1)b[y][x-1]=a[y][x-1].d;
                       q[0].push_back(y);
                       q[1].push_back(x-1);
                       l++;
                       }
                       if(a[y][x].pb>0 && (a[y][x-1].d==-1 || (a[y][x-1].d>a[y][x].d || a[y][x-1].pv<a[y][x].pv)))
                       {
                       a[y][x-1].pb=a[y][x].pb-1;
                       a[y][x-1].pv=a[y][x].pv;
                       a[y][x-1].d=a[y][x].d;
                       if(a[y][x-1].d<b[y][x-1] || b[y][x-1]==-1)b[y][x-1]=a[y][x-1].d;
                       q[0].push_back(y);
                       q[1].push_back(x-1);
                       l++;
                       }
                       if(a[y][x].pb==0 && (a[y][x+1].d==-1 || (a[y][x+1].d>a[y][x].d+1 || a[y][x+1].pv<a[y][x].pv)))
                       {
                       a[y][x+1].pb=a[y][x].pv-1;
                       a[y][x+1].pv=a[y][x].pv;
                       a[y][x+1].d=a[y][x].d+1;
                       if(a[y][x+1].d<b[y][x+1] || b[y][x+1]==-1)b[y][x+1]=a[y][x+1].d;
                       q[0].push_back(y);
                       q[1].push_back(x+1);
                       l++;
                       }
                       if(a[y][x].pb>0 && (a[y][x+1].d==-1 || (a[y][x+1].d>a[y][x].d || a[y][x+1].pv<a[y][x].pv)))
                       {
                       a[y][x+1].pb=a[y][x].pb-1;
                       a[y][x+1].pv=a[y][x].pv;
                       a[y][x+1].d=a[y][x].d;
                       if(a[y][x+1].d<b[y][x+1] || b[y][x+1]==-1)b[y][x+1]=a[y][x+1].d;
                       q[0].push_back(y);
                       q[1].push_back(x+1);
                       l++;
                       }
                       if(a[y][x].pb==0 && (a[y-1][x].d==-1 || (a[y-1][x].d>a[y][x].d+1 || a[y-1][x].pv<a[y][x].pv)))
                       {
                       a[y-1][x].pb=a[y][x].pv-1;
                       a[y-1][x].pv=a[y][x].pv;
                       a[y-1][x].d=a[y][x].d+1;
                       if(a[y-1][x].d<b[y-1][x] || b[y-1][x]==-1)b[y-1][x]=a[y-1][x].d;
                       q[0].push_back(y-1);
                       q[1].push_back(x);
                       l++;
                       }
                       if(a[y][x].pb>0 && (a[y-1][x].d==-1 || (a[y-1][x].d>a[y][x].d || a[y-1][x].pv<a[y][x].pv)))
                       {
                       a[y-1][x].pb=a[y][x].pb-1;
                       a[y-1][x].pv=a[y][x].pv;
                       a[y-1][x].d=a[y][x].d;
                       if(a[y-1][x].d<b[y-1][x] || b[y-1][x]==-1)b[y-1][x]=a[y-1][x].d;
                       q[0].push_back(y-1);
                       q[1].push_back(x);
                       l++;
                       }
                }
                /*for(int i=1;i<=n;i++) 
                {
                 for(int j=1;j<=m;j++)
                 {
                    cout<<a[i][j].d<<" ";
                    if(a[i][j].d>max)
                    {
                                     max=a[i][j].d;
                                     y=i;
                                     x=j;
                    }
                 }
                cout<<endl;
                }
                cin>>r;*/
                f++;
     }
}
int main()
{
    scanf("%d %d %d",&n,&m,&k);
    int y,x,v;
    for(int i=0;i<=n+1;i++) 
    {
            for(int j=0;j<=m+1;j++)
            {
                    a[i][j].d=-1;
                    b[i][j]=-1;
            }
    }
    for(int i=0;i<k;i++)
    {
            scanf("%d %d %d",&y,&x,&v);
            a[y][x].pb=0;
            q[0].push_back(y);
            q[1].push_back(x);
            a[y][x].pv=v;
            a[y][x].d=0;
            b[y][x]=0;    
    }
    BFS();
    int max=a[1][1].d;
    for(int i=1;i<=n;i++) 
    {
            for(int j=1;j<=m;j++)
            {
                    if(a[i][j].d<b[i][j])
                    {
                    //cout<<a[i][j].d;
                    if(a[i][j].d>max)
                    {
                    max=a[i][j].d;
                    y=i;
                    x=j;
                    }
                    }
                    else
                    {
                        //cout<<b[i][j];
                        if(b[i][j]>max)
                        {
                        max=b[i][j];
                        y=i;
                        x=j;
                        }
                    }
                    
            }
            //cout<<endl;
    }
    printf("%d %d\n",y,x);
    return 0;
}
