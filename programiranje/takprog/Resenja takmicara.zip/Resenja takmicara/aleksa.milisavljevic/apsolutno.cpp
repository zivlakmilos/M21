#include <cstdlib>
#include <cstdio>
#include <iostream>

using namespace std;
int n,a[100000],b[100000],c[100000],d[100000],k=0,l=0,ba0=0,ba1=0,bb0=0,bb1=0;
long long suma_svih=0,cu=0,du=0;
int main()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++) 
    {
            scanf("%d",&a[i]);
            if(a[i]==0) ba0++;
            if(a[i]==1) ba1++;
    }
    for(int i=0;i<n;i++) 
    {
            scanf("%d",&b[i]);
            if(b[i]==0) bb0++;
            if(b[i]==1) bb1++;
    }
    if(ba0+ba1==n && bb0+bb1==n) printf("%d\n",ba1*bb0+bb1*ba0);
    else
    {
    for(int i=0;i<n;i++)
    {
            if(a[0]-b[i]<=0)
            {
                      c[k]=b[i]-a[0];
                      cu+=c[k];
                      k++;
            }
            else
            {
                 d[l]=a[0]-b[i];
                 du+=d[l];
                 l++;
            }
    }
    //cout<<k<<" "<<l<<endl;
    for(int i=0;i<n;i++)
    {
            if(a[i]==a[0]) suma_svih+=cu+du;
            else
            {
                if(a[i]<a[0])
                {
                             suma_svih+=cu+k*(a[0]-a[i]);
                             for(int j=0;j<l;j++) suma_svih+=abs(d[j]-(a[0]-a[i]));
                }
                else
                {
                    suma_svih+=du+l*(a[i]-a[0]);
                    for(int j=0;j<k;j++) suma_svih+=abs(c[j]-(a[i]-a[0]));
                }
            }
            //cout<<suma_svih<<endl;
    }
    printf("%lld\n",suma_svih);
    }
    return 0;
}
