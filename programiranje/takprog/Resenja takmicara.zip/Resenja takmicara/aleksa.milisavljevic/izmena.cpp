#include <cstdlib>
#include <iostream>
#include <cstdio>

using namespace std;
char niz[500000];
int n,xf,yf,xt=0,yt=0,a[2][500000],dx,dy,c=-1,b=-1;
int main()
{
    scanf("%d %d %d",&n,&xf,&yf);
    scanf("%s",niz);
    if(niz[0]=='R') a[0][0]=1;
    if(niz[0]=='U') a[1][0]=1;
    if(niz[0]=='L') a[0][0]=-1;
    if(niz[0]=='D') a[1][0]=-1;
    for(int i=1;i<n;i++)
    {
            a[0][i]=a[0][i-1];
            a[1][i]=a[1][i-1];
            if(niz[i]=='R') a[0][i]++;
            if(niz[i]=='U') a[1][i]++;
            if(niz[i]=='L') a[0][i]--;
            if(niz[i]=='D') a[1][i]--;
    }
    /*for(int i=0;i<n;i++)
    {
            cout<<a[0][i]<<" "<<a[1][i];
    }*/
    if(yf!=0)
    {
    for(int i=0;i<n;i++)
    {
            dx=xf-xt;
            dy=yf-yt;
            if(abs(dx)+abs(dy)>n-i) break;
            else
            {
                if(abs(dx)+abs(dy)==n-i)
                {
                       if(i==0)
                       {
                            if(abs(dx+a[0][n-1])+abs(dy+a[1][n-1])<b || b==-1) b=abs(dx+a[0][n-1])+abs(dy+a[1][n-1]);
                       }
                       else
                       {
                           if(abs(dx+(a[0][n-1]-a[0][i-1]))+abs(dy+(a[1][n-1]-a[1][i-1]))<b || b==-1) b = abs(dx+(a[0][n-1]-a[0][i-1]))+abs(dy+(a[1][n-1]-a[1][i-1]));
                       }               
                }
                if(i==0)
                {
                       if(abs(dx+a[0][abs(dx)+abs(dy)])+abs(dy+a[1][abs(dx)+abs(dy)])<c || c==-1) c=abs(dx+a[0][n-1])+abs(dy+a[1][n-1]);
                }
                else
                {
                       if(abs(dx+(a[0][abs(dx)+abs(dy)]-a[0][i-1]))+abs(dy+(a[1][abs(dx)+abs(dy)]-a[1][i-1]))<c || c==-1) c = abs(dx+(a[0][n-1]-a[0][i-1]))+abs(dy+(a[1][n-1]-a[1][i-1]));
                }
            }
            if(niz[i]=='R')xt++;
            if(niz[i]=='L')xt--;
            if(niz[i]=='U')yt++;
            if(niz[i]=='D')yt--;
    }
    printf("%d %d\n",c,b);
    }
    else
    {
        for(int i=0;i<n;i++)
        {
                dx=xf-xt;
                if(abs(dx)==n-i)
                {
                if(i==0) if(abs(dx-a[0][n-1])<b || b==-1) b=abs(dx-a[0][n-1]);
                else if(abs(dx-(a[0][n-1]-a[0][i-1]))<b || b==-1) b=abs(dx-(a[0][n-1]-a[0][i-1]));
                }
                if(niz[i]=='R')xt++;
                if(niz[i]=='L')xt--;
        }
        printf("1 %d\n",b);
    }
    return 0;
}
