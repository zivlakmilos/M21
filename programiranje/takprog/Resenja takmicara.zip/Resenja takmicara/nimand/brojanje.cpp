#include <cstdio>
#include <algorithm>
#include <stack>

using namespace std;

typedef long long ll;

const int N = 1000010, mod = 1000000007;
int n, q, d, a[N], b[N], h[N];
int l[N], r[N], p[N];
stack<int> s, t;

int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]), b[i] = a[i];

    sort(b + 1, b + n + 1);
    h[d = 1] = b[1];
    for (int i = 2; i <= n; i++) if (b[i] != b[i - 1]) h[++d] = b[i];
    for (int i = 1; i <= n; i++) a[i] = lower_bound(h + 1, h + d + 1, a[i]) - h;

    for (int i = 1; i <= n; i++)
    {
        while (!s.empty() && a[s.top()] < a[i]) s.pop();
        if (!s.empty()) l[i] = s.top();
        s.push(i);
    }
    for (int i = n; i; i--)
    {
        while (!t.empty() && a[t.top()] <= a[i]) t.pop();
        if (!t.empty()) r[i] = t.top(); else
        r[i] = n + 1;
        t.push(i);
    }
    for (int i = 1; i <= n; i++)
    {
        ll x = i - l[i];
        x *= r[i] - i;
        x %= mod;
        p[a[i]] = (p[a[i]] + x) % mod;
    }

    scanf("%d", &q);
    while (q--)
    {
        int k, x;
        scanf("%d", &k);
        x = lower_bound(h + 1, h + d + 1, k) - h;
        if (x > d || h[x] != k) printf("0\n"); else
        printf("%d\n", p[x]);
    }
    return 0;
}
