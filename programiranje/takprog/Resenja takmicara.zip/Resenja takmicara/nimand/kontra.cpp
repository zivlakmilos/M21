#include <cstdio>
#include <algorithm>
#include <queue>

using namespace std;

typedef pair<int, int> ii;

const int N = 1010, K = 1000010, inf = 1000000007;
const int dx[] = {-1, 0, 0, 1}, dy[] = {0, -1, 1, 0};
int n, m, k, a[N][N], p[N][N];
int x[K], y[K], v[K];
char s[N];
queue<ii> q;

bool moze(int x, int y)
{
    return x > 0 && x <= n && y > 0 && y <= m && !p[x][y];
}

void sub0()
{
    for (int i = 1; i <= k; i++) p[x[i]][y[i]] = 1, q.push(ii(x[i], y[i]));
    while (!q.empty())
    {
        int x = q.front().first, y = q.front().second;
        q.pop();
        for (int i = 0; i < 4; i++)
        {
            int xc = x + dx[i], yc = y + dy[i];
            if (moze(xc, yc)) p[xc][yc] = p[x][y] + 1, q.push(ii(xc, yc));
        }
    }
    int z = 0, xs, ys;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) if (p[i][j] > z) z = p[i][j], xs = i, ys = j;
    printf("%d %d\n", xs, ys);
}

void sub2()
{
    sub0();
}

void solve()
{
    sub0();
}

int main()
{
    bool f = false, g = false;
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= n; i++)
    {
        scanf("%s", s + 1);
        for (int j = 1; j <= m; j++) a[i][j] = s[j];
    }
    scanf("%d", &k);
    for (int i = 1; i <= k; i++)
    {
        scanf("%d %d %d", &x[i], &y[i], &v[i]);
        if (v[i] != v[1]) f = true;
    }
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) if (a[i][j]) g = true;
    if (!f) sub0(); else
    if (!g) sub2(); else
    solve();
    return 0;
}
/*
5 5
00101
00000
00001
00010
00000
2
3 2 2
1 4 2
*/
