#include <cstdio>
#include <algorithm>

using namespace std;

const int N = 100010, D = 10000010;
int n, a[N], sol;
int dp[D];

void upd(int k, int x, int p)
{
    int c = x % 10, g;
    if (x >= 10 || a[1] < 10) g = 0; else
    g = 1;
    for (int j = g; j < 10; j++)
    {
        if (dp[k + (j - c) * p] != -1)
            dp[k] = max(dp[k], dp[k + (j - c) * p] + abs(j - c));
    }
}

int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    for (int i = 0; i < D; i++) dp[i] = -1;
    for (int i = 1; i <= n; i++)
    {
        int k = a[i], x = a[i], p = 1;
        dp[k] = max(dp[k], 0);
        if (!k) upd(0, 0, 1); else
        for (; x; x /= 10, p *= 10) upd(k, x, p);
        sol = max(sol, dp[k]);
    }
    printf("%d\n", sol);
    return 0;
}
/*
5
1999991
9999991
1999994
1231232
1999991
*/
