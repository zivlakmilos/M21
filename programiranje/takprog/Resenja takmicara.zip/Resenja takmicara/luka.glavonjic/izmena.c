#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    long int N, p, q, i, a, b, x, y, temp;
    long int u, d, l, r, nU, nD, nL, nR, uV, dV, lV, rV, uM, dM, lM, rM;
    int alX, alY, allowA;
    char ar[500000];
    u = 0;
    d = 0;
    l = 0;
    r = 0;
    nU = 0;
    nD = 0;
    nL = 0;
    nR = 0;
    uV = 0;
    dV = 0;
    lV = 0;
    rV = 0;
    uM = 0;
    dM = 0;
    lM = 0;
    rM = 0;
    alX = 0;
    alY = 0;
    allowA = 0;
    a = 0;
    b = 0;
    x = 0;
    y = 0;
    temp = 0;
    scanf("%ld %ld %ld\n", &N, &p, &q);
    if(p>0){
        r = p;
    }
    if(p<0){
        l = -p;
    }
    if(q>0){
        u = q;
    }
    if(q<0){
        d = -q;
    }
    for(i=0; i<N; i++){
        scanf("%c", &ar[i]);
        if(ar[i]=='U'){
            nU++;
        }
        if(ar[i]=='D'){
            nD++;
        }
        if(ar[i]=='L'){
            nL++;
        }
        if(ar[i]=='R'){
            nR++;
        }
    }
    if(nU>u){
        uV = nU-u;
    }
    else{
        uM = u-nU;
    }
    if(nD>d){
        dV = nD-d;
    }
    else{
        dM = d-nD;
    }
    if(nL>l){
        lV = nL-l;
    }
    else{
        lM = l-nL;
    }
    if(nR>r){
        rV = nR-r;
    }
    else{
        rM = r-nR;
    }
    //printf("%lld %lld %lld %lld | %lld %lld %lld %lld\n", uV, dV, lV, rV, uM, dM, lM, rM);
    if(uM>dV || dM>uV){
        alY = 1;
    }
    if(lM>rV || rM>lV){
        alX = 1;
    }
    //printf("%d %d\n", alX, alY);
    for(i=0; i<N; i++){
        if(ar[i]=='U' && ((alX==1 && y>=q) || (alX==0 && y>q))){
            if(alX){
                if(lM>0){
                    //menjaj u left
                    lM--;
                    uV--;
                    x--;
                }
                if(rM>0){
                    //menjaj u right
                    rM--;
                    uV--;
                    x++;
                }
            }
            else{
                //menjaj u down
                dM--;
                uV--;
                y--;
                //printf("-----%lld %lld\n", i, y);
            }
            if(allowA==0){
              a++;
            }
        }
        else if(ar[i]=='U' && y<=q){
            y++;
        }

        if(ar[i]=='D' && ((alX==1 && y<=q) || (alX==0 && y<q))){
            if(alX){
                if(lM>0){
                    //menjaj u left
                    lM--;
                    dV--;
                    x--;
                }
                if(rM>0){
                    //menjaj u right
                    rM--;
                    dV--;
                    x++;
                }
            }
            else{
                //menjaj u down
                uM--;
                dV--;
                y++;
            }
            if(allowA==0){
              a++;
            }
        }
        else if(ar[i]=='D' && y>=q){
            y--;
        }

        if(ar[i]=='L' && ((alY==1 && x<=p) || (alY==0 && x<p))){
            if(alY){
                if(uM>0){
                    //menjaj u left
                    uM--;
                    lV--;
                    y++;
                }
                if(dM>0){
                    //menjaj u right
                    dM--;
                    lV--;
                    y--;
                }
            }
            else{
                //menjaj u down
                rM--;
                lV--;
                x++;
            }
            if(allowA==0){
                a++;
            }
        }
        else if(ar[i]=='L' && x>=p){
            x--;
        }

        if(((alY==1 && x>=p) || (alY==0 && x>p)) && ar[i]=='R'){
            if(alY){
                if(uM>0){
                    //menjaj u left
                    uM--;
                    rV--;
                    y++;
                }
                if(dM>0){
                    //menjaj u right
                    dM--;
                    rV--;
                    y--;
                }
            }
            else{
                //menjaj u down
                lM--;
                rV--;
                x--;
            }
            if(allowA==0){
                a++;
            }
        }
        else if(ar[i]=='R' && x<=p){
            x++;
        }
        //printf("%lld %lld\n", x, y);
        //if(uM==0 && dM==0 && lM==0 && rM==0){
        if(x==p && y==q){
            temp=i;
            allowA = 1;
            break;
            //printf("%lld %lld %lld %lld | %lld %lld %lld %lld\n", uV, dV, lV, rV, uM, dM, lM, rM);
            //printf("----------%lld %lld\n", x, y);
        }
    }

    printf("%ld", a);
    //printf("%lld\n", temp);
    nU = 0;
    nD = 0;
    nL = 0;
    nR = 0;
    for(i=temp+1; i<N; i++){
        //printf("%c", ar[i]);
        if(ar[i]=='U'){
            nU++;
        }
        if(ar[i]=='D'){
            nD++;
        }
        if(ar[i]=='L'){
            nL++;
        }
        if(ar[i]=='R'){
            nR++;
        }
    }
    //printf("\n%lld %lld %lld %lld", nU, nD, nL, nR);
    b = a;
    if(abs(nU-nD)>1){
        if(abs(nU-nD)%2==0){
            if(nU>nD){
                b+= (nU-nD)/2;
                nD+=(nU-nD)/2;
                nU-=(nU-nD)/2;
            }
            else{
                b+=(nD-nU)/2;
                nU+=(nD-nU)/2;
                nD-=(nD-nU)/2;
            }
        }
        else{
            if(nU>nD){
                b+= (nU-nD-1)/2;
                nD+=(nU-nD-1)/2;
                nU-=(nU-nD-1)/2;
            }
            else{
                b+=(nD-nU-1)/2;
                nU+=(nD-nU-1)/2;
                nD-=(nD-nU-1)/2;
            }
            if(nL<nR){
                nL++;
                b++;
            }
            else if(nR>nL){
                nR++;
                b++;
            }
        }
    }
    if(nL>nR){
        b+=(nL-nR)/2;
        nR+=(nL-nR)/2;
        //printf("a asdsdf %lld", nL-nR);
    }
    else if(nR>nL){
        b+=(nR-nL)/2;
        nL+=(nR-nL)/2;
    }
    printf(" %ld", b);
    return 0;
}
