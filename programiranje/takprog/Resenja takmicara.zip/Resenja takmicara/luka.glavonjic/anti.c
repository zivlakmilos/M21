#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int ar[1000][1000];
int main()
{
    int N, M, K, temp;
    scanf("%d %d %d", &N, &M, &K);
    int koo[10][2];
    long long int brz[10];
    int i,j, i1;
    int max = 0;
    int x, y;
    for(i=1; i<=K; i++){
        scanf("%d %d %lld", &koo[i][0], &koo[i][1], &brz[i]);
    }
    for(i1=1; i1<=1; i1++){
        for(i=1; i<=N; i++){
            for(j=1; j<=M; j++){
                temp = abs(koo[i1][0]-i) + abs(koo[i1][1]-j);
                //printf("%lld ", temp/brz[i1]);
                if(temp % brz[i1]==0){
                    //if(temp/brz[i1]<ar[i][j]){
                        ar[i][j]=temp/brz[i1];
                    //}
                }
                else{
                    //if(temp/brz[i1]+1<ar[i][j]){
                        ar[i][j]=temp/brz[i1]+1;
                    //}
                }
                //printf("%d ", ar[i][j]);
            }
            //printf("\n");
        }
    }
    //printf("\n");
    for(i1=2; i1<=K; i1++){
        for(i=1; i<=N; i++){
            for(j=1; j<=M; j++){
                temp = abs(koo[i1][0]-i) + abs(koo[i1][1]-j);
                //printf("%lld ", temp/brz[i1]);
                if(temp % brz[i1]==0){
                    if(temp/brz[i1]<ar[i][j]){
                        ar[i][j]=temp/brz[i1];
                    }
                }
                else{
                    if(temp/brz[i1]+1<ar[i][j]){
                        ar[i][j]=temp/brz[i1]+1;
                    }
                }
                //printf("%d ", ar[i][j]);
            }
            //printf("\n");
        }
    }
    for(i=1; i<=N; i++){
        for(j=1; j<=M; j++){
            if(ar[i][j]>max){
                max = ar[i][j];
                x = i;
                y = j;
            }
        }
    }
    printf("%d %d", x, y);
    return 0;
}



