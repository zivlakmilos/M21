#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main()
{
    long long int n, i, i1, sum, a[100000], b[100000];
    sum = 0;
    scanf("%lld", &n);
    for(i=0; i<n; i++){
        scanf("%lld", &a[i]);
    }
    for(i=0; i<n; i++){
        scanf("%lld", &b[i]);
        for(i1=0; i1<n; i1++){
            sum+=abs(a[i1]-b[i]);
        }
    }


    printf("%lld", sum);
    return 0;
}




