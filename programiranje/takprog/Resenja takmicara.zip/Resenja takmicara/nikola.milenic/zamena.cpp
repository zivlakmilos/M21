#include <stdio.h>
#include <vector>
using namespace std;
    vector<int> b[1000100], ch[100001], g[100001];
    int a[100010], inc[100010];
    int c, d, i, j, k, l, n, x, y, mx;
int main(){
    scanf("%d", &n);
    for (i=0; i<n; i++){
        scanf("%d", &a[i]);
        b[a[i]%1000073].push_back(i);
        for (x=a[i], j=1; x>0; x/=10, j++);
        for (x=1, k=0; k<j; k++, x*=10){
            c=(a[i]-a[i]%x-(a[i]/x/10)*x*10)/x;
            d=a[i]-a[i]/x%10*x;
            for (y=(j<=1||k<j)?0:1; y<10; y++)
                if (y!=c && b[(d+x*y)%1000073].size()>0)
                    for (l=0; l<b[(d+x*y)%1000073].size(); l++){
                        ch[b[(d+x*y)%1000073][l]].push_back(i);
                        g[b[(d+x*y)%1000073][l]].push_back(c>y?c-y:y-c);
                        inc[i]++;
                    }
        }
    }
    l=0;
    for (i=0; i<n; i++){
        if (inc[i]==0) {
            a[l]=i;
            l++;
            }
    }
    for (i=0; i<n; i++){
        for(j=0; j<ch[a[i]].size(); j++){
            inc[ch[a[i]][j]]--;
            if (inc[ch[a[i]][j]]==0){
                a[l]=ch[a[i]][j];
                l++;
            }
        }
    }
    for (i=n-1; i>=0; i--){
        inc[a[i]]=0;
        for (j=0; j<ch[a[i]].size(); j++){
            if(inc[a[i]]<g[a[i]][j]+inc[ch[a[i]][j]])
                inc[a[i]]=g[a[i]][j]+inc[ch[a[i]][j]];
        }
        if (inc[a[i]]>mx) mx=inc[a[i]];
    }
    printf("%d", mx);
    return 0;
}
