#include <stdio.h>
using namespace std;
long long i, j, k, n, q;
long long a[1000100], b[1000100], c[1000100], r[1000100];
int main(){
    scanf("%lld", &n);
    for (i=0; i<n; i++) {scanf("%lld", &a[i]); r[a[i]%1000073]=-1;}
    for (i=0; i<n; i++) if (r[a[i]%1000073]<i){
    for(j=i; j>0 && a[j]<=a[i]; j--);
    if (a[j]>a[i]) j++;
    for(k=i; k<n-1 && a[k]<=a[i]; k++);
    if (a[k]>a[i]) k--;
    b[a[i]%1000073]+=(k-i+1)*(i-j+1)%1000000007;
    r[a[i]%1000073]=k;
    }
    scanf("%d", &q);
    for (i=0; i<q; i++) scanf("%lld", &c[i]);
    for (i=0; i<q; i++) printf("%lld\n", b[c[i]%1000073]);
    return 0;
}
