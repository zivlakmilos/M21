#include <stdio.h>
using namespace std;
int a,b,i,j,k,l,n,m;
char x;
int main(){
    scanf("%d%d", &n, &m);
    for (i=1; i<=n; i++)
        for (j=1; j<=m+1; j++)
            scanf("%c", &x);


    scanf("%d", &x);
    for (i=0; i<x; i++) scanf("%d%d%d", &k, &j, &l);
    printf("%d %d", n/2+1, m);
    return 0;
}
