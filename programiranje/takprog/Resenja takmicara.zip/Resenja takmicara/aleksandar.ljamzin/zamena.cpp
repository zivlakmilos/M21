#include <iostream>
#include <stdio.h>
#include <list>
#include <queue>
#include <algorithm>
#include <set>
#include <math.h>
using namespace std;
#define IN(x) scanf("%d", &x)
#define IN2(x, y) scanf("%d%d", &x, &y)
#define IN3(x, y, z) scanf("%d%d%d", &x, &y, &z)
#define TT DEBUG(printf("\t\t");)
#define fi first
#define se second
#define itr iterator
#define mxc(mx, c) {if((mx)<(c)) {(mx)=(c);} }
typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
enum { N = 100100, INF = 1000000000 };
#define DEBUG(x) 
struct tri
{
       int w, f, d;
       tri(int w0,int f0,int d0)
       {
               w=w0; f=f0; d=d0;
       }
       bool operator<(const tri& t) const
       {
            return( (w<t.w) || (w==t.w&&(f<t.f||(f==t.f&&d<t.d) ) ) );
       }
};
int n, a[N], mx[N];
int main()
{
    set<tri> sp[10], sm[10];
    IN(n);
    for(int i=0; i<n; i++) IN(a[i]);
    if(a[0]<10)
    {    
        int sum=0;
        for(int i=0; i<n-1; i++)
        {
                sum+=abs(a[i]-a[i+1]);
        }
        printf("%d\n", sum);
        DEBUG(system("PAUSE");)
        return 0;
    }
    for(int i=n-1; i>=0; i--)
    {
            int num=a[i];
            for(int j=0, sd=1; (num+1)/sd>0; j++, sd*=10)
            {
                    int ls=(num/sd)%10;
                    int nn=((num/(sd*10))*sd)+num%sd;
                    //printf(" %d %d \n", ls, nn);
                    set<tri>::itr ip=sp[j].lower_bound(tri(nn+1, -INF, 0));
                    if(ip!=sp[j].begin()&&(--ip)->w==nn)
                    {
                                   int tmp=ip->f-ls;                  
                                   mxc(mx[i], tmp);
                    }                    
                    set<tri>::itr im=sm[j].lower_bound(tri(nn+1, -INF, 0));
                    if(im!=sm[j].begin()&&(--im)->w==nn)
                    {
                                   int tmp=im->f+ls;                     
                                   mxc(mx[i], tmp);
                    }
                    //mxc(mx[i], mx[i+1]);
            }
            for(int j=0, sd=1; num/sd>0; j++, sd*=10)
            {
                    int ls=(num/sd)%10;
                    int nn=((num/(sd*10))*sd)+num%sd;
                    sp[j].insert(tri(nn, mx[i]+ls, ls) );
                    sm[j].insert(tri(nn, mx[i]-ls, ls) );
            }
    }
    int sum=0;
    for(int i=0; i<n; i++) mxc(sum, mx[i]);
    printf("%d\n", sum);
    DEBUG(system("PAUSE");)
    return 0;
}
