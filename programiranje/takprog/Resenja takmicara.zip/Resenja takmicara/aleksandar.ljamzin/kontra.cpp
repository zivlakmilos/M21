#include <iostream>
#include <stdio.h>
#include <list>
#include <queue>
#include <algorithm>
#include <set>
#include <math.h>
#include <map>
#include <bitset>
using namespace std;
#define IN(x) scanf("%d", &x)
#define IN2(x, y) scanf("%d%d", &x, &y)
#define IN3(x, y, z) scanf("%d%d%d", &x, &y, &z)
#define TT DEBUG(printf("\t\t");)
#define fi first
#define se second
#define itr iterator
#define mxc(mx, c) {if((mx)<(c)) {(mx)=(c);} }
typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
enum { N = 1250, M = 1001000 };
#define DEBUG(x) 
#define ts second.first
#define tt second.second
inline int max(int a, int b) { return a>b?a:b; }
struct something
{
       int left;
       vector<ii> pos;
};
int n, m, k;
bitset<N> vis[N];
int dx[] = { 1, 0, 0, -1 };
int dy[] = { 0, 1, -1, 0 };
char s[N];
int qx[2][M], qy[2][M], sp[2][M], pr=1, cu=0, prc=0, cuc=0;
int wx[2][M], wy[2][M], ws[2][M], wl[2][M];
int main()
{
    IN2(n, m);
    for(int i=0; i<n; i++)
    {
            scanf("%s", s);
            for(int j=0; j<m; j++)
            {
                    if(s[i]=='1') vis[i][j]=1;
            }
    }
    IN(k); prc=k;
    map<int, something> mp;
    for(int i=0; i<k; i++)
    {
            int tx, ty, tsp;
            IN3(tx, ty, tsp);
            mp[tsp].pos.push_back(ii(tx, ty));
    }
    int turn=0;
    printf("1\n"); 
    /*
    for(;;turn++)
    {
           for(map<int, something>::itr it=mp.begin(); it!=mp.end(); ++it)
           {
                        map<int, something>::itr nx=it; ++nx;
                        if(nx==mp.end())
                        {
                                        for(int i=0; i<(int)v[pr].size(); i++)
                                        {
                                                        
                                        }
                        }
                        else
                        {
                            int ms=it->left-nx->left+1;
                            vector<ii> v[2];
                            v[1]=it->pos;
                            int pr=1, cu=0;
                            while(nx--)
                            {
                                       for(int i=0; i<(int)v[pr].size(); i++)
                                       {
                                               for(int d=0; d<4; d++)
                                               {
                                                       int nx=v[pr][i].fi+dx[d];
                                                       int ny=v[pr][i].se+dy[d];
                                                       if(nx>=0&&nx<n&&ny>=0&&ny<m&&vis[nx][ny]==0)
                                                       {
                                                              vis[nx][ny]=1;
                                                              v[cu].push_back(ii(nx, ny));
                                                       }
                                               }
                                       }
                                       pr=cu;
                                       cu=1-cu;
                            }
                            it->pos=v[pr];
                            it->left=nx->left-1;
                        }
                        
           }
    }
    printf("%d\n", turn);
    DEBUG(system("PAUSE");)*/
    return 0;
}
