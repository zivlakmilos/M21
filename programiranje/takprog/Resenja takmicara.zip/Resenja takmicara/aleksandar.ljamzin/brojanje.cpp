#include <iostream>
#include <stdio.h>
#include <list>
#include <queue>
#include <algorithm>
#include <set>
#include <math.h>
#include <map>
using namespace std;
#define IN(x) scanf("%d", &x)
#define IN2(x, y) scanf("%d%d", &x, &y)
#define IN3(x, y, z) scanf("%d%d%d", &x, &y, &z)
#define TT DEBUG(printf("\t\t");)
#define fi first
#define se second
#define itr iterator
#define mxc(mx, c) {if((mx)<(c)) {(mx)=(c);} }
typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
enum { N = 1001000, INF = 1000000000, MOD = 1000000007, INVALID = -37 };
#define DEBUG(x) 
inline int max(int a, int b) { return a>b?a:b; }
int n, q;
pair<int, ii> a[N];
pair<int, ll> p[N];
struct segtree
{
       segtree *l, *r;
       int b, e;
       int mx;
       segtree(int b0, int e0)
       {
                   b=b0; e=e0;
                   if(b!=e)
                   {
                           int m=(b+e)/2;
                           l=new segtree(b, m);
                           r=new segtree(m+1, e);
                           mx=max(l->mx, r->mx);
                   }
                   else mx=a[b].fi;
       }
       segtree(int b0, int e0, int val)
       {
                   b=b0; e=e0;
                   if(b!=e)
                   {
                           int m=(b+e)/2;
                           l=new segtree(b, m, val);
                           r=new segtree(m+1, e, val);
                   }
                   mx=val;
       }
       int findleft(int x)
       {
                    if(mx<x) return INVALID;
                    if(b==e) return b;
                    if(r->mx>=x) return r->findleft(x);
                    return l->findleft(x);
       }
       int findright(int x)
       {
           if(mx<=x) return INVALID;
           if(b==e) return b;
           if(l->mx>x) return l->findright(x);
           return r->findright(x);
       }
       void update(int i, int v)
       {
                  if(i<b||i>e) return;
                  if(b!=e)
                  {
                          r->update(i, v);
                          l->update(i, v);
                          mx=max(r->mx, l->mx);
                  }
                  else mx=v;
       }
};
#define ts second.first
#define tt second.second
int main()
{
    IN(n);
    for(int i=0; i<n; i++) IN(a[i].fi);
    segtree st(0, n-1, -1);
    segtree en(0, n-1);
    for(int i=0; i<n; i++)
    {
            en.update(i, -1);
            int l = st.findleft(a[i].fi);
            int r = en.findright(a[i].fi);
            if(l==INVALID) l=i+1;
            else l=i-l;
            if(r<0) r=n-i;
            else r=r-i;
            st.update(i, a[i].fi);
            a[i].ts=l;
            a[i].tt=r;
            
    }
    /*map<int, int> m;
    set<ii> s;
    a[0].se=1;
    m.insert(ii(a[0].fi, 0));
    for(int i=1; i<n; i++)
    {
            
            s.insert(ii(a[i].fi, i));
    }
    for(int i=1; i<n; i++)
    {
            s.erase(ii(a[i].fi, i));
            map<int, int>:: itr it=m.upper_bound(a[i].fi);
            set<ii>::itr en=s.lower_bound(ii(a[i].fi, i));
            if(it==m.end()) a[i].se=i+1;
            else a[i].se=i-it->se;
            if(en==s.end()) a[i].se+=n-i-1;
            else a[i].se+=en->se-i-1;
            m[a[i].fi]=i;
    }*/
    sort(a, a+n);
    //DEBUG(for(int i=0; i<n; i++) printf(" %d %d %d \n", a[i].fi, a[i].ts, a[i].tt);)
    int id=0, ls=a[0].fi;
    p[0].se=a[0].fi;
    p[0].fi=ls;
    for(int i=1; i<n; i++)
    {
            if(ls==a[i].fi) p[id].se+=((ll)a[i].ts*(ll)a[i].tt)%MOD;
            else
            {
                id++;
                ls=a[i].fi;
                p[id].fi=ls;
                p[id].se=((ll)a[i].ts*(ll)a[i].tt)%MOD;
            }
    }
    IN(q); id++;
    //DEBUG(for(int i=0; i<id; i++) printf(" %d %d \n", p[i].fi, p[i].se);)
    while(q--)
    {
              int tmp;
              IN(tmp);
              pair<int, ll> *pt=lower_bound(p, p+id, pair<int, ll>(tmp, -1) ); TT;
              if(pt->fi!=tmp) printf("0\n");
              else printf("%d\n", (int)(pt->se%MOD) );
    }
    DEBUG(system("PAUSE");)
    return 0;
}
