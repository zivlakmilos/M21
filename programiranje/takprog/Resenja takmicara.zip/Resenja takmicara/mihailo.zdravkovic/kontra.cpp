#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <queue>
#include <string>

using namespace std;
int n, m, k, kx[1000000], ky[1000000], v[1000000], mat[1000][1000], skr[1000][1000];
int mat1[1000][1000], skr1[1000][1000];
int hx[4] = {0, 0, 1, -1};
int hy[4] = {1, -1, 0, 0};

struct polje {
    int i, j, speed, time;
};

void BFS() {
    queue <polje> q;
    for(int i = 0; i < k; i++) {
        polje p;
        p.i = kx[i] - 1;
        p.j = ky[i] - 1;
        p.speed = v[i];
        p.time = 0;
        q.push(p);
        skr[kx[i]][ky[i]] = 0;
        mat[kx[i]][ky[i]] = -1;
    }
    while(!q.empty()) {
        polje p = q.front();
        q.pop();
        /*for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                cout << mat[i][j] << " ";
            }
            cout << endl;
        }*/
        //cout << p.i << " " << p.j << endl;
        for(int i = (-1) * p.speed; i <= p.speed; i++) {
            for(int j = (-1) * p.speed; j <= p.speed; j++) {
                if(p.i + i >= 0 && p.i + i < n && p.j + j >= 0 && p.j + j < m && abs(i) + abs(j) <= p.speed) {
                    if(mat[p.i + i][p.j + j] == 0) {
                        if(abs(i) + abs(j) == p.speed) {
                            polje tmp;
                            tmp.i = p.i + i;
                            tmp.j = j + p.j;
                            tmp.speed = p.speed;
                            tmp.time = p.time + 1;
                            q.push(tmp);
                        }
                        skr[p.i + i][p.j + j] = p.time + 1;
                        mat[p.i + i][p.j + j] = -1;
                    }
                    if(mat[p.i + i][p.j + j] == -1 && skr[p.i + i][p.j + j] > p.time + 1) {
                        skr[p.i + i][p.j + j] = p.time + 1;
                    }
                }
            }
        }
    }
    int maximum = 0;
    int ki, kj;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            if(skr[i][j] > maximum) {
                maximum = skr[i][j];
                ki = i;
                kj = j;
            }
        }
    }
    cout << ki + 1 << " " << kj + 1;
}

void BFSALLEQUAL() {
    //cout << "using bfs equal";
    queue <polje> q;
    for(int i = 0; i < k; i++) {
        polje p;
        p.i = kx[i] - 1;
        p.j = ky[i] - 1;
        p.speed = v[i];
        p.time = 0;
        q.push(p);
        skr[kx[i]][ky[i]] = 0;
        mat[kx[i]][ky[i]] = -1;
    }
    while(!q.empty()) {
        polje p = q.front();
        q.pop();
        /*for(int i = 0; i < n; i++) {
            for(int j = 0; j < m; j++) {
                cout << mat[i][j] << " ";
            }
            cout << endl;
        }*/
        //cout << p.i << " " << p.j << endl;
        for(int i = 0; i < 4; i++) {
            if(p.i + hx[i] >= 0 && p.i + hx[i] < n && p.j + hy[i] >= 0 && p.j + hy[i] < m) {
                if(mat[p.i + hx[i]][p.j + hy[i]] == 0) {
                    polje tmp;
                    tmp.i = p.i + hx[i];
                    tmp.j = hy[i] + p.j;
                    tmp.time = p.time + 1;
                    q.push(tmp);
                    skr[p.i + hx[i]][p.j + hy[i]] = p.time + 1;
                    mat[p.i + hx[i]][p.j + hy[i]] = 1;
                }
            }
        }
    }
    int maximum = 0;
    int ki, kj;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            if(skr[i][j] > maximum) {
                maximum = skr[i][j];
                ki = i;
                kj = j;
            }
        }
    }
    cout << ki + 1 << " " << kj + 1;
}

void BFS3 () {
    for(int i = 0; i < n; i++)
            for(int j = 0; j < m; j++)
                skr[i][j] = -1;
    for(int l = 0; l < k; l++) {
        //cout << "using bfs 3";
        for(int i = 0; i < n; i++)
            for(int j = 0; j < m; j++)
                mat1[i][j] = mat[i][j];
        queue <polje> q;
        polje p;
        p.i = kx[l] - 1;
        p.j = ky[l] - 1;
        p.speed = v[l];
        p.time = 0;
        q.push(p);
        skr1[kx[l]][ky[l]] = 0;
        mat1[kx[l]][ky[l]] = -1;
        while(!q.empty()) {
            polje p = q.front();
            q.pop();
//            for(int i = 0; i < n; i++) {
//                for(int j = 0; j < m; j++) {
//                    cout << mat[i][j] << " ";
//                }
//                cout << endl;
//            }
            //cout << p.i << " " << p.j << endl;
            for(int i = 0; i < 4; i++) {
                if(p.i + hx[i] >= 0 && p.i + hx[i] < n && p.j + hy[i] >= 0 && p.j + hy[i] < m) {
                    if(mat1[p.i + hx[i]][p.j + hy[i]] == 0) {
                        polje tmp;
                        tmp.i = p.i + hx[i];
                        tmp.j = hy[i] + p.j;
                        tmp.time = p.time + 1;
                        q.push(tmp);
                        skr1[p.i + hx[i]][p.j + hy[i]] = p.time + 1;
                        mat1[p.i + hx[i]][p.j + hy[i]] = 1;
                    }
                }
            }
        }
        for(int i = 0; i < n; i++) {
                for(int j = 0; j < m; j++) {
                    if((skr1[i][j]+v[l]-1)/v[l] < skr[i][j] || skr[i][j] == -1) {
                        skr[i][j] = skr1[i][j];
                    }
                }
        }
    }
    int maximum = 0;
    int ki, kj;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            if(skr[i][j] > maximum) {
                maximum = skr[i][j];
                ki = i;
                kj = j;
            }
        }
    }
    cout << ki + 1 << " " << kj + 1;
}


int main()
{
    scanf("%i%i", &n, &m);
    char s[1005];
    for(int i = 0; i < n; i++) {
        scanf("%s", &s);
        for(int j = 0; j < m; j++) {
            mat[i][j] = (int)(s[j] - '0');
            //printf("working on it\n");
        }
    }
    scanf("%i", &k);
    for(int i = 0; i < k; i++) {
        scanf("%i%i%i", &kx[i], &ky[i], &v[i]);
    }
    bool doSecond = false;
    int brz = v[0];
    for(int i = 1; i < k; i++) {
        if(v[i] != brz) doSecond = true;
    }
    bool allzero = true;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            if(mat[i][j] == 1) allzero = false;
        }
    }
    if(doSecond) {
            if(allzero || k * m * n > 200000000) {
                    BFS();
            }
            else BFS3();

    } else BFSALLEQUAL();
    //cout << sizeof(ky);
    return 0;
}
