#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stack>

using namespace std;
int n, a[10000];
bool used[10000];
int computed[10000];

struct node {
    int cvor;
    int w;
    node *next;
};

node* niz[10000];

void createEdge(int x, int y) {
    node *tmp;
    tmp = new node();
    tmp->cvor = y;
    tmp->w = 0;
    for(int i = 1; i < 10000000; i = i * 10) {
        tmp->w += abs(((a[x] / i) % 10) - ((a[y] / i) % 10));
    }
    tmp->next = niz[x];
    niz[x] = tmp;
}

int DFS(int x, int weight) {
    if(computed[x] != -1) {
        return computed[x] + weight;
    }
    int currMax = 0;
    node *tmp;
    tmp = niz[x];
    while(tmp != NULL) {
        int k = DFS(tmp->cvor, weight + tmp->w);
        if(currMax < k - weight) {
            currMax = k - weight;
        }
        tmp = tmp->next;
    }
    computed[x] = currMax;
    return currMax + weight;
}

int calculate() {
    for(int i = 0; i < n; i++) computed[i] = -1;
    int maxWeight = 0;
    for(int i = 0; i < n; i++) {
        int k;
        if(computed[i] == -1) {
            k = DFS(i, 0);
        } else {
            k = computed[i];
        }
        if(k > maxWeight) maxWeight = k;
    }
    return maxWeight;
}

int main()
{
    scanf("%i", &n);
    for(int i = 0; i < n; i++) {
        scanf("%i", &a[i]);
        for(int j = 0; j < i; j++) {
            int diff = 0;
            for(int k = 1; k < 10000000; k = k * 10) {
                if(((a[i] / k) % 10) - ((a[j] / k) % 10) != 0) diff++;
            }
            if(diff == 1) createEdge(j, i);
        }
    }

    /*for(int i = 0; i < n; i++) {
        node *tmp;
        printf("%i: ", a[i]);
        tmp = niz[i];
        while(tmp != NULL) {
            printf("%i ", a[tmp->cvor]);
            tmp = tmp->next;
        }
        printf("\n");
    }*/

    printf("%i", calculate());
    return 0;
}
