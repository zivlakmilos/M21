#include <iostream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
int n, q;
int a[1000000], res[1000000];
int r[1000000], l[1000000];

int main()
{
    scanf("%i", &n);
    for(int i = 0; i < n; i++) {
        scanf("%i", &a[i]);
    }
    for(int i = 0; i < n; i++) {
        l[i] = 1;
        int k = i - 1;
        while(a[k] < a[i] && k >= 0) {
            l[i] = l[i] + l[k];
            k = k - l[k];
        }
    }
    for(int i = n-1; i >= 0; i--) {
        r[i] = 1;
        int k = i + 1;
        while(a[k] <= a[i] && k < n) {
            r[i] = r[i] + r[k];
            k = k + r[k];
        }
    }
    for(int i = 0; i < n; i++) {
        res[a[i]] = (res[a[i]] + ((l[i] * r[i]) % 1000000007)) % 1000000007;
        //cout << res[i] << endl;
    }
    scanf("%i", &q);
    for(int i = 0; i < q; i++) {
        int query;
        scanf("%i", &query);
        printf("%i\n", res[query]);
    }
    return 0;
}
