#include <iostream>
#include <cstdlib>
#include <stdio.h>
using namespace std;

#define MOD 1000000007
#define NMAX 1000005
int N,Q;
int a[NMAX];

long long finterval(int a,int b)
{
    if (b<a) return 0;
    long long length=b-a+1;
    long long bin=length*(length-1)/2;
    bin%=MOD;
    bin+=length;
    bin%=MOD;
    return bin;
}

long long f(int M)
{
    long long ret=0;
    int left,right;
    left=0;
    for (int i=0;i<=N;i++)
      {
          if (a[i]>M)
          {
              right=i-1;
              ret+=finterval(left,right);
              ret%=MOD;
              left=i+1;
          }
      }
    return ret;
}

#define SUBTASK2 100007
long long boring[SUBTASK2]={0};

int main()
{
  int maxdosadnost=0;
  cin>>N;

  for (int i=0;i<N;i++)
  {
      scanf("%d",&a[i]);
      if (a[i]>maxdosadnost) maxdosadnost=a[i];
  }

  a[N]=MOD;
  cin>>Q;
  for (int i=0;i<Q;i++)
  {
      if (N<=1000&&maxdosadnost<=100005)
      {
          int val;
          scanf("%d",&val);
          if (val>maxdosadnost) cout<<0<<endl;
          else
          {
              if (boring[val]!=0)
              {
                  printf("%lld\n",boring[val]);
              }
              else
              {
                long long f1=f(val);
                long long f2=f(val-1);
                printf("%d\n",(f1-f2)%MOD);
                boring[val]=(f1-f2)%MOD;
              }
          }
      }
      else
      {
      int val;
      scanf("%d",&val);
      long long f1=f(val);
      long long f2=f(val-1);
      printf("%d\n",(f1-f2)%MOD);
      }
  }

 return 0;
}
