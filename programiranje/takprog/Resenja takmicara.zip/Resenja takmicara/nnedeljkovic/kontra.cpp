#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <memory.h>
using namespace std;

#define NMAX 1005
#define KMAX 1000005
#define INF 10000000
int N,M,K;
bool tree[NMAX][NMAX];
int T[NMAX][NMAX]={0};
int speed[KMAX];
bool posecentragac[NMAX][NMAX]={0};
int skrivenost[NMAX][NMAX];


int main()
{

cin>>N>>M;
for (int i=0;i<N;i++)
{
    getchar();
    char c;
    for (int j=0;j<M;j++)
    {
       c=getchar();
       tree[i][j]=c-'0';
    }
}


/*
for (int i=0;i<N;i++)
{
    for (int j=0;j<M;j++)
    cout<<A[i][j];
    cout<<endl;
}*/

cin>>K;
for (int i=1;i<=K;i++)
{
   int a,b,c;
   scanf("%d%d%d",&a,&b,&c);
   speed[i]=c;
   T[a][b]=i;
}
/*
for (int i=0;i<N;i++)
memset(skrivenost[i],INF,sizeof skrivenost[i]);
*/
//MA MRS
cout<<N<<" "<<M<<endl;

return 0;
}
