#include <iostream>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <stdio.h>
#include <math.h>

using namespace std;

#define NMAX 100005
#define INF 100000000
int powers[10]={1,10,100,1000,10000,100000,1000000,10000000};
int a[NMAX];
int N;
int dp[NMAX]={0};
vector <int> val;
vector <int> pos[NMAX];
int numdigits=0;
int sol=0;

int difference(int a,int b)
{
    if (a%10==b%10)
    return difference(a/10,b/10);
    else
    return abs(a%10-b%10);
}


int main()
{
  cin>>N;
 for (int i=0;i<N;i++)
 {
    scanf("%d",&a[i]);
    val.push_back(a[i]);
 }

 val.push_back(INF);

 int counter=a[0];
while (counter>0)
{
    counter/=10;
    numdigits++;
}
//cout<<numdigits<<endl;
//cout<<difference(a[4],a[5])<<endl;

 sort(val.begin(),val.end());

/*
 for (int i=0;i<val.size();i++)
 cout<<val[i]<<" ";
 cout<<endl;
*/


for (int i=N-1;i>=0;i--)
{
    int value=a[i];
    int position=lower_bound(val.begin(),val.end(),value)-val.begin();
    //cout<<position<<" ";

    for (int j=0;j<pos[position].size();j++)
    {
       int nextpos=pos[position][j];
       int diff=difference(a[nextpos],a[i]);
       if (diff+dp[nextpos]>dp[i]) dp[i]=diff+dp[nextpos];
    }


    int broj,change,pozicija;
    value=a[i];
    for (int j=0;j<numdigits;j++)
    {
        for (int k=0;k<=9;k++)
        {
           if (k!=(value%10))
           {
              change=k-(value%10);
              broj=a[i]+change*powers[j];
              pozicija=lower_bound(val.begin(),val.end(),broj)-val.begin();

              if (val[pozicija]==broj)
               pos[pozicija].push_back(i);
                  //O(N*70*logN) hope to pass atleast 80 pts
           }
        }

        value=value/10;
    }

}

for (int i=0;i<=N-1;i++)
if (dp[i]>sol) sol=dp[i];
cout<<sol<<endl;
return 0;
}































