#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{int n,q;


cin>>n;
int * a;
a=new int[n];
for(int i=0;i<n;i++){cin>>a[i];}


cin>>q;
int * b;
b=new int[q];
for(int i=0;i<q;i++){cin>>b[i];}

unsigned int * l;
l=new unsigned int[n];
unsigned int * d;
d=new unsigned int[n];
for(int i=0;i<n;i++){l[i]=1;d[i]=1;}
for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){if(a[i]>=a[j]){d[i]++;}else break;}
        for(int j=i-1;j>=0;j--){if(a[i]>a[j]){l[i]++;}else break;}
        }
        unsigned long long br;
        for(int i=0;i<q;i++){
                br=0;
                for(int j=0;j<n;j++){
                        if(a[j]==b[i]){br+=l[j]*d[j];br%=1000000007;}
                        }
                        cout<<br<<"\n";
                }
       // for(int i=0;i<n;i++){cout<<l[i]<<" "<<d[i]<<"\n";}
   return 0;
}
