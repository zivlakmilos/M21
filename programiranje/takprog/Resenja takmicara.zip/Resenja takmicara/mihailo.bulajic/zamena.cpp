#include <cstdlib>
#include <iostream>
#include <math.h>
using namespace std;

struct node{
       char val[7];
      int * deca;
       int br;
       
       };
       
       int razlika(char * p, char * q){
           int len=strlen(p);
           for(int i=0;i<len;i++){if(p[i]!=q[i]){return abs(p[i]-q[i]);}}
           return 0;
           }
       
int nadji(int tren,int vrednost,node * a)
{if(a[tren].br==0){return vrednost;}
    else{
    int max=0,lom;
    for(int i=0;i<a[tren].br;i++){
           
            lom=nadji(a[tren].deca[i],vrednost+razlika(a[tren].val,a[a[tren].deca[i]].val),a);
            if(max<lom)
            max=lom;
            }
    
    return max;}
    }

bool provera(char * a,char * b)
{ int br=0;
int z=strlen(a);
    for(int i=0;i<z;i++){if(a[i]!=b[i]){br++;if(br==2){break;}}}
    return br!=2; 
     }


int main(int argc, char *argv[])
{
    
    
  
    int n;
cin>>n;
node * a;
a=new node[n];
for(int i=0;i<n;i++){
        cin>>a[i].val;
        a[i].br=0;
        a[i].deca=new int[n-i];
        for(int j=0;j<i;j++){
                
                if(provera(a[i].val,a[j].val))
                {
                  a[j].deca[a[j].br]=i;
                  a[j].br++;                            
                //zatvorna of if-a
                }
                              //zatvorna od pod-for-a 
                               }
        //zatvorna of unosnog for-a
        }
        bool * pom;
        pom=new bool[n];
        for(int i=0;i<n;i++){pom[i]=false;}
  int max=0;
   unsigned int z;
  for(int i=0;i<n-1;i++){
          if(a[i].br>0&&!pom[i]){
                       for(int j=0;j<a[i].br;j++){pom[a[i].deca[j]]=true;}
                       
                      unsigned int  z=nadji(i,0, a);
                        if(z>max){max=z;}
                        }
          }
  cout<<max;
    
    return 0;
}
