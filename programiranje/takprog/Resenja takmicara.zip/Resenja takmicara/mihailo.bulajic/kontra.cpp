#include <cstdlib>
#include <iostream>

using namespace std;



struct spijun
{
       int x;
       int y;
       int korak;
       };



int main(int argc, char *argv[])
{int n,m,k,br1,br2,brk;
cin>>n>>m;
char a[n][m];

for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
                cin>>a[i][j];
        if(a[i][j]=='1'){a[i][j]='X';}
        }
}

   
    cin>>k;
    spijun s[k];
   
    for(int i=0;i<k;i++){cin>>s[i].x>>s[i].y>>s[i].korak;s[i].x--;s[i].y--;}
    
    char konacna[n][m];
 

for(int i=0;i<n;i++){for(int j=0;j<m;j++){konacna[i][j]=a[i][j];}}
  

unsigned short korx[2000][2],kory[2000][2];



br1=0;
br2=0;

brk=1;
int kop;
if(s[0].x+1<n&&konacna[s[0].x+1][s[0].y]=='0'){korx[br1][0]=s[0].x+1;kory[br1][0]=s[0].y;br1++;konacna[s[0].x+1][s[0].y]='1';}
if(s[0].x-1>=0&&konacna[s[0].x+1][s[0].y]=='0'){korx[br1][0]=s[0].x-1;kory[br1][0]=s[0].y;br1++;konacna[s[0].x-1][s[0].y]='1';}
if(s[0].y+1<m&&konacna[s[0].x][s[0].y+1]=='0'){korx[br1][0]=s[0].x;kory[br1][0]=s[0].y+1;br1++;konacna[s[0].x][s[0].y+1]='1';}
if(s[0].y-1>=0&&konacna[s[0].x][s[0].y-1]=='0'){korx[br1][0]=s[0].x;kory[br1][0]=s[0].y-1;br1++;konacna[s[0].x][s[0].y-1]='1';}

while(br1!=0||br2!=0){
                      kop=brk/s[0].korak+1;
                      br2=0;
                      for(int i=0;i<br1;i++){
                              if(korx[i][0]+1<n&&konacna[korx[i][0]+1][kory[i][0]]=='0'){korx[br2][1]=korx[i][0]+1;kory[br2][1]=kory[i][0];br2++;konacna[korx[i][0]+1][kory[i][0]]=(char)(kop+48);}
                              if(korx[i][0]-1>=0&&konacna[korx[i][0]-1][kory[i][0]]=='0'){korx[br2][1]=korx[i][0]-1;kory[br2][1]=kory[i][0];br2++;konacna[korx[i][0]-1][kory[i][0]]=(char)(kop+48);}
                              if(kory[i][0]+1<m&&konacna[korx[i][0]][kory[i][0]+1]=='0'){korx[br2][1]=korx[i][0];kory[br2][1]=kory[i][0]+1;br2++;konacna[korx[i][0]][kory[i][0]+1]=(char)(kop+48);}
                              if(kory[i][0]-1>=0&&konacna[korx[i][0]][kory[i][0]-1]=='0'){korx[br2][1]=korx[i][0];kory[br2][1]=kory[i][0]-1;br2++;konacna[korx[i][0]][kory[i][0]-1]=(char)(kop+48);}     
                              }
                      br1=0;
                      brk++;
                      kop=brk/s[0].korak+1;
                      for(int i=0;i<br2;i++){
                              
                              if(korx[i][1]+1<n&&konacna[korx[i][1]+1][kory[i][1]]=='0'){korx[br1][0]=korx[i][1]+1;kory[br1][0]=kory[i][1];br1++;konacna[korx[i][1]+1][kory[i][1]]=(char)(kop+48);}
                              if(korx[i][1]-1>=0&&konacna[korx[i][1]-1][kory[i][1]]=='0'){korx[br1][0]=korx[i][1]-1;kory[br1][0]=kory[i][1];br1++;konacna[korx[i][1]-1][kory[i][1]]=(char)(kop+48);}
                              if(kory[i][1]+1<m&&konacna[korx[i][1]][kory[i][1]+1]=='0'){korx[br1][0]=korx[i][1];kory[br1][0]=kory[i][1]+1;br1++;konacna[korx[i][1]][kory[i][1]+1]=(char)(kop+48);}
                              if(kory[i][1]-1>=0&&konacna[korx[i][1]][kory[i][1]-1]=='0'){korx[br1][0]=korx[i][1];kory[br1][0]=kory[i][1]-1;br1++;konacna[korx[i][1]][kory[i][1]-1]=(char)(kop+48);} 
                             
                              }
                      brk++;
                      }  
                    
        /*KRAJ KONSTRUKCIJE OSNOVNE MATRICE*/ 
        
       
        
        char pomocna[n][m];            

               
       
               
       
      for(int j=1;j<k;j++){
             
              for(int i=0;i<n;i++){for(int j=0;j<m;j++){pomocna[i][j]=a[i][j];}}
               br1=1;
               br2=0;
               brk=0;
               korx[0][0]=s[j].x;
               kory[0][0]=s[j].y;
               korx[0][1]=s[j].x;
               kory[0][1]=s[j].y;
               
               
               
               
       while(br1!=0||br2!=0){
                      kop=brk/s[j].korak+1;
                      br2=0;
                      for(int i=0;i<br1;i++){
                              if(korx[i][0]+1<n&&pomocna[korx[i][0]+1][kory[i][0]]=='0'){korx[br2][1]=korx[i][0]+1;kory[br2][1]=kory[i][0];br2++;pomocna[korx[i][0]+1][kory[i][0]]=(char)(kop+48);}
                              if(korx[i][0]-1>=0&&konacna[korx[i][0]-1][kory[i][0]]=='0'){korx[br2][1]=korx[i][0]-1;kory[br2][1]=kory[i][0];br2++;pomocna[korx[i][0]-1][kory[i][0]]=(char)(kop+48);}
                              if(kory[i][0]+1<m&&konacna[korx[i][0]][kory[i][0]+1]=='0'){korx[br2][1]=korx[i][0];kory[br2][1]=kory[i][0]+1;br2++;pomocna[korx[i][0]][kory[i][0]+1]=(char)(kop+48);}
                              if(kory[i][0]-1>=0&&konacna[korx[i][0]][kory[i][0]-1]=='0'){korx[br2][1]=korx[i][0];kory[br2][1]=kory[i][0]-1;br2++;pomocna[korx[i][0]][kory[i][0]-1]=(char)(kop+48);}     
                              }
                      br1=0;
                      brk++;
                      kop=brk/s[j].korak+1;
                      for(int i=0;i<br2;i++){
                              
                              if(korx[i][1]+1<n&&konacna[korx[i][1]+1][kory[i][1]]=='0'){korx[br1][0]=korx[i][1]+1;kory[br1][0]=kory[i][1];br1++;pomocna[korx[i][1]+1][kory[i][1]]=(char)(kop+48);}
                              if(korx[i][1]-1>=0&&konacna[korx[i][1]-1][kory[i][1]]=='0'){korx[br1][0]=korx[i][1]-1;kory[br1][0]=kory[i][1];br1++;pomocna[korx[i][1]-1][kory[i][1]]=(char)(kop+48);}
                              if(kory[i][1]+1<m&&konacna[korx[i][1]][kory[i][1]+1]=='0'){korx[br1][0]=korx[i][1];kory[br1][0]=kory[i][1]+1;br1++;pomocna[korx[i][1]][kory[i][1]+1]=(char)(kop+48);}
                              if(kory[i][1]-1>=0&&konacna[korx[i][1]][kory[i][1]-1]=='0'){korx[br1][0]=korx[i][1];kory[br1][0]=kory[i][1]-1;br1++;pomocna[korx[i][1]][kory[i][1]-1]=(char)(kop+48);} 
                             
                              }
                      brk++;
                      }          
               
                for(int i=0;i<n;i++){for(int j=0;j<m;j++)
                      cout<<pomocna[i][j]<<" ";
                      cout<<"\n";
                      }
               
               for(int i=0;i<n;i++){
                       for(int j=0;j<m;j++){if(pomocna[i][j]<konacna[i][j]){konacna[i][j]=pomocna[i][j];}}
                       }
              
               
               
               
               
               }
               int xkon,ykon;
               char max='0';
               for(int i=0;i<n;i++){
                       for(int j=0;j<m;j++){if(konacna[i][j]!='X'&&konacna[i][j]>max){max=konacna[i][j];xkon=i;ykon=j;}}
                       
                       }
                      cout<<xkon+1<<" "<<ykon+1;    
    
    return 0;
}
