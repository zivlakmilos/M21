#include <stdio.h>
#include <algorithm>

int a[100000], b[100000], vecia[100000], vecib[100000];

int main()
{
    int n,p,q,s=0;
    scanf("%d",&n);
    for(int i=0; i<n; ++i)
    {
        scanf("%d", &a[i]);
    }
    std::sort(a, a+n);
    for(int i=0; i<n; ++i)
    {
        scanf("%d", &b[i]);
    }
    std::sort(b, b+n);
    for(p=0, q=0; p<n && q<n;)
    {
        if(a[p]>b[q])
        {
            vecib[q]=p;
            q++;
        }
        else
        {
            vecia[p]=q;
            ++p;
        }
    }
    if(q==n)
        for(int i=p; i<n; ++i)
            vecia[i]=n;
    if(p==n)
        for(int i=q; i<n; ++i)
            vecib[i]=n;
    for(int i=0; i<n; ++i)
    {
        s+=vecia[i]*a[i]-(n-vecia[i])*a[i]+vecib[i]*b[i]-(n-vecib[i])*b[i];
    }
    printf("%d",s);
    return 0;
}
