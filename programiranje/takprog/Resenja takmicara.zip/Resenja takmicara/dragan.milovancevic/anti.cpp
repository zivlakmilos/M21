#include <stdio.h>

int n1, m[1002][1002], mmin[1002][1002], n2;

void bfs(int x, int y, int v, int t, int i)
{
    if(!(x==n2+2 || x==0 || y==n1+2 || y==0))
    {
        if(t==0)
        {
            ++i;
            t=v;
        }
        --t;
        if(i<m[x+1][y])
        {
           m[x+1][y]=i;
           if(i<mmin[x+1][y])
            mmin[x+1][y]=i;
           bfs(x+1, y, v, t, i);
        }
        if(i<m[x-1][y])
        {
           m[x-1][y]=i;
           if(i<mmin[x-1][y])
            mmin[x-1][y]=i;
           bfs(x-1, y, v, t, i);
        }
        if(i<m[x][y+1])
        {
           m[x][y+1]=i;
           if(i<mmin[x][y+1])
            mmin[x][y+1]=i;
           bfs(x, y+1, v, t, i);
        }
        if(i<m[x][y-1])
        {
           m[x][y-1]=i;
           if(i<mmin[x][y-1])
            mmin[x][y-1]=i;
           bfs(x, y-1, v, t, i);
        }
    }
}

int main()
{
    int k, x, y, max, maxx, maxy, v;
    scanf("%d%d%d", &n1,&n2, &k);
    for(int i=1; i<=n1; ++i)
        for(int j=1; j<=n2; ++j)
        {
            m[i][j]=1001;
            mmin[i][j]=1001;
        }
    for(int i=0; i<k; ++i)
    {
        scanf("%d%d%d",&x,&y,&v);
        mmin[x][y]=0;
        m[x][y]=0;
        bfs(x,y,v,0,0);
        m={{1001}};
    }
    max=0;
    for(int i=1; i<=n1; ++i)
    {
        for(int j=1; j<=n2; ++j)
        {
            if(mmin[i][j]>=max)
            {
                max=mmin[i][j];
                maxx=i;
                maxy=j;
            }
        }
    }
    printf("%d %d",maxx,maxy);
    return 0;
}
