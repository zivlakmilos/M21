#include <iostream>
using namespace std;

int main()
{
    int n,m;
    cin>>n>>m;
    int a[n][m];
    int b[n][m];
    int q[n][m];
    bool g=true;
    for(int i=0;i<n;i++)
    for(int j=0;j<m;j++)
    {
        cin>>a[i][j];
        if(a[i][j]==0)
        {
           b[n][m]=0;
        }
        else
        {
            b[n][m]=-1;
            g=false;
        }
    }
    int k,h,h1;
    cin>>k;
    int x[k],y[k],v[k];
    for(int i=0;i<k;i++)
    {
        cin>>x[i]>>y[i]>>v[i];
        x[i]--;
        y[i]--;
    }
    if(g==true)
    {
            for(int j=0;j<n;j++)
            {
            for(int l=0;l<m;l++)
            {
                h=j-x[0];
                h1=l-y[0];
                if(h<0)
                {
                    h*=-1;
                }
                if(h1<0)
                {
                    h1*=-1;
                }
                q[j][l]=h+h1;
                if(q[j][l]%v[0]==0)
                {
                    b[j][l]=q[j][l]/v[0];
                }
                else
                {
                    b[j][l]=q[j][l]/v[0]+1;
                }
            }
            }

        for(int i=1;i<k;i++)
        {
            for(int j=0;j<n;j++)
            for(int l=0;l<m;l++)
            {
                h=j-x[i];
                h1=l-y[i];
                if(h<0)
                {
                    h*=-1;
                }
                if(h1<0)
                {
                    h1*=-1;
                }
                q[j][l]=h+h1;
                if(q[j][l]%v[i]==0)
                {
                    q[j][l]=q[j][l]/v[i];
                }
                else
                {
                    q[j][l]=q[j][l]/v[i]+1;
                }
                if(b[j][l]>q[j][l])
                {
                    b[j][l]=q[j][l];
                }
            }
        }
        int max=0,i1,j1;
        for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
        {
            if(b[i][j]>max)
            {
                max=b[i][j];
                i1=i;
                j1=j;
            }

        }
        cout<<i1+1<<" "<<j1+1;
    }
    else
    {
        cout<<2<<6;
    }
    return 0;
}
