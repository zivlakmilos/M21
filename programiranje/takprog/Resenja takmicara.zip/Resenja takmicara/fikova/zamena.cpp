#include <iostream>

using namespace std;
int provera(int a,int b)
{
    int x=a,y=b,z=0;
    bool g=false;
    while(x>0)
    {
        if(x%10!=y%10)
        {
            if(g==true)
            {
                return -1;
            }
            else
            {
                if(x-y<0)
                {
                z=y-x;
                }
                else
                {
                z=x-y;
                }
                g=true;
            }
        }
        x/=10;
        y/=10;
    }
    return z;
}
int main()
{
    long int n;
    cin>>n;
    long long int a[n];
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    int max[n];
    for(int i=0;i<n;i++)
    {
        max[i]=0;
    }
    int maxmax=0,k=0;
    for(int i=1;i<n;i++)
        for(int j=i-1;j>=0;j--)
        {
            k=provera(a[i],a[j]);
            if(max[i]<max[j]+k&&k!=-1)
            {
                max[i]=max[j]+k;
            }
            if(maxmax<max[i])
            {
                maxmax=max[i];
            }
        }
        cout<<maxmax;
    return 0;
}
