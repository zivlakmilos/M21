#include <iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int a[n],max=0,desno[n];
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        if(max<a[i])
        {
            max=a[i];
        }
        desno[i]=0;
    }
    int k;
    long long int p[max];
    for(int i=0;i<n;i++)
    {
        p[a[i]]=0;
    }
    cin>>k;
    int b[k];
    for(int i=0;i<k;i++)
    {
        cin>>b[i];
    }
    int x=0,y=0;
    for(int i=0;i<n;i++)
    {
        x=0;
        y=0;
        for(int j=i-1;j>=0;j--)
        {
            if(a[i]>=a[j])
            {
                if(a[i]==a[j])
                {
                    j=-1;
                }
                else
                {
                    x+=desno[j]+1;
                    j-=desno[j];
                }

            }
            else
            {
                j=-1;
            }
        }
        for(int j=i+1;j<n;j++)
        {
                if(a[i]>=a[j])
                {
                    y++;
                }
                else
                {
                    j=n;
                }
        }
        desno[i]=x;
         p[a[i]]+=((x+1)*(y+1))%(1000000007);
    }
    for(int i=0;i<k;i++)
    {
        cout<<p[b[i]];
        if(i!=k-1)
        {
            cout<<"\n";
        }
    }
    return 0;
}
