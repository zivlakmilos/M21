#include <stdio.h>
#include <queue>
#define NMMAX 1000
#define KMAX 1000000
using namespace std;

long int M[NMMAX][NMMAX]; //1 MB

int main()
{
    long int m,n,k,x,y,v,l,b;
    queue<long int> qx,qy,qv,ql,qb;

    scanf("%i%i",&m,&n);

    for (long int i=0;i<m;++i)
        for (long int j=0;j<n;++j)
            scanf("%i",&M[i][j]);

    scanf("%i",&k);
    for (long int i=0;i<k;++i)
    {
        scanf("%i%i%i",&x,&y,&v);
        qx.push(x-1);
        qy.push(y-1);
        qv.push(v);
        ql.push(0);
        qb.push(10);
        M[x-1][y-1]=10;
    }

    while(!qx.empty())
    {
        x=qx.front();
        y=qy.front();
        v=qv.front();
        l=ql.front();
        b=qb.front();
        qx.pop();
        qy.pop();
        qv.pop();
        ql.pop();
        qb.pop();

        if ((x>0)&&((M[x-1][y]==0)||(M[x][y]<M[x-1][y])))
        {
            qx.push(x-1);
            qy.push(y);
            qv.push(v);
            if (l>1)
            {
                ql.push(l-1);
                qb.push(b);
                if ((M[x-1][y]==0)||(M[x][y]<M[x-1][y]))
                    M[x-1][y]=b;
            }
            else
            {
                ql.push(v);
                qb.push(b+1);
                if ((M[x-1][y]==0)||(M[x][y]<M[x-1][y]))
                    M[x-1][y]=b+1;
            }
        }

        if ((x<(m-1))&&((M[x+1][y]==0)||(M[x][y]<M[x+1][y])))
        {
            qx.push(x+1);
            qy.push(y);
            qv.push(v);
            if (l>1)
            {
                ql.push(l+1);
                qb.push(b);
                if ((M[x+1][y]==0)||(M[x][y]<M[x+1][y]))
                    M[x+1][y]=b;
            }
            else
            {
                ql.push(v);
                qb.push(b+1);
                if ((M[x+1][y]==0)||(M[x][y]<M[x+1][y]))
                    M[x+1][y]=b+1;
            }
        }

        if ((y>0)&&((M[x][y-1]==0)||(M[x][y]<M[x][y-1])))
        {
            qx.push(x);
            qy.push(y-1);
            qv.push(v);
            if (l>1)
            {
                ql.push(l-1);
                qb.push(b);
                if ((M[x][y-1]==0)||(M[x][y]<M[x][y-1]))
                    M[x][y-1]=b;
            }
            else
            {
                ql.push(v);
                qb.push(b+1);
                if ((M[x][y-1]==0)||(M[x][y]<M[x][y-1]))
                    M[x][y-1]=b+1;
            }
        }

        if ((y<(n-1))&&((M[x][y+1]==0)||(M[x][y]<M[x][y+1])))
        {
            qx.push(x);
            qy.push(y+1);
            qv.push(v);
            if (l>1)
            {
                ql.push(l-1);
                qb.push(b);
                if ((M[x][y+1]==0)||(M[x][y]<M[x][y+1]))
                    M[x][y+1]=b;
            }
            else
            {
                ql.push(v);
                qb.push(b+1);
                if ((M[x][y+1]==0)||(M[x][y]<M[x][y+1]))
                    M[x][y+1]=b+1;
            }
        }
    }
    long int mm=0;
    x=0;
    y=0;

    for (long int i=0;i<m;++i)
    {
        for (long int j=0;j<n;++j)
        {
            printf("%3i ",M[i][j]);
            if (M[i][j]>mm)
            {
                mm=M[i][j];
                x=j;
                y=i;
            }
        }
        printf("\n");
    }
    printf("%i %i",x+1,y+1);

    return 0;
}

/*
5 7
0 0 1 0 0 0 0
0 1 0 0 0 0 0
0 0 0 0 1 1 0
0 0 0 0 0 0 0
0 0 0 0 0 0 0
2
1 2 3
4 4 1
*/
