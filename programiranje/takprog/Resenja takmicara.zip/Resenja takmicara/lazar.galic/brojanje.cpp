#include <stdio.h>
#include <queue>
using namespace std;
#define ERR -2000000000
#define MOD 1000000007

int D[5000][5000];
int X[5000];
int K[5000];

int main()
{
    int n,k;
    queue<int> qa;
    scanf("%i",&n);

    for (int i=0;i<n;++i)
        scanf("%i",&X[i]);

    scanf("%i",&k);
    for (int i=0;i<k;++i)
    {
        int m;
        scanf("%i",&m);
        qa.push(m);
    }

    for (int i=0;i<n;++i)
        for (int j=i;j<n;++j)
        {
            if (j==i)
                D[i][j]=X[i];
            else
                D[i][j]=(D[i][j-1]>X[j])?D[i][j-1]:X[j];
        }

    int a,b;
    while (!qa.empty())
    {
        a=qa.front();
        qa.pop();
        b=0;

        for (int i=0;i<n;++i)
            for (int j=i;j<n;++j)
                if (D[i][j]==a)
                    ++b;

        printf("%i",b%MOD);
        if (!qa.empty())
            printf("\n");
    }
}
