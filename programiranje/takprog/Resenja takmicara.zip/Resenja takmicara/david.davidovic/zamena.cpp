#include <cstdio>
#include <vector>
#include <map>
#include <algorithm>
#include <cstring>

using namespace std;
#define MAXN				(10*1000)
#define HASH_MODULO			(0x100001)

int EntryLen;
struct entry {
	char a[7];

	bool operator<(const entry& other) const {
		return memcmp(a, other.a, EntryLen) < 0;
	}
};

int dp[MAXN];
entry a[MAXN];

struct cache {
	int pos, b;

	bool operator<(const cache& other) const {
		return (pos == other.pos ? b < other.b : pos < other.pos);
	}
};

map<entry, vector<int> > index;
map<entry, cache> cachedb;

int N;

int binary_search(const vector<int>& vec, int val)
{
	int first = 0, end = vec.size();
	if (val > vec.back())
		return vec.size();

	if (vec.size() == 1) {
		return val <= vec.front() ? 0 : 1;
	}

	while (first < end) {
		int mid = first + (end - first) / 2,
			midv = vec[mid];

		if (val > midv) {
			first = mid + 1;
		} else if (val == midv) {
			return mid;
		} else {
			end = mid;
		}
	}

	return first;
}

int best_for_entry(char *ak, int pos)
{
	entry e;
	memcpy(e.a, ak, EntryLen);

	// O(log N)
	map<entry, vector<int> >::iterator it = index.find(e);
	if (it == index.end()) {
		// no such number
		return -1;
	}

	vector<int> &positions = it->second;

	// O(log N)
	int right_bound = ::binary_search(positions, pos);
	if (right_bound == 0 || (right_bound <= positions.size() - 1 && positions[right_bound] == pos)) {
		// no such number before pos
		return -1;
	}

	// check if we have this in cache
	// O(log N)
	map<entry, cache>::iterator cit = cachedb.find(e);
	cache ce = {-1, 0};
	if (cit != cachedb.end()) {
		ce = cit->second;
	}

	int left_bound;
	if (ce.pos == -1) left_bound = 0;
	// O(log N)
	else left_bound = ::binary_search(positions, ce.pos);

	// Amortized O(N) over the whole execution of the program
	int best = ce.b;
	for (int i = left_bound; i < right_bound && i < positions.size(); ++i) {
		if (dp[positions[i]] > best) {
			best = dp[positions[i]];
		}
	}

	ce.b = best;
	ce.pos = pos;

	// O(log N)
	cachedb[e] = ce;

	return best;
}

int main()
{
	//freopen("Z:\\zamena.in.txt", "r", stdin);
	scanf("%d", &N);
	dp[0] = 0;

	//int kz[] = { 1, 2, 6, 8, 12, 12, 15, 19, 24 };
	//vector<int> kv;
	//kv.resize(sizeof(kz)/sizeof(int));
	//memcpy(&kv.front(), kz, sizeof(kz));

	//int ret;
	//ret = binary_search(kv, 6);
	//ret = binary_search(kv, 0);
	//ret = binary_search(kv, 7);
	//ret = binary_search(kv, 20);
	//ret = binary_search(kv, 24);
	//ret = binary_search(kv, 27);

	char buf[ 16 ];
	scanf("%s", buf);
	EntryLen = strlen(buf);
	memcpy(a[0].a, buf, EntryLen);
	index[a[0]].push_back(0);

	// O(N) input
	for (int i = 1; i < N; ++i) {
		scanf("%s", buf);
		memcpy(a[i].a, buf, EntryLen);

		index[a[i]].push_back(i);
	}

	// O(N log N)
	for (map<entry, vector<int> >::iterator it = index.begin(); it != index.end(); ++it)
		sort(it->second.begin(), it->second.end());

	// O(N) outer loop
	for (int i = 1; i < N; ++i) {
		
		char mutated[7];
		memcpy(mutated, a[i].a, EntryLen);

		int bestb = 0;

		// O(D) inner loop
		bool did_self = false;

		for (int d = 0; d < EntryLen; ++d) {
			// O(9) inner loop
			int olddig = a[i].a[d] - '0';

			for (int newdig = 0; newdig <= 9; ++newdig) {
				if (d == 0 && newdig == 0)
					continue;

				if (olddig == newdig) {
					if (did_self)
						continue;

					did_self = true;
				}

				mutated[d] = newdig + '0';

				int beste = best_for_entry(mutated, i);
				if (beste != -1) {
					int bestf = beste + (newdig > olddig ? newdig - olddig : olddig - newdig);
					if (bestf > bestb) {
						bestb = bestf;
					}
				}

				mutated[d] = olddig + '0';
			}
		}

		dp[i] = bestb;
	}

	int best = 0;
	// O(N)
	for (int i = 0; i < N; ++i) {
		if (dp[i] > best) {
			best = dp[i];
		}
	}

	printf("%d\n", best);
	return 0;
}
