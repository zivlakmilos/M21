#include <cstdio>
#include <map>
#include <set>
#include <vector>

using namespace std;
#define MAXN			1000000
/*
int mymax(int a, int b) {
	if (a>b)return a;else return b;
}

struct seg_node {
	int local_max, start, end;
	seg_node *lchild, *rchild, *parent;
};

seg_node root;*/
int a[MAXN], N;
/*
void build_segtree(seg_node* root, int start, int end)
{
	root->start = start;
	root->end = end;
	
	int mid = (end - start) / 2 + start;

	seg_node* left = new seg_node, *right = new seg_node;
	root->lchild = left;
	root->rchild = right;
	left->parent = right->parent = root;

	build_segtree(left, start, mid);
	build_segtree(right, mid + 1, end);
}

int segtree_max(seg_node* root)
{
	int ret = -1;
	if (root->start == root->end) {
		ret = a[root->start];
	} else {
		if (root->lchild)
			ret = segtree_max(root->lchild);

		if (root->rchild)
			ret = mymax(ret, segtree_max(root->rchild));
	}

	root->local_max = ret;
	return ret;
}

void query_segtree_up_to(int k)
{

}

void query_segtree_down_to(int k)
{

}*/

vector<vector<int> > subsets;
int subsetcount[1000000];

set<int> valueSet;
map<int, int> valueToIdx;//, idxToValue;

int main()
{
	scanf("%d", &N);
	for (int i = 0; i < N; ++i) {
		scanf("%d", &a[i]);
		valueSet.insert(a[i]);
	}

	/*build_segtree(&root, 0, N - 1);
	segtree_max(&root);*/

	int i = 0;
	for (set<int>::iterator it = valueSet.begin(); it != valueSet.end(); ++it) {
		valueToIdx[*it] = i;
		//idxToValue[i] = *it;

		++i;
	}

	for (int start = 0; start < N; ++start) {
		for (int end = start; end < N; ++end) {
			subsets.push_back(vector<int>());
			vector<int> &subset = subsets.back();

			int submax = -1;
			for (int i = start; i <= end; ++i) {
				subset.push_back(a[i]);
				
				if (a[i] > submax) {
					submax = a[i];
				}
			}

			subsetcount[valueToIdx[submax]]++;
		}
	}


	/*subsets.push_back(vector<int>());
	vector<int> &last_sub = subsets.back();
	for (int i = 0; i < N; ++i)
		last_sub.push_back(a[i]);
*/
	int Q;
	scanf("%d", &Q);
	while (Q--) {
		int k;
		scanf("%d", &k);
		k = valueToIdx[k];

		printf("%d\n", subsetcount[k]);
	}

}
