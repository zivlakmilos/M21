#include <iostream>
#include <vector>
#include <cmath>
#define ROF(a, b, c) for(int a = b; a < c; a++)

using namespace std;

int main()
{
    int n;
    vector<int> a;
    vector<int> b;
    long int res = 0;

    cin >> n;

    ROF(i, 0, n)
    {
        int in;
        cin >> in;
        a.push_back(in);
    }

    ROF(i, 0, n)
    {
        int in;
        cin >> in;
        ROF(j, 0, n)
        {
            res += abs(in - a[j]);
        }
    }

    /*ROF(i, 0, n)//n2
    {
        ROF(j, 0, n)
        {
            res += abs(a[i] - b[j]);
        }
    }*/

    cout << res;

    return 0;
}
