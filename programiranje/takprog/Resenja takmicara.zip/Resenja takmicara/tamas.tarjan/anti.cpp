#include <iostream>
#include <cmath>
#include <vector>
#define ROF(a, b, c) for(int a = b; a < c; a++)

using namespace std;

struct trg{
//tragac
    int x, y;
    long long v;
};

int divup(int a, long long& b)
{
    long long a2 = (long long)a;
    long long c = a2 / b;

    if (a2 != b * c)
        c++;

    return c;
}

int main()
{
    int rx, ry;
    int maxturns = 0;

    int n, m, k;
    vector<trg> tragaci;
    vector<vector<int> > park;
    vector<int> dummy(1000, 1000000);
    cin >> n;
    cin >> m;
    cin >> k;

    ROF(i, 0, k)
    {
        trg temp;
        cin >> temp.x;
        cin >> temp.y;
        cin >> temp.v;

        temp.x--;
        temp.y--;

        tragaci.push_back(temp);
    }

    ROF(i, 0, n)
    {
        park.push_back(dummy);
    }

    ROF(i, 0, k)
    {
        int x, y;
        long long v;

        x = tragaci[i].x;
        y = tragaci[i].y;
        v = tragaci[i].v;

        ROF(j, 0, n)
        {
            ROF(z, 0, m)
            {
                int turns = divup(abs(x - j) + abs(y - z), v);

                if (turns < park[j][z])
                {
                    park[j][z] = turns;
                }
            }
        }
    }

/*
    ROF(i, 0, n)
    {
        cout << endl;
        ROF(j, 0, m)
        {
            cout << park[i][j] << " ";
        }
    }
    cout << endl;

*/




    ROF(i, 0, n)
    {
        ROF(j, 0, m)
        {
            if (maxturns < park[i][j])
            {
                maxturns = park[i][j];
                rx = i;
                ry = j;
            }
        }
    }

    rx++;
    ry++;

    cout << rx << " " << ry;

    return 0;
}
