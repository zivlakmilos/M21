#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#define ROF(a, b, c) for(int a = b; a < c; a++)

using namespace std;

bool t_Odd (int a)
{
    if (a % 2 == 0)
    {
        return false;
    }
    else
        return true;

}

void calcCoord(int *x, int *y, int& r, int& s, int n, string& indirs, int& mxf, int& myf)
{
    int mx, my;
    ROF(i, 0, n)
    {
        char dr = indirs[i];

        if (dr == 'L')
        {
            *x -= 1;
        }
        else if (dr == 'R')
        {
            *x += 1;
        }
        else if (dr == 'D')
        {
            *y -= 1;
        }
        else if (dr == 'U')
        {
            *y += 1;
        }
        else
        {
            cout << 'dir error';
            return;
        }


        if (!t_Odd(*x))
        {
            mx = abs(r - *x);
            if (mx < mxf)
            {
                mxf = mx;
            }
        }

        if (!t_Odd(*y))
        {
            my = abs(s - *y);
            if (my < myf)
            {
                myf = my;
            }
        }
    }
    return;
}

int main()
{
    //alg vars
    int xoffset;
    int yoffset;

    int minxoffset = 900000;
    int minyoffset = 900000;

    int a, b;
    //in format vars
    int n;
    int r, s;
    int x = 0;
    int y = 0;
    string indirs;

    cin >> n;
    cin >> r;
    cin >> s;
    cin >> indirs;

  //calcCoord(int *x, int *y, int& r, int& s, int n, string& indirs, int& mxf, int& myf)
    calcCoord(&x, &y, r, s, n, indirs, minxoffset, minyoffset);

    //imas x,y; r,s
    xoffset = abs(x - r);
    yoffset = abs(y - s);

    a =  minxoffset / 2 + minyoffset / 2;
    b = xoffset / 2 + yoffset / 2;

    cout << a << " " << b;

    return 0;
}
