#include <cstdio>
#include <algorithm>

using namespace std;

int dist(int a)
{
    if (a>0) return a;
    else return -a;
}

bool cmp(int a, int b)
{
    return a>b;
}

int find_smaller(int left, int right, int target, int *a)
{
    if (left == right) return left;
    else if (left > right) return -1;
    else
    {
        if (a[(left + right)/2] < target) return find_smaller(left, (left+right)/2,target,a);
        else
        {
            return find_smaller((left+right)/2, right,target,a);
        }
    }
}

int main()
{
    int a[100000], b[100000];
    int n;
    scanf(" %d", &n);
    int i;
    for (i=0; i<n; i++)
    {
        scanf(" %d", &a[i]);
    }
    for (i=0; i<n; i++)
    {
        scanf(" %d", &b[i]);
    }
    sort(a,a+n, cmp);
    sort(b,b+n, cmp);
    if ((a[0] == 0 || a[0] == 1) && (a[n-1] == 0 || a[n-1] == 1)
        && (b[0] == 0 || b[0] == 1) && (b[n-1] == 0 || b[n-1] == 1)
        )
        {
            int p=0,q=0,r=0,s=0;
            for (i=0; i<n; i++)
            {
                if (a[i] == 0) p++;
                if (a[i] == 1) q++;
                if (b[i] == 0)r++;
                if (b[i] == 1)s++;
            }
            //printf("%d %d %d %d\n",p,q,r,s);
            printf("%d\n", q*r+p*s);
        }
    else
    {
        int sum = 0;
        for (i=0; i<n; i++)
        {
            for (int j = 0; j<n; j++)
            {
                sum += dist(a[i] - b[j]);
            }
        }
        printf("%d", sum);
    }
    return 0;
}
