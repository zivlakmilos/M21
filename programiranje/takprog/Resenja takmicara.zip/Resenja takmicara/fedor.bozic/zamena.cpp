#include<iostream>

using namespace std;

int main(void)
{
    int i,j;
    int n;
    cin >> n;

    int a[n];
    int b[n];
    int zbir[n];
    int sum=0;
    int tmp1,tmp2;

    for(i=0;i<n;i++)
    {
        cin >> a[i];
        zbir[i] = 0;
    }

    for(i=0;i<n;i++)
    {
        cin >> b[i];
    }

    /*for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(a[j]>=b[j])
            {
            zbir[i] = zbir[i] + a[j] - b[j];
            }
            else
            {
                zbir[i] = zbir[i] + b[j] - a[j];
            }
        }

        tmp1 = a[0];
        for(j=1;j<=n;j++)
        {
            tmp2 = a[j%n];
            a[j%n] = tmp1;
            tmp1 = tmp2;
            cout << a[j%n] << " ";
        }
    }*/

    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(a[i]>=b[j])
            {
            zbir[i] = zbir[i] + a[i] - b[j];
            //cout << "V:" << zbir[i] << endl;
            }
            else
            {
                zbir[i] = zbir[i] + b[j] - a[i];
                //cout << "M" << zbir[i] << endl;
            }
        }
    }

    for(i=0;i<n;i++)
    {
        sum+=zbir[i];
    }
    cout << sum;

    return 0;
}

/*
3
4 2 8
2 7 3
*/
