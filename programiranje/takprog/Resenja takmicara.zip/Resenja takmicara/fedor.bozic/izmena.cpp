#include<iostream>
#include<math.h>

using namespace std;

bool nadjen(char a[], int r, int s,int n)
{
    int i;
    int x,y;
    x=0;
    y=0;
    for(i=0;i<n;i++)
    {
        if(a[i] == 'R')
        {
            x++;
            if(x==r && y==s)
            {
                return true;
            }
        }
        else if(a[i] == 'L')
        {
            x--;
            if(x==r && y==s)
            {
                return true;
            }
        }
        else if(a[i] == 'U')
        {
            y++;
            if(x==r && y==s)
            {
                return true;
            }
        }
        else if(a[i] == 'D')
        {
            y--;
            if(x==r && y==s)
            {
                return true;
            }
        }
    }
    return false;
}

int pomerajx(char smer, int x)
{
    if(smer == 'R')
    {
        x=x+1;
        return x;
    }
    if(smer == 'L')
    {
        x=x-1;
        return x;
    }
}

int pomerajy(char smer, int y)
{
    if(smer == 'U')
    {
        y=y+1;
        return y++;
    }
    if(smer == 'D')
    {
        y=y-1;
        return y--;
    }
}
int main(void)
{
    int n,r,s;
    int i;
    int x,y;
    double mindaljina;
    int minx;
    int miny;
    int mini=0;
    int promene = 0;
    char rx,ry;
    cin >> n;
    cin >> r;
    cin >> s;

    char a[n];

    for(i=0;i<n;i++)
    {
        cin >> a[i];
    }

    mindaljina = sqrt(r*r + s*s);
    minx=0;
    miny=0;
    x=0;
    y=0;
    for(i=0;i<n;i++)
    {
        if(a[i] == 'R')
        {
            x++;
            if((double)sqrt((r-x)*(r-x)+(s-y)*(s-y))<mindaljina)
            {
                mindaljina = (double)sqrt((r-x)*(r-x)+(s-y)*(s-y));
                minx = x;
                miny = y;
                mini = i;
            }
        }
        else if(a[i] == 'L')
        {
            x--;
            if((double)sqrt((r-x)*(r-x)+(s-y)*(s-y))<mindaljina)
            {
                mindaljina = (double)sqrt((r-x)*(r-x)+(s-y)*(s-y));
                minx = x;
                miny = y;
                mini = i;
            }
        }
        else if(a[i] == 'U')
        {
            y++;
            if((double)sqrt((r-x)*(r-x)+(s-y)*(s-y))<mindaljina)
            {
                mindaljina = (double)sqrt((r-x)*(r-x)+(s-y)*(s-y));
                minx = x;
                miny = y;
                mini = i;
            }
        }
        else if(a[i] == 'D')
        {
            y--;
            if((double)sqrt((r-x)*(r-x)+(s-y)*(s-y))<mindaljina)
            {
                mindaljina = (double)sqrt((r-x)*(r-x)+(s-y)*(s-y));
                minx = x;
                miny = y;
                mini = i;
            }
        }
    }

    /*cout << mindaljina << endl;
    cout << minx << endl;
    cout << miny;*/

    if(minx<r)
    {
        rx = 'R';
    }
    else if(minx==r)
    {
        rx = 'J';
    }
    else
    {
        rx = 'L';
    }

    if(miny<s)
    {
        ry = 'U';
    }
    else if(miny==s)
    {
        ry = 'J';
    }
    else
    {
        ry = 'D';
    }

    /*cout << minx << endl;
    cout << miny << endl;
    cout << rx << " " << ry << endl;*/
    for(i=mini;i<n;i++)
    {
        if(nadjen(a,r,s,n))
        {
            //cout << "1" << endl;
            break;
        }
        else if(minx == r)
        {
            //cout << "2" << endl;
            rx = 'J';
        }
        else if(miny == s)
        {
            //cout << "3" << endl;
            ry = 'J';
        }
        if((a[i] == 'R' || a[i] == 'L') && rx == 'J' && ry!='J')
        {
            //cout << "4" << endl;
            a[i] = ry;
            promene++;
            miny = pomerajy(a[i],miny);
            //cout << "X:" << minx << "Y:" << miny << endl;
        }
        else if((a[i] == 'U' || a[i] == 'D') && ry == 'J' && rx!='J')
        {
            //cout << "5" << endl;
            a[i] = rx;
            promene++;
            minx = pomerajx(a[i],minx);
            //cout << "X:" << minx << "Y:" << miny << endl;
        }
        else if((a[i]!=rx || a[i]!=ry) && rx!='J' && ry!='J')
        {
            //cout << "6" << endl;
            a[i] = rx;
            promene++;
            minx = pomerajx(a[i],minx);
            //miny = pomerajy(a[i],miny);
            //cout << "X:" << minx << "Y:" << miny << endl;
        }
    }

    /*for(i=0;i<n;i++)
    {
       cout << a[i];
    }
    cout << endl;*/
    cout << promene << endl;

    return 0;
}
/*
6 0 2
RRRRRR

13 3 -4
UURRRDUUDRLLL
*/
