#include<iostream>

using namespace std;

int a[1000][1000];

void koraci(int a[1000][1000],int n, int m, int xi, int yi, int vi, int potezi, int brk)
{
    if(potezi < a[xi][yi] && a[xi][yi] != -1)
    {
        a[xi][yi] = potezi;
    }
    else if(a[xi][yi] == -1)
    {
        a[xi][yi] = potezi;
    }

    if(brk<vi)
    {
        if(xi+1<n)
        {
            koraci(a,n,m,xi+1,yi,vi,potezi,brk+1);
        }
        if(yi+1<m)
        {
            koraci(a,n,m,xi,yi+1,vi,potezi,brk+1);
        }
        if(xi-1>=0)
        {
            koraci(a,n,m,xi-1,yi,vi,potezi,brk+1);
        }
        if(yi-1>=0)
        {
            koraci(a,n,m,xi,yi-1,vi,potezi,brk+1);
        }
    }
}

int main(void)
{
    int i,j;
    int n,m,k;
    int maxi;
    int maxx,maxy;
    cin >> n;
    cin >> m;
    cin >> k;

    long long vi[k];
    int xi[k];
    int yi[k];

    for(i=0;i<k;i++)
    {
        cin >> xi[i];
        cin >> yi[i];
        cin >> vi[i];
    }

    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            a[i][j] = -1;
        }
    }

    for(i=0;i<10;i++)
    {
        for(j=0;j<10;j++)
        {
            koraci(a,n,m,xi[i],yi[i],vi[i],j,0);
        }
    }
    cout << 2 << endl;
    maxi = 0;
    maxx;
    maxy;
    for(i=0;i<1000;i++)
    {
        for(j=0;j<1000;j++)
        {
            if(maxi>a[i][j])
            {
                maxi = a[i][j];
                maxx = i;
                maxy = j;
            }
        }
    }

    cout << maxx << endl;
    cout << maxy << endl;

    return 0;
}

/*
5 7 2
1 2 3
4 4 1
*/
