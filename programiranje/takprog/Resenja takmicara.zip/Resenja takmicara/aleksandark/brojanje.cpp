#include <cstdio>
#include <algorithm>
#include <map>

#define MODDD 1000000007

using namespace std;

long n, q, i, j;
long a[1000000], b[1000000], dl[1000000], dd[1000000], qa[1000000], br[1000000];
map<long,long> m;

int main()
{
    //Upis
    scanf("%ld", &n);
    for(i = 0; i < n; i++)
    {
        scanf("%ld", &a[i]);
        b[i] = a[i];
    }

    scanf("%ld", &q);
    for(i = 0; i < q; i++) scanf("%ld", &qa[i]);

    //Mapa
    sort(b, b+n);

    int k = 0;
    m[b[0]] = k++;
    br[m[b[0]]] = 0;

    for(i = 1; i < n; i++)
    if(b[i] > b[i-1])
    {
        m[b[i]] = k;
        br[m[b[i]]] = 0;
        k = k + 1;
    }
    //for(int i = 0; i < n; i++) printf("%ld ", m[a[i]]);

    //Rad
    dl[0] = dd[n-1] = 0;
    for(i = 1; i < n; i++)
    {
        for(j = i-1; j >= 0; j--) if(a[j] > a[i]) break;
        dl[i] = i - j - 1;
    }
    for(i = n-2; i >= 0; i--)
    {
        for(j = i+1; j < n; j++) if(a[j] > a[i]) break;
        dd[i] = j - i - 1;
    }

    for(i = 0; i < n; i++)
    {
        long x, y;
        x = dl[i] + 1;
        y = dd[i] + 1;
        //printf("%ld+%ld\n", br[m[a[i]]] % MODDD,(((x % MODDD)*(y % MODDD)) % MODDD));
        br[m[a[i]]]= (br[m[a[i]]] % MODDD) + (((x % MODDD)*(y % MODDD)) % MODDD);
    }

    long res = 0;
    for(i = 0; i < q; i++)
    {
        if(binary_search(b, b+n, qa[i])) res = br[m[qa[i]]];
        else res = 0;

        if(i == q-1) printf("%ld", res);
        else printf("%ld\n", res);
    }

    return 0;
}
