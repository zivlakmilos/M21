#include <cstdio>

#define KORAK 1
#define BRZINA 2

long a[1002][1002], v[1002][1002];
long b[1002][1002], v1[1002][1002];
long n, m, z, i ,j, ti, tj, tv;
char s[1001];

long kalk(long i, long j)
{
    if((!v[i][j]) || (a[i][j] == -1)) return -1;
        return (   (a[i][j] + 1) / v[i][j]   );
}

bool manje(long x, long y)
{
    if(x < 0) return 0;
    if(y < 0) return 1;
    return x < y;
}

int main()
{

    //Ulaz
    scanf("%ld %ld", &n, &m);

    for(i = 0; i <= n+1; i++)
        a[i][0] = a[i][m+1] = -1;

    for(j = 1; j < m+1; j++)
        a[0][j] = a[n+1][j] = -1;

    for(i = 1; i <= n; i++)
    {
        scanf("%s", s);
        for(j = 1; j <= m; j++)
        {
            a[i][j] = (s[j-1] - '0');
            if(a[i][j] == 1) a[i][j] = -1;
            v[i][j] = 0;
        }
    }

    scanf("%ld", &z);
    for(i = 0; i < z; i++)
    {
        scanf("%ld %ld %ld", &ti, &tj, &tv);
        //printf("%ld %ld %ld\n", ti, tj, tv);
        v[ti][tj] = tv;
        //printf("%d\n", v[ti][tj]);
    }

    //Rad

    //Dole-desno
    long left, top; //topleft;
    for(i = 1; i <= n; i++)
    for(j = 1; j <= m; j++)
    if((a[i][j] != -1) && (!v[i][j]))
    {
        left = kalk(i, j-1);
        top = kalk(i-1, j);
        //topleft = kalk(i-1, j-1);

        long minnn = left; v[i][j] = v[i][j-1]; a[i][j] = a[i][j-1];
        if(manje(top, minnn))
            { minnn= top; v[i][j] = v[i-1][j]; a[i][j] = a[i-1][j];}
        /*if(manje(topleft, minnn))
            { minnn= topleft; v[i][j] = v[i-1][j-1]; a[i][j] = a[i-1][j-1];}*/
            if(minnn == -1) a[i][j] = -2;
            else if (minnn >= 0) a[i][j]++;
    }

    //Gore-levo
    long right, bottom; //bottomright;
    for(i = n; i >= 1; i--)
    for(j = m; j >= 1; j--)
    if((a[i][j] != -1))
    {
        right = kalk(i, j+1);
        bottom = kalk(i+1, j);
        //bottomright = kalk(i+1, j+1);

        long minnn = right; v1[i][j] = v[i][j+1]; b[i][j] = a[i][j+1];
        if(manje(bottom, minnn))
            { minnn= bottom; v1[i][j] = v[i+1][j]; b[i][j] = a[i+1][j];}
        /*if(manje(bottomright, minnn))
            { minnn= bottomright; v1[i][j] = v[i+1][j+1]; b[i][j] = a[i+1][j+1];}*/
            if(minnn > -1) b[i][j]++;

        if(manje(b[i][j], a[i][j]))
        {
            a[i][j] = b[i][j];
            v[i][j] = v1[i][j];
        }
    }

    long max_i = 1, max_j = 1, maksimum = 0;

    //Izlaz
    for(i = 1; i <= n; i++)
    {
        for(j = 1; j <= m; j++)
        if(v[i][j])
        if(a[i][j]/v[i][j] > maksimum)
        {
            max_i = i;
            max_j = j;
            maksimum = a[i][j]/v[i][j];
        }
    }

    printf("%d %d", max_i, max_j);

    return 0;
}
