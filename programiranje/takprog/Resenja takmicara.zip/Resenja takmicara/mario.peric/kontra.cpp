#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;

int N, M;
int K;
long long V[1000005];
int X[1000005], Y[1000005];
int rast[1000005];
int putic[1005][1005];
bool P[1000][1000];

int maksimum(int A[])
{
    int m = A[0];
    int i;
    for (i = 0; i < K; i++)
        if (A[i] < m)
            m = A[i];
    return m;
}

int abs(int x)
{
    return x > 0 ? x : -x;
}

int rastojanje(int x1, int y1, int x2, int y2)
{
    return abs(x1 - x2) + abs(y1 - y2);
}

int findMax(int A[][1005])
{
    int m = A[0][0];
    int i, j;
    for (i = 0; i < N; i++)
        for (j = 0; j < M; j++)
            if (A[i][j] > m)
                m = A[i][j];
    return m;
}

int main()
{
    int i, j;
    int x, y;
    char* a = 0;
    scanf("%d %d",&N, &M);
    for (i = 0; i < N; i++) {
        scanf("%s",&a);
    }
    scanf("%d",&K);
    for (i = 0; i < K; i++)
    {
        scanf("%d %d %lld",&X[i], &Y[i], &V[i]);
        X[i]--;
        Y[i]--;
    }

     for (x = 0; x < N; x++)
        for (y = 0; y < M; y++)
        {
            for (i = 0; i < K; i++)
                rast[i] = rastojanje (x,y,X[i],Y[i]) / V[i];
            putic[x][y] = maksimum(rast);
        }
    int m = findMax(putic);
    bool be = true;
    for (x = 0; x < N && be; x++)
        for (y = 0; y < M && be; y++)
            if (putic[x][y] == m)
            {
                printf("%d %d", x + 1, y + 1);
                be = false;
            }
    return 0;
}
