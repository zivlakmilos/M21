#include <iostream>
#include <stdio.h>

using namespace std;

int N, Q;
long long Z[1000005];
long long k;

int main()
{
    int i, j, c, g;
    long long br;
    bool imaBr, nemaVeci;
    scanf("%d", &N);
    for (i = 0; i < N; i++)
        scanf("%lld", &Z[i]);
    scanf("%d", &Q);
    for (g = 0; g < Q; g++)
    {
        scanf("%d", &k);
        br = 0;
        for (i = 0; i < N; i++)
            for (j = i; j < N; j++)
            {
                imaBr = false;
                nemaVeci = true;
                for (c = i; c <= j; c++)
                {
                    if (imaBr || Z[c] == k)
                        imaBr = true;
                    if (Z[c] > k)
                        nemaVeci = false;
                }
                if (nemaVeci && imaBr)
                    br++;
            }
        printf("%lld", br % 1000000007);
    }

    return 0;
}
