#include <iostream>
#include <stdio.h>
#include <math.h>

using namespace std;

int N;
long long A[10000005];
int bod[10000005];

int abs(int x)
{
    return x >= 0 ? x : -x;
}

int jednaCifra(long long x, long long y)
{
    int brCif = 0, raz = 0;
    while(x != 0 && y != 0)
    {
        if (x % 10 != y % 10)
        {
            brCif++;
            raz += abs (x % 10 - y % 10);
        }
        x = x / 10;
        y = y / 10;
    }
    return brCif == 1 ? raz : 0;
}

int pokusaj (long long n, int p)
{
    if (p < N)
    {
        if (!jednaCifra(n, A[p]))
        {
            return pokusaj(n,p+1);
        }
        else
        {
            int a = jednaCifra(n, A[p]) + pokusaj(A[p], p+1);
            int b = pokusaj(n, p+1);
            return max(a,b);
        }
    }
    return 0;


}

int maksimum(int A[])
{
    int m = A[0];
    int i;
    for (i = 0; i < N; i++)
        if (A[i] > m)
            m = A[i];
    return m;
}

int main()
{
    int i;
    scanf("%d", &N);
    for (i = 0; i < N; i++)
        scanf("%lld", &A[i]);
    for (i = 0; i < N; i++)
        bod[i] = pokusaj(A[i], i);
    printf("%d", maksimum(bod));
    return 0;
}
