#include <cstdio>
#include <cstdlib>
#include <algorithm>

const int pow10[8] = {1, 10, 100, 1000, 10000, 100000, 1000000, 10000000};

#define _timesx(i,s,x) for(int i = s; i < x; i++)
#define _times(i,x) _timesx(i,0,x)

using namespace std;

int delta(int a, int b)
{
    if (a == b) return 0;
    if (a < b) return delta(b,a);
    int c = a - b;
    while (c % 10 == 0) c /= 10;
    if (c > 10) return -1;
    return c;
}

int _gd(int z, int k)
{
    return (z/pow10[k])%10;
}

int get_len(int a)
{
    if (a < 10) return 1;
    return get_len(a/10) + 1;
}

int dp[100005];
int a[100005];

int cif[7][10];

void ins_cif(int z, int len)
{
    _times(i, len)
    {
        int* k = &cif[i][_gd(a[z],i)];
        if (*k == -1 || dp[*k] < dp[z])
        {
            *k = z;
        }
    }
}

int main()
{
    int N;
    scanf("%i", &N);
    _times(i, N)
    {
        scanf("%i", &a[i]);
    }

    if (a[0] < 10)
    {
        int t = a[0];
        int sum = 0;
        _timesx(i, 1, N)
        {
            sum += t < a[i] ? a[i] - t : t - a[i];
            t = a[i];
        }
        printf("%i", sum);
        return 0;
    }

    int len = get_len(a[0]);

    _times(i, len) _times(j, 10)
    {
        cif[i][j] = -1;
    }

    _times(i, N)
    {
        int mscore = 0;
        _times(j, len)
        {
            int& k = cif[j][_gd(a[i],j)];
            if (k != -1)
            {
                int x = delta(a[k], a[i]);
                if (x == -1)
                    mscore = max(mscore, 0);
                else
                    mscore = max(mscore, dp[k] + x);
            }
        }
        dp[i] = mscore;
        ins_cif(i, len);
    }
    int mx = 0;
    _times(i, N)
    {
        mx = max(mx, dp[i]);
    }
    printf("%i", mx);

    return 0;
}
