#include <cstdio>

using namespace std;

#define _times(i,x) for(int i = 0; i < x; i++)

const int mod = 1e9 + 7;

int d[1000005];

int main()
{
    int N;
    scanf("%i", &N);
    _times(i, N)
    {
        scanf("%i", &d[i]);
    }
    int Q;
    scanf("%i", &Q);
    _times(i, Q)
    {
        int k;
        scanf("%i", &k);
        int lastg = -1;
        int cr = 0;
        int sum = 0;
        _times(j, N)
        {
            if (d[j] > k)
            {
                lastg = j;
                cr = 0;
            }
            else if (d[j] == k)
            {
                cr = j-lastg;
                sum += cr;
            }
            else
            {
                sum += cr;
            }
            sum %= mod;
        }
        printf("%i\n", sum);
    }
    return 0;
}
