#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <queue>
#include <vector>

using namespace std;

#define _times(i,x) for(int i = 0; i < x; i++)

int divup(int a, int b)
{
    if (a%b == 0)
        return a/b;
    else
        return (a-(a%b))/b + 1;
}

int in[1005][1005];
int skr[1005][1005], vmax[1005][1005];

struct A
{
    int x, y, d, v, k;
    A(int a, int b, int c, int x, int y) : x(a), y(b), d(c), v(x), k(y) {}
};

int main()
{
    int N=1000, M=1000;
    _times(i, 1005) _times(j,1005)
    {
        skr[i][j] = 10000006;
        vmax[i][j] = -1;
    }
    //srand(17);
    scanf("%i %i", &N, &M);
    _times(i, N) _times(j, M)
    {
        char c;
        do
            scanf("%c", &c);
        while (c != '1' && c != '0');
        in[i][j] = c == '1' ? 1 : 0;
        //in[i][j] = 0;
    }
    int K = 100000;
    scanf("%i", &K);
    queue <A> q;
    vector< vector< vector<int> > > cur = vector< vector< vector<int> > >(K, vector< vector<int> > (N, vector<int>(M, 0)));
    _times(i, N)
        _times(j, M)
            if (in[i][j] == 1)
                _times(k, K)
                    cur[k][i][j] = 1;
    _times(i, K)
    {
        //int px = 1 + rand() % N, py = 1 + rand() % M, v = 1 + rand() % 10;
        int px, py, v;
        scanf("%i %i %i", &px, &py, &v);
        q.push(A(px - 1, py - 1, 0, v, i));
        cur[i][px-1][py-1] = 1;
    }

    while (!q.empty())
    {
        A l = q.front();
        q.pop();

        vmax[l.x][l.y] = max(vmax[l.x][l.y], l.v);

        if (skr[l.x][l.y] >= divup(l.d, l.v))
        {
            skr[l.x][l.y] = divup(l.d, l.v);
        }
        else if (vmax[l.x][l.y] >= l.v)
        {
            continue;
        }

        if (l.x > 0 && cur[l.k][l.x - 1][l.y] == 0)
        {
            cur[l.k][l.x-1][l.y] = 1;
            q.push(A(l.x-1, l.y, l.d+1, l.v, l.k));
        }
        if (l.x < N-1 && cur[l.k][l.x+1][l.y] == 0)
        {
            cur[l.k][l.x+1][l.y] = 1;
            q.push(A(l.x+1, l.y, l.d+1, l.v, l.k));
        }
        if (l.y > 0 && cur[l.k][l.x][l.y-1] == 0)
        {
            cur[l.k][l.x][l.y-1] = 1;
            q.push(A(l.x, l.y-1, l.d+1, l.v, l.k));
        }
        if (l.y < M-1 && cur[l.k][l.x][l.y+1] == 0)
        {
            cur[l.k][l.x][l.y+1] = 1;
            q.push(A(l.x, l.y+1, l.d+1, l.v, l.k));
        }
    }

    int _m = -1, _x = -1, _y = -1;
    _times(i, N)
    {
        _times(j, M)
        {
            if (_m < skr[i][j] && skr[i][j] != 10000006)
            {
                _m = skr[i][j];
                _x = i+1;
                _y = j+1;
            }
        }
    }
    printf("%i %i", _x, _y);
    return 0;
}
/*
5 7
0010000
0100000
0000110
0000000
0000000
2
1 2 3
4 4 1
*/
