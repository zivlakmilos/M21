#include <iostream>
#include <stdio.h>
using namespace std;

long int abs(long int num){
    return num >= 0 ? num : -num;
}

int main()
{
    long int A[100001];
    long int B[100001];
    long int N;
    cin >> N;

    for(long int i = 0; i<N; i++)
        scanf("%ld", &A[i]);
    for(long int i = 0; i<N; i++)
        scanf("%ld", &B[i]);
    long long int sumM = 0;
    long long int sum = 0;
    for(long int i = 0; i<N; i++){
        sum = 0;
        for(long int j = i; j< i + N; j++){
            sum+=abs(B[i] - A[j % N]);
        }
        sumM += sum;
    }
    cout << sumM;
    return 0;
}
