#include <iostream>
#include <stdio.h>

#define inf  500005

using namespace std;

inline long int abs(long int num){
    return num >= 0 ? num : -num;
}

long int rCnt = 0, lCnt = 0, uCnt = 0, dCnt = 0;
long int x, y;
long int diffX;
long int diffY;
long int N;
long int r;
long int s;
void calc(){
    x = rCnt - lCnt;
    y = uCnt - dCnt;
    diffX = r - x;
    diffY = s - y;
    return;
}
long int leadToSameDiff(){
    long int toChange = 0;
    long int cost = 0;
    if(abs(diffX) == abs(diffY)) return 0; //Nema potrebe za promenom
    if(abs(abs(diffX) - abs(diffY)) % 2 != 0)    return inf; //Ne moze da radi
    if(abs(diffX) > abs(diffY)){
        //mora da se menja po X osi
        toChange = abs(abs(diffX) - abs(diffY)) / 2;
        if(diffX < 0){
            //mora da se ide levo
            if(toChange > rCnt) return inf;
            rCnt -= toChange;
            lCnt += toChange;
        } else {
            //mora da se ide desno
            if(toChange > lCnt) return inf;
            lCnt -= toChange;
            rCnt += toChange;
        }
    } else {
        //mora da se menja po Y osi
        toChange = abs(abs(diffX) - abs(diffY)) / 2;
        if(diffY < 0){
            //mora da se ide dole
            if(toChange > uCnt) return inf;
            uCnt -= toChange;
            dCnt += toChange;
        } else {
            //mora da se ide desno
            if(toChange > dCnt) return inf;
            dCnt -= toChange;
            uCnt += toChange;
        }
    }
    calc();
    return toChange;
}

long int leadFromSameDiffDouble(){
    long int toChange = abs(diffX) / 2;
    if(diffX == 0 && diffY == 0) return 0;
    //Pronadji maximum vrednosti toChange
    if(diffX < 0){
        //mora da se ide levo
        if(toChange > rCnt) toChange = rCnt;
    } else {
        //mora da se ide desno
        if(toChange > lCnt) toChange = lCnt;
    }

    if(diffY < 0){
        //mora da se ide dole
        if(toChange > uCnt) toChange = uCnt;
    } else {
        //mora da se ide gore
        if(toChange > dCnt) toChange = dCnt;
    }


    //iskoristi tu vrednos'
    if(diffX < 0){
        //mora da se ide levo
        rCnt-=toChange;
        lCnt+=toChange;
    } else {
        //mora da se ide desno
        lCnt-=toChange;
        rCnt+=toChange;
    }

    if(diffY < 0){
        //mora da se ide dole
        uCnt-=toChange;
        dCnt+=toChange;
    } else {
        //mora da se ide gore
        uCnt+=toChange;
        dCnt-=toChange;
    }
    calc();
    return toChange * 2;
}
long int leadFromSameDiffSimple(){
    long int toChange = abs(diffX);
    if(diffX == 0) return 0;
    if(diffX < 0 && diffY < 0){
        //Mora da se ide levo - dole => menjaj desne sa dole ili gornje sa levo
        if(rCnt + uCnt < toChange) return inf;
    } else if(diffX < 0 && diffY > 0){
        //Mora da se ide levo - gore => menjaj desne sa gore ili donje sa levo
        if(rCnt + dCnt < toChange) return inf;
    } else if(diffX > 0 && diffY < 0){
        //Mora da se ide desno - dole => menjaj leve sa dole ili gornje sa desno
        if(lCnt + uCnt < toChange) return inf;
    } else if(diffX > 0 && diffY > 0){
        //Mora da se ide desno - gore => menjaj leve sa gore ili donje sa desno
        if(lCnt + dCnt < toChange) return inf;
    }
    return toChange;
}

long int CalcMinCost2(){
    long int cost = leadToSameDiff();
    if(cost == inf) return inf;
    //idi prema rsu u krupnim koracima:
    cost += leadFromSameDiffDouble();
    long int tmp = leadFromSameDiffSimple();
    if(tmp == inf) return inf;
    cost += tmp;

    //cout << cost << "        " << rCnt <<" " << lCnt << " "<<uCnt << " "<<dCnt << " " << diffX << " " << diffY << endl;
    return cost;
}

int main()
{

    scanf("%ld %ld %ld ", &N, &r, &s);
    char tmp;
    long int brCnt = 0, blCnt = 0, buCnt = 0, bdCnt = 0;
    long int minCost = inf;
    long int tmpA;
    for(long int i = 0; i < N; i++){
        scanf("%c", &tmp);

        switch(tmp){
            case 'R':
                brCnt++;
                break;
            case 'L':
                blCnt++;
                break;
            case 'U':
                buCnt++;
                break;
            case 'D':
                bdCnt++;
                break;
            default:
                printf("NE VALJA VAM TEST FAJL. Ili sam negde pogresio...");
                return 0;
                break;

        }
        rCnt = brCnt;
        lCnt = blCnt;
        uCnt = buCnt;
        dCnt = bdCnt;
        calc();
        tmpA = CalcMinCost2();
        if(tmpA < minCost) minCost = tmpA;
        //CalcMinCost2();
    }
    rCnt = brCnt;
    lCnt = blCnt;
    uCnt = buCnt;
    dCnt = bdCnt;
    cout << minCost << " " << tmpA;
    return 0;
}
