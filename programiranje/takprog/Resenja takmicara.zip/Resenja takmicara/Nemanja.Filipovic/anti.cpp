#include <stdio.h>
#include <iostream>
using namespace std;

#define inf 1000000001
long long int mestaSkrivanja[1001][1001];
int N, M, K;
int xMax, yMax;
int maxV = 0;
void init(){
    for(int x = 0; x < N; x++)
        for(int y = 0; y < M; y++)
            mestaSkrivanja[x][y] = inf;

}
void debugOut(){
    for(int x = 0; x < N; x++){
        for(int y = 0; y < M; y++)
            cout << mestaSkrivanja[x][y];
        cout << endl;
    }
}

void searchMax(){
    for(int x = 0; x < N; x++)
        for(int y = 0; y < M; y++){
            if(mestaSkrivanja[x][y] > maxV){
                xMax = x;
                yMax = y;
                maxV = mestaSkrivanja[x][y];
            }
        }
}
void runSearcher(int xi, int yi, long long int left, long long int step, long long int origLeft){

    if(xi < 0 || xi > N || yi < 0 || yi > M) return;
    if(left == 0) {
        step++;
        left = origLeft;
    }
    if(step <= mestaSkrivanja[xi][yi]){
        mestaSkrivanja[xi][yi] = step;
    } else return;


    runSearcher(xi - 1, yi, left - 1, step, origLeft);
    runSearcher(xi + 1, yi, left - 1, step, origLeft);
    runSearcher(xi, yi - 1, left - 1, step, origLeft);
    runSearcher(xi, yi + 1, left - 1, step, origLeft);


    return;
}
void startRecursion(int xi, int yi, long long int origLeft){
    mestaSkrivanja[xi][yi] = 0;
    runSearcher(xi - 1, yi, origLeft, 1, origLeft);
    runSearcher(xi + 1, yi, origLeft, 1, origLeft);
    runSearcher(xi, yi - 1, origLeft, 1, origLeft);
    runSearcher(xi, yi + 1, origLeft, 1, origLeft);
    return;
}

int main(){
    scanf("%d %d %d", &N, &M, &K);
    init();
    long long int vi;
    int xi, yi;
    for(int i = 0; i<K; i++){
        scanf("%d %d", &xi, &yi);
        cin >> vi;
        startRecursion(xi - 1,yi - 1,vi);

    }
    searchMax();
    //debugOut();
    cout << xMax+1 << " " << yMax+1;
    return 0;
}
