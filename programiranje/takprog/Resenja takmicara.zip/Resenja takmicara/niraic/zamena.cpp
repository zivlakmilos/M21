#include <iostream>
#include <cstdio>
using namespace std;
int slicnost(int a,int b)
{
    int k=a-b;
    if(k<0)k*=-1;
    while(k%10==0 && k!=0)k/=10;
    return k;
}
int ubacicifru(int a,int k,int brc,int c)//ubacuje cifru c na mjesto k
{
    int l=a;
int t=1;
for(int i=0;i<brc-k;i++)
t*=10;
a/=t;
a=a-(a%10);
a+=c;
a*=t;
a+=l%t;
return a;
}
int b1[1000000];
int c1[1000000];
int main()
{
    int n;
    int a[100010];
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
    scanf("%d",&a[i]);
    }
    if(n<=1000)
    {
        int maxx=0;
        int b[1010];
        b[n-1]=0;
        for(int i=n-2;i>=0;i--)
        {
            int maks=0;
            for(int j=i+1;j<n;j++)
            {
               if(slicnost(a[i],a[j])<=9)
               {
                   if(maks<slicnost(a[i],a[j])+b[j])
                   maks=slicnost(a[i],a[j])+b[j];
               }
            }
            b[i]=maks;
            if(maks>maxx)maxx=maks;
        }
        cout<<maxx;
    }
    if(a[0]<10 && n>=1000)
    {
        int suma=0;
        for(int i=0;i<n-1;i++)
        suma+=slicnost(a[i],a[i+1]);
        cout<<suma;
    }
    if(a[0]<100 && a[0]>=10 && n>1000)
    {
        for(int r=0;r<100;r++)b1[r]=-1;
        int k=2;//broj cifara
        c1[n-1]=0;
        b1[a[n-1]]=n-1;
        int makss=0;
        for(int i=n-2;i>=0;i--)
        {
            int maks=0;
            for(int j=1;j<=k;j++)
            {
                for(int w=0;w<10;w++)
                {
                    if(w!=0 || j!=1)
                    {
                  int f=ubacicifru(a[i],j,k,w);
                   if(b1[f]!=-1 && maks<slicnost(a[i],a[b1[f]])+c1[b1[f]])
                   maks=slicnost(a[i],a[b1[f]])+c1[b1[f]];
                    }
                }
            }
            c1[i]=maks;
            b1[a[i]]=i;
            if(maks>makss)makss=maks;
        }
        cout<<makss;
    }
    if(a[0]<1000 && a[0]>=100 && n>1000)
    {
        for(int r=0;r<1000;r++)b1[r]=-1;
        int k=3;//broj cifara
        c1[n-1]=0;
        b1[a[n-1]]=n-1;
        int makss=0;
        for(int i=n-2;i>=0;i--)
        {
            int maks=0;
            for(int j=1;j<=k;j++)
            {
                for(int w=0;w<10;w++)
                {
                    if(w!=0 || j!=1)
                    {
                  int f=ubacicifru(a[i],j,k,w);
                   if(b1[f]!=-1 && maks<slicnost(a[i],a[b1[f]])+c1[b1[f]])
                   maks=slicnost(a[i],a[b1[f]])+c1[b1[f]];
                    }
                }
            }
            c1[i]=maks;
            b1[a[i]]=i;
            if(maks>makss)makss=maks;
        }
        cout<<makss;
    }
    if(a[0]<10000 && a[0]>=1000 && n>1000)
    {
        for(int r=0;r<10000;r++)b1[r]=-1;
        int k=4;//broj cifara
        c1[n-1]=0;
        b1[a[n-1]]=n-1;
        int makss=0;
        for(int i=n-2;i>=0;i--)
        {
            int maks=0;
            for(int j=1;j<=k;j++)
            {
                for(int w=0;w<10;w++)
                {
                    if(w!=0 || j!=1)
                    {
                  int f=ubacicifru(a[i],j,k,w);
                   if(b1[f]!=-1 && maks<slicnost(a[i],a[b1[f]])+c1[b1[f]])
                   maks=slicnost(a[i],a[b1[f]])+c1[b1[f]];
                    }
                }
            }
            c1[i]=maks;
            b1[a[i]]=i;
            if(maks>makss)makss=maks;
        }
        cout<<makss;
    }
    if(a[0]<100000 && a[0]>=10000 && n>1000)
    {
        for(int r=0;r<100000;r++)b1[r]=-1;
        int k=5;//broj cifara
        c1[n-1]=0;
        b1[a[n-1]]=n-1;
        int makss=0;
        for(int i=n-2;i>=0;i--)
        {
            int maks=0;
            for(int j=1;j<=k;j++)
            {
                for(int w=0;w<10;w++)
                {
                    if(w!=0 || j!=1)
                    {
                  int f=ubacicifru(a[i],j,k,w);
                   if(b1[f]!=-1 && maks<slicnost(a[i],a[b1[f]])+c1[b1[f]])
                   maks=slicnost(a[i],a[b1[f]])+c1[b1[f]];
                    }
                }
            }
            c1[i]=maks;
            b1[a[i]]=i;
            if(maks>makss)makss=maks;
        }
        cout<<makss;
    }
    if(a[0]<1000000 && a[0]>=100000 && n>1000)
    {
        for(int r=0;r<1000000;r++)b1[r]=-1;
        int k=6;//broj cifara
        c1[n-1]=0;
        b1[a[n-1]]=n-1;
        int makss=0;
        for(int i=n-2;i>=0;i--)
        {
            int maks=0;
            for(int j=1;j<=k;j++)
            {
                for(int w=0;w<10;w++)
                {
                    if(w!=0 || j!=1)
                    {
                  int f=ubacicifru(a[i],j,k,w);
                   if(b1[f]!=-1 && maks<slicnost(a[i],a[b1[f]])+c1[b1[f]])
                   maks=slicnost(a[i],a[b1[f]])+c1[b1[f]];
                    }
                }
            }
            c1[i]=maks;
            b1[a[i]]=i;
            if(maks>makss)makss=maks;
        }
        cout<<makss;
    }
    return 0;
}
