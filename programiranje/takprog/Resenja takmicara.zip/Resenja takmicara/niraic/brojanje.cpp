#include <iostream>

using namespace std;

int main()
{
    int n,q;
    cin >> n;
    int a[100000];
    for(int i=0;i<n;i++)
    cin>>a[i];
    cin>>q;
    if(n<=1000)
    {
      int brojevi[1100];
      for(int i=0;i<1001;i++)brojevi[i]=0;
      for(int i=0;i<n;i++)
      {
          int maks=0;
          for(int k=0;i+k<n;k++)
          {
              if(a[i+k]>maks)
              maks=a[i+k];
              brojevi[maks]=(brojevi[maks]+1)%1000000007;
          }
      }
      for(int i=0;i<q;i++)
      {
          int k;
          cin>>k;
          if(k>1000)cout<<0;
          else cout<<brojevi[k];
          cout<<"\n";
      }
    }
    return 0;
}
