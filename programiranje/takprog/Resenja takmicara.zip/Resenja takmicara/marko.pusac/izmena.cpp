#include <iostream>
#include <iomanip>
#include <cstdio>
#include <string>
#include <math.h>

using namespace std;

int main()
{
    int n,r,s,i;
    string q;
    
    cin>>n>>r>>s;
    cin>>q;
    
    int z,min=999999,x=0,y=0;
    
    for(i=0;i<n;i++)
    {
                    switch(q[i])
                    {
                                case 'U':y+=1;break;
                                case 'R':x+=1;break;
                                case 'L':x-=1;break;
                                case 'D':y-=1;break;
                                default: break;
                    }
                    z=abs(x-r)+abs(y-s);
                    
                    if(z<min)
                    {
                             min=z;
                    }
    }
    
    int a,b;
    
    a=min/2+1;
    b=z/2;
    
    cout<<a<<" "<<b;
    
    system("PAUSE");
    
    return 0;
    
    
}
