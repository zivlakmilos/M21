#include <iostream>
#include <iomanip>
#include <cstdio>

using namespace std;

int a[100001];
int b[100001];
int a1[1000001]={0};
int b1[1000001]={0};
int x[1000001]={0};
int k1[1000001]={0};

int main()
{
    int i,n,max=0;
    long long int z=0;
    
    cin>>n;
    
    for(i=0;i<n;i++)
    {
                    cin>>a[i];
    }
    
    for(i=0;i<n;i++)
    {
                    cin>>b[i];
    }
    
    for(i=0;i<n;i++)
    {
                    ++a1[a[i]];
                    ++b1[b[i]];
    }
    
    for(i=0;i<n;i++)
    {
                    if(a[i]>max)
                                max=a[i];
    }
    
    for(i=0;i<n;i++)
    {
                    if(b[i]>max)
                                max=b[i];
    }
    
    
    k1[0]=b1[0];
    
    for(i=1;i<=max;i++)
    {
                    x[i]=x[i-1]+b1[i]*i;
                    k1[i]=k1[i-1]+b1[i];
    }

    
    
    for(i=0;i<=max;i++)
    {
       if(a1[i]>0)
       {
                    z+=((x[max]-x[i])-(k1[max]-k1[i])*i)*a1[i];
                    if(i>0 && k1[i-1]>0)
                           z+=(k1[i-1]*i-x[i-1])*a1[i];
       }
                    
    }
    
    cout<<z;
    
    system("PAUSE");
    
    return 0;
}

