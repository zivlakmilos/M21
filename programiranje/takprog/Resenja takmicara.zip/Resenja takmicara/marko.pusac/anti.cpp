#include <iostream>
#include <iomanip>
#include <cstdio>
#include <math.h>

using namespace std;

int main()
{
    int n,m,k,i,j,r;
    double max1=99999999,max2=0,z;
    int a[1000],b[1000],v[1000];
    
    cin>>n>>m>>k;
    
    for(i=0;i<k;i++)
    {
                    cin>>a[i]>>b[i]>>v[i];
    }
    
    int g,h;
    
    for(i=1;i<=n;i++)
    {
                    for(j=1;j<=m;j++)
                    {
                                    for(r=0;r<k;r++)
                                    {
                                            z=abs(a[r]-i)+abs(b[r]-j);
                                            z=double(z/v[r]);
                                            if(z<=max1)
                                            {
                                                     max1=z;
                                            }
                                    }
                                    if(max1>=max2)
                                    {
                                                 g=i;
                                                 h=j;
                                    }
                    }
    }
    
    cout<<g<<" "<<h;
    
    
    system("PAUSE");
    return 0;
    
}
