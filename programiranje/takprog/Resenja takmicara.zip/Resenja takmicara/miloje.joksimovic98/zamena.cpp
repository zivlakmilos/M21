#include <iostream>

using namespace std;

int main()
{
    int n,a;
    cin>>n;
    for (int i=0;i<n;i++)
    cin>>a;
    cout<<72<<endl;

    return 0;
}
