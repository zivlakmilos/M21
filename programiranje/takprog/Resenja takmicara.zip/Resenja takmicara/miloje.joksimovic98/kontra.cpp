#include <iostream>
#include <cstdio>
#include <queue>

using namespace std;
int a[1002][1002];
int n,m;
int k;
queue <int> q;

int min(int a,int b)
{
   if (a>b) return b;
   return a;
}
int mark[1002][1002];
int main()
{
    cin>>n>>m;
    char c;
    for (int i=1;i<=n;i++)
    for (int j=1;j<=m;j++)
    {
        cin>>c;
        if (c=='1') a[i][j]=-1;
        else a[i][j]=0;
    }
    for (int i=1;i<=n;i++)
    for (int j=1;j<=m;j++) mark[i][j]=0;
    int sol;
    cin>>k;
    int x,y,v;
    int vreme;
    for (int l=0;l<k;l++)
    {
        cin>>x>>y>>v;
        int tmpx=x;
        int tmpy=y;
        q.push(x);q.push(y);q.push(0);
        static int X[4]={1,-1,0,0};
        static int Y[4]={0,0,1,-1};
        while(!q.empty())
        {
        x=q.front();q.pop();
        y=q.front();q.pop();
        vreme=q.front();q.pop();
        if (x>=1 && x<=n && y>=1 && y<=m && a[x][y]>=0 && mark[x][y]<l+1)
        {
            mark[x][y]=l+1;
            if (a[x][y]==0) a[x][y]=(1+(vreme-1)/v);
            else a[x][y]=min(a[x][y],(1+(vreme-1)/v));
        for (int i=0;i<4;i++)
        {
          q.push(x+X[i]);
          q.push(y+Y[i]);
          q.push(vreme+1);
        }
        }

    }
    a[tmpx][tmpy]=-1;
    }
    sol=-5;
    int indi,indj;
    for (int i=1;i<=n;i++)
    for (int j=1;j<=m;j++)
        if (a[i][j]>sol)
        {
            sol=a[i][j];
            indi=i;indj=j;
        }
    cout<<indi<<" "<<indj<<endl;

    return 0;
}
