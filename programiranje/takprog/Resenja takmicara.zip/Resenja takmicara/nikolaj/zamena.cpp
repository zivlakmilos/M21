//RandomUsername(Nikola Jovanovic)
//Drzavno 2015
//A

#include <bits/stdc++.h>
#define MAXN 100005
#define MAXNUM 10000005

using namespace std;

int n;
//int a[MAXN];
int ai;
int len;

int pom;
int deg;
int ret;
int currdp, olddp;
int diff;
int currcif;
int currnum;

//map<int, int> DP;
//or
int DP[MAXNUM];

// unordered_map :(
// logn factor -> TLE ? :(
// 1e7 hash table -> MLE ? :(
// full feedback pls

// hash table works SO MUCH faster
// 1e7 ints + 1e6 ints = 44MB, might work
// no full feedback => possible 0pts

int main()
{
    //freopen("inn.txt","r",stdin);

    //Input
    scanf("%d", &n);

    //ID len?

    ret = 0;
    len = 0;
    for(int i=1; i<=n; i++) //DP[i]
    {
       scanf("%d", &ai);
       if(i == 1)
       {
            pom = ai;
            while(pom > 0)
            {
               len++;
               pom /= 10;
            }
       }
       currdp = 0;
       deg = 1;
       currnum = ai;
       for(int j=0; j<len; j++) //each position
       {
           currcif = currnum % 10;
           currnum /= 10;
           for(int k=0; k<=9; k++) //change!
           {
               //kobasicenje

               pom = ai - currcif * deg + k * deg; //new num

               olddp = DP[pom]; //old dp

               diff = k - currcif;
               if(diff < 0) diff *= -1;

               //cout<<i<<" "<<j<<" "<<k<<" "<<pom<<" "<<olddp<<endl;

               if(olddp == -1 && diff > currdp)
               {
                   //-1 <=> present as a starting position
                   currdp = diff;
               }
               if(olddp > 0 && olddp + diff > currdp)
               {
                   //>0 <=> present
                   currdp = olddp + diff;
               }

           }
           deg *= 10;
       }
       if(currdp == 0) currdp = -1; // present as a starting position
       DP[ ai ] = currdp; //enter

       ret = max(ret, currdp); //ret is the global max
    }
    printf("%d\n", ret);
    return 0;
}
