//RandomUsername(Nikola Jovanovic)
//Drzavno 2015
//C

#include <bits/stdc++.h>
#define MAXN 1005
#define par pair<int, int>
#define fi first
#define se second
#define lld long long

using namespace std;

bool ok[MAXN][MAXN];
int d[MAXN][MAXN];
bool vis[MAXN][MAXN];
char s[MAXN];
bool allEq;
int n, m, k;
int glv;

struct drot
{
  int i, j, v;

};

drot b[MAXN*MAXN];
queue<par> q;

bool okk(int i, int j)
{
    if(i<0 || j<0 || i>n || j>m) return false;
    if(!ok[i][j]) return false;
    if(vis[i][j]) return false;
    return true;
}

void BFS()
{
    while(!q.empty())
    {
        par curr = q.front();
        q.pop();
       // cout<<curr.fi<<" "<<curr.se<<" "<<d[curr.fi][curr.se]<<endl;
        if(okk(curr.fi + 1, curr.se))
        {
                d[curr.fi + 1][curr.se] = d[curr.fi][curr.se] + 1;
                vis[curr.fi+1][curr.se] = true;
                q.push(par(curr.fi+1, curr.se));
        }
        if(okk(curr.fi - 1, curr.se))
        {
                d[curr.fi - 1][curr.se] = d[curr.fi][curr.se] + 1;
                vis[curr.fi-1][curr.se] = true;
                q.push(par(curr.fi-1, curr.se));
        }
        if(okk(curr.fi, curr.se+1))
        {
                d[curr.fi][curr.se+1] = d[curr.fi][curr.se] + 1;
                vis[curr.fi][curr.se+1] = true;
                q.push(par(curr.fi, curr.se+1));
        }
        if(okk(curr.fi, curr.se-1))
        {
                d[curr.fi][curr.se-1] = d[curr.fi][curr.se] + 1;
                vis[curr.fi][curr.se-1] = true;
                q.push(par(curr.fi, curr.se-1));
        }
    }
}

int cntFree;

int main()
{
    //zlo
    cntFree = 0;
    allEq = true;
    scanf("%d %d", &n, &m);
    for(int i=1; i<=n; i++)
    {
        scanf("%s", s+1);
        for(int j=1; j<=m; j++)
        {
            if(s[j] == '1')
                ok[i][j] = false;
            else
                {ok[i][j] = true; cntFree++;}
        }
    }
    scanf("%d", &k);
    for(int i=1; i<=k; i++)
    {
        scanf("%d %d %d", &b[i].i, &b[i].j, &b[i].v);

        d[b[i].i][b[i].j] = 0;
        vis[b[i].i][b[i].j] = true;
        q.push(par(b[i].i, b[i].j));

        if(i>1 && b[i].v != b[i-1].v)
            allEq = false;
    }
    glv = b[1].v;
    if(allEq)
    {
        BFS();
        int ret = -1;
        par res;
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=m; j++)
            {
                //cout<<d[i][j];
                if(d[i][j] > ret)
                {
                    ret = d[i][j];
                    res.fi = i;
                    res.se = j;
                }
            }
           // cout<<endl;
        }
        printf("%d %d\n", res.fi, res.se);
        //printf("%d %d\n", (ret-1)/glv + 1);
    }
    else if(k == cntFree)
    {
        printf("%d %d\n", b[1].i, b[1].j);
    }
    else
    {
        printf("%d %d\n", n, m);
    }

    return 0;
}
