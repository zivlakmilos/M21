//RandomUsername(Nikola Jovanovic)
//Drzavno 2015
//B

#include <bits/stdc++.h>
#define MAXN 1000005
#define MOD 1000000007
#define lld long long

using namespace std;

struct dat //data
{
     int val;
     int l; //closest left GOE
     int r; //closest right G
};

int n;
int q, qq;
dat ass[MAXN];
map<int, int> sol;
lld old;

struct pqdat //data for priority queue
{
    int idx;
    int val;
    pqdat(int IDX, int VAL)
    {
        idx = IDX;
        val = VAL;
    }
};

struct cmp
{
    bool operator() (const pqdat a, const pqdat b)
    const
    {
        return a.val > b.val; //min PQ by val
    }
};

priority_queue<pqdat, vector<pqdat>, cmp> pq;

void CalcL() //closest left GOE
{
    for(int i=n; i>=1; i--)
    {
        while(!pq.empty() && pq.top().val <= ass[i].val)
        {
            ass[ pq.top().idx ].l = i;
            pq.pop();
        }
        pq.push( pqdat(i, ass[i].val) );
    }
    while(!pq.empty())
    {
        ass[ pq.top().idx ].l = 0;
        pq.pop();
    }
}

void CalcR() //Closest right G
{
    for(int i=1; i<=n; i++)
    {
        while(!pq.empty() && pq.top().val < ass[i].val)
        {
            ass[ pq.top().idx ].r = i;
            pq.pop();
        }
        pq.push( pqdat(i, ass[i].val) );
    }
    while(!pq.empty())
    {
        ass[ pq.top().idx ].r = n + 1;
        pq.pop();
    }
}

lld p2plus(lld a)
{
    return a * (a+1);
}

lld getNum(lld l, lld i, lld r)
{
    // (r-1-l) ^ 2 / 2 - (i-1-l) ^ 2 / 2 - (r - i) ^ 2 / 2
    lld ret = ( ( p2plus(r - 1 - l) - p2plus(i - 1 - l) - p2plus(r - 1 - i) ) / 2 ) % MOD;
    return ret; //voodoo magic
}

void PrecomputeSols()
{
    for(int i=1; i<=n; i++)
    {
       old = sol[ ass[i].val ];
       old += getNum(ass[i].l, i, ass[i].r);
       old %= MOD;
       sol[ ass[i].val ] = (int)old;
    }
}

//O(nlogn + qlogn), maxn = maxq = 1e6, good enough

int main()
{
   // freopen("in.txt","r",stdin);
    //Input
    scanf("%d", &n);
    for(int i=1; i<=n; i++)
    {
        scanf("%d", &ass[i].val);
    }
    //closest left GOE
    CalcL();

    //closest right G
    CalcR();

    //calc
    PrecomputeSols();

    //Queries
    scanf("%d", &q);
    for(int i=1; i<=q; i++)
    {
        scanf("%d", &qq);
        printf("%d\n", sol[qq]);
    }

    return 0;
}
