#include <iostream>
#include <stdio.h>
#include <map>
#define MAXN 1000005

using namespace std;
int n,q;
int a[MAXN],b[MAXN];
map<int, int> res;
int mat[1005][1005];
bool pos[1005][1005];
int req(int x, int y)
{
    if(pos[x][y])
        return mat[x][y];
    pos[x][y]=1;
    if(x==y)
    {
        mat[x][y]=a[x];
        return a[x];
    }
    mat[x][y]=max(a[x], req(x+1,y));
    return mat[x][y];
}
void init()
{
    for(int i=0;i<n;i++)
    for(int j=i;j<n;j++)
    {
        res[req(i,j)]++;
    }
}
int main()
{
    scanf("%d", &n);
    for(int i=0;i<n;i++)
        scanf("%d", &a[i]);
    scanf("%d", &q);
    for(int i=0;i<q;i++)
        scanf("%d", &b[i]);
    init();
    for(int i=0;i<q;i++)
        printf("%d\n", res[b[i]]);
    return 0;
}
/*
5
1 2 3 4 3
3
2
3
4
*/
