#include <iostream>
#include <stdio.h>

using namespace std;
int n, a[100005], k,pov=1;
int mat[100005][7];
int pov10[7]={1,10,100,1000,10000,100000,1000000};
int dp[9000005];
bool pos[9000005];
void kek(int i)
{
    int t=a[i];
    for(int j=0;j<k;j++)
    {
        int c=t%10;
        t/=10;
        mat[i][k-j-1]=c;
    }
}
int abso(int x)
{
    if(x<0)
        x*=-1;
    return x;
}
void init ()
{
    for(int i=0;i<n;i++)
        kek(i);
    int t;
    for(int i=0;i<n;i++)
    {
        t=dp[a[i]-pov];
        for(int j=0;j<k;j++)
        {
            for(int l=0;l<10;l++)
            {
                if(j==0&&l==0)
                    continue;
                int pom=a[i]-(mat[i][j]-l)*pov10[k-j-1]-pov;
                //cout<<pom<<endl;

                if(pos[pom])
                {
                    dp[a[i]-pov]=max(dp[a[i]-pov],dp[pom]+abso(mat[i][j]-l));
             //       cout<<mat[i][j]<<endl;
                }
                pos[a[i]-pov]=1;
            }
        }
    }
}
int main()
{
  //  freopen("out.txt","r",stdin);
    scanf("%d", &n);
    for(int i=0;i<n;i++)
        scanf("%d", &a[i]);
    int t=a[0];
    while (t>0)
    {
        t/=10;
        k++;
        pov*=10;
    }
    pov=(pov+9)/10;
    if(pov==1)
    {
        int res=0;
        for(int i=1;i<n;i++)
            res+=abso(a[i]-a[i-1]);
        cout<<res;
        return 0;
    }
    init();
    int max1=0;
    //cout<<k;
    for(int i=0;i<n;i++)
    {
       // if(dp[a[i]-pov]>0)
         //   cout<<i<<" "<<dp[a[i]-pov]<<endl;
        max1=max(max1,dp[a[i]-pov]);
       // if(dp[i]>0)
       // cout<<i<<" "<<dp[i]<<endl;
    }

    cout<<max1;

    return 0;
}
/*
6
8823
2145
2185
3385
4145
4445
*/
