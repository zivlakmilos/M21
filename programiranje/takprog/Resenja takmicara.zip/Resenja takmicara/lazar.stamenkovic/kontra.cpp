#include<cstdio>
int mat[1000][1000],n,m,i,j,k;
char ma[1000][1000];
void napravi(int x,int y,int v,int u)
{
    int c;
    if(u==0) c=0;
    else c=(u-1)/v +1;
    mat[x][y]=c;
    //if(x-1>-1) printf("itwork");
    //if((mat[x-1][y] > (u % v))||(mat[x-1][y]==-2)) printf("itwork");

    if((x-1>-1)&&((mat[x-1][y] > c)||(mat[x-1][y]==-2))&&(mat[x-1][y]!=-1)) {napravi(x-1,y,v,u+1);}
    if((y-1>=0)&&((mat[x][y-1]>c)||(mat[x][y-1]==-2))&&(mat[x][y-1]!=-1)) napravi(x,y-1,v,u+1);
    if((x+1<n)&&((mat[x+1][y]>c)||(mat[x+1][y]==-2))&&(mat[x+1][y]!=-1)) napravi(x+1,y,v,u+1);
    if((y+1<m)&&((mat[x][y+1]>c)||(mat[x][y+1]==-2))&&(mat[x][y+1]!=-1)) napravi(x,y+1,v,u+1);
}

int main()
{
    scanf("%d%d",&n,&m);
    for(i=0;i<n;i++) scanf("%s\n",&ma[i]);
    for(i=0;i<n;i++)
    for(j=0;j<m;j++) {
            if(ma[i][j]=='1') mat[i][j]=-1;
            else mat[i][j]=-2;
    }
    //napravi(0,1 ,3,0);
    /*for(i=0;i<n;i++) {
    for(j=0;j<m;j++) printf("%d ",mat[i][j]);
   // printf("%d",0%3);
    printf("\n");
}*/
    int x,y,v;
    scanf("%d",&k);
    for(i=0;i<k;i++)
    {
        scanf("%d%d%d",&x,&y,&v);
        napravi(x-1,y-1,v,0);
    }
    int maxx=0,w=0,q=0;
    for(i=0;i<n;i++)
        for(j=0;j<m;j++) if(mat[i][j]>maxx) {maxx=mat[i][j];w=i;q=j;}
    printf("%d %d",w+1,q+1);
   /* for(i=0;i<n;i++) {
    for(j=0;j<m;j++) printf("%d ",mat[i][j]);
   // printf("%d",0%3);
    printf("\n");
}*/
}
