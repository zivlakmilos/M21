#include<cstdio>
#include<algorithm>
#include<cstdlib>
using namespace std;
inline int uporedi(int a,int b)
{
    int i=0,c=0,x,y;
    bool f=true;
    while(a>9)
    {
        x=a % 10;
        y=b % 10;
        c+=abs(x-y);
        if(x!=y) i++;
        a=a/10;
        b=b/10;
    }
    c+=abs(a-b);
    if(a!=b) i++;
    if(i<2) return c;
    return 0;
}
int main()
{
    int n,x[100000],k[100000]={0},i,j;
    scanf("%d",&n);
    for(i=0;i<n;i++) scanf("%d",&x[i]);
    k[n-1]=0;
    for(i=n-2;i>=0;i--)
        for(j=i+1;j<n;j++)
    {
        //printf("it-works");
        if(uporedi(x[i],x[j]))
        if(k[i]<k[j]+uporedi(x[i],x[j])) k[i]=k[j]+uporedi(x[i],x[j]);
    }
    //printf("%d",k[4]);
    /* printf("%d ",k[i]);
    printf("%d",uporedi(x[4],x[2]));*/
    int maxx=0;
    for(i=0;i<n;i++) if(maxx<k[i]) maxx=k[i];
    printf("%d",maxx);
    return 0;
}
