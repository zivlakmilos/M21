#include <iostream>
#include <string>

using namespace std;

long long a[10000][10000];
long long n;
long long abs (long long x)
{
if (x<0) return -x;
return x;
}
long long razlika (string s1, string s2){
    long long suma = 0;
    unsigned int i = 0;
    int brojp = 0;
    while (i<s1.length())
    {
    if ((brojp !=0) && (s1[i]-s2[i]!=0)) return -1;
        if ((brojp == 0) && (s1[i]-s2[i]!=0))
        {suma +=abs(s1[i]-s2[i]);
        brojp ++;}
        i++;
    }
    return suma;
}

long long maxrow (long long index)
{
long long j=index+1;
long long max=0;
long long pom = 0;
//cout<<"in "<<index;
    while (j<n)
    {
        if (a[index][j] > -1) { pom = a[index][j] + maxrow (j); if (pom>max) max = pom;}
        j++;
    }
    return max;
}

int main()
{
    cin>>n;
    string s[n];
    for(long long i = 0; i<n; i++)
        cin>>s[i];
for (int i = 0 ; i<n; i++)
    for (int j=0; j<n; j++)
        a[i][j] = razlika(s[i],s[j]);

/*for (int i = 0 ; i<n; i++) {
    for (int j=0; j<n; j++)
        cout<<a[i][j]<<" ";
        cout<<endl;
        }*/
long long max = 0, pom = 0;
for (int i = 0 ; i<n; i++)
    {
        pom = maxrow(i);
        if (pom > max) max = pom;
    }
cout<<max;

    return 0;
}
