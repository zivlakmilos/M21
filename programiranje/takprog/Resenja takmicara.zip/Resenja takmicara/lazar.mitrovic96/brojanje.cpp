#include <iostream>
#include <algorithm>
using namespace std;

long long n;
long long q;
long long k;
long long x;
long long prevx;
int sum = 0;
long long brmanj=1;
long long a[1000001],b[1000001];
long long find_n(long long vrd,long long prs)
{
    for (long long i=prs; i<n; i++)
        {
        if ((a[i]==vrd)) {return i;}
        }
        return -1;
}
long long trcilevo(long long index)
{
    long long brojac=1;
    long long j = index-1;
    while ((j>=0) && (a[j] < a[index])) {brojac ++; j--;}
    return brojac;
}
long long trcidesno (long long index)
{
    long long brojac=0;
    long long j = index+1;
    while ((j<n) && (a[j] <= a[index])) {brojac ++; j++;}
    return brojac;
}
long long trci( long long index)
{
    return  (trcilevo(index) * (trcidesno(index)+1));

}
int main()
{
    cin>>n;
    for (long long i = 0; i<n; i++)
        cin>>a[i];
    for (long long i = 0; i<n; i++)
        {b[i] = trci(i); /*cout<<b[i]<<endl;*/}
    cin>>q;
    for (long long i = 0; i<q; i++)
        {
        cin>>k;
        sum = 0;
        x = find_n(k,0);
        while(x!=-1)
            {
            sum+=b[x];
            x = find_n(k,x+1);
            }
            cout<<sum<<endl;
        }


    return 0;
}
