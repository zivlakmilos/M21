#include <bits/stdc++.h>
typedef long long ll;
using namespace std;





//palindromske sekvence su mi upropastile resenje
//ff@20

const ll MOD=1e9+7;
const int N=1e6+10;

int a[N], n, q;
int sleva[N], sdesna[N]; //broj manjih sa leve i desne strane
int maxbr;

bool p;

pair<int,int> maxLeva[N], maxDesna[N];
int nLevo, nDesno;

//************//
map<int, ll> sol; //za svaki broj upisuje resenje; radim queriovavavavavanje
//***********//

int bsLevo (int br)
{
    int ret=-1;
    int l=0, d=nLevo-1, mid;
    while (l<=d)
    {
        mid=(l+d)/2;
        if (maxLeva[mid].first<br) d=mid-1; //br je veci od mida, trazim veci
        else if (maxLeva[mid].first>br) //br je manji od mida, trazim prvi veci;
        {
            ret=mid;
            l=mid+1;
        }
        else if (maxLeva[mid].first==br)
        {
            //postoji isti broj
            p=true;
            ret=mid;
            break;
        }
    }
    return ret; //pozicija od lokalnog max
}

int bsDesno (int br)
{
    int ret=-1;
    int l=0, d=nDesno-1, mid;
    while (l<=d)
    {
        mid=(l+d)/2;
        if (maxDesna[mid].first<br) d=mid-1; //br je veci od mida, trazim veci
        else if (maxDesna[mid].first>br) //br je manji od mida, trazim prvi veci
        {
            ret=mid;
            l=mid+1;
        }
        else if (maxDesna[mid].first==br)
        {
            //postoji isti broj
            p=true;
            ret=mid;
            break;
        }
    }
    return ret; //pozicija od lokalnog max
}

void postaviLevo (int br, int pos, int njegovPos) //postavljam novi lokalni max
{
    maxLeva[pos].first=br; //vrednost lokalnog maxa
    maxLeva[pos].second=njegovPos; //pozicija lokalnog maxa u nizu
    nLevo=pos+1; //nova velicina niza lokalnih maximuma
}

void postaviDesno (int br, int pos, int njegovPos) //postavljam novi lokalni max
{
    maxDesna[pos].first=br; //vrednost lokalnog maxa
    maxDesna[pos].second=njegovPos; //pozicija lokalnog maxa u nizu
    nDesno=pos+1; //nova velicina niza lokalnih maximuma
}

int main()
{
    scanf ("%d", &n);
    for (int i=1;i<=n;i++)
    {
        scanf ("%d", &a[i]);
    }

    //koliko manjih ima sa leve strane broja a[i], !UKLJUCUJEM I NJEGA!
    maxbr=a[1];
    sleva[1]=1;
    maxLeva[0].first=a[1];
    maxLeva[0].second=1;
    nLevo=1;
    for (int i=2;i<=n;i++)
    {
        if (a[i]>=maxbr)
        {
            //nasao sam globalni max;
            sleva[i]+=i;
            maxbr=a[i];
            maxLeva[0].first=maxbr;
            maxLeva[0].second=i;
            nLevo=1;
        }
        else
        {
            //postavljam novi lokalni max
            p=false; //ako postoji identican broj
            int curpos=bsLevo(a[i]); //pozicija prvog veceg broja sa lijeve strane
            sleva[i]=i-maxLeva[curpos].second; //trenutno resenje
            if (!p) postaviLevo(a[i], curpos+1, i); //stavljam na mesto ispred od njegovog prvog maxa
            else postaviLevo(a[i], curpos, i); //ako ima isti broj, samo apdejtujem poziciju, ne dodajem nista novo niti brisem
        }
    }

    //obrni ovo sranje za desno
    maxbr=a[n];
    sdesna[n]=1;
    maxDesna[0].first=a[n];
    maxDesna[0].second=n;
    nDesno=1;
    for (int i=n-1;i>=1;i--)
    {
        if (a[i]>=maxbr)
        {
            //nasao sam globalni max
            sdesna[i]+=((n-i)+1);
            maxbr=a[i];
            maxDesna[0].first=maxbr;
            maxDesna[0].second=i;
            nDesno=1;
        }
        else
        {
            //postavljam novi lokalni max
            p=false;
            int curpos=bsDesno(a[i]);
            sdesna[i]=maxDesna[curpos].second-i;
            if (!p) postaviDesno (a[i], curpos+1, i);
            else postaviDesno(a[i], curpos, i);
        }
    }

    //racunam za svaki broj
    //imamo iste uzastopne brojeve, to ne racunam dva puta xexe OK BUT HOW?! n00bfuck
    for (int i=1;i<=n;i++)
    {
        //while (a[i]==a[i+1]) i++;
        int curLeva=sleva[i];
        int curDesna=sdesna[i];

        ll curAns=curLeva*curDesna;
        if (curAns>=MOD) curAns%=MOD;
        sol[a[i]]+=curAns;
    }

    //ispis
    scanf ("%d", &q);
    while (q--)
    {
        int x;
        scanf ("%d", &x);
        ll ende=sol[x];
        //jbg
        if (ende>=MOD) ende%=MOD;
        printf ("%lld\n", ende);
    }

    return 0;
}
