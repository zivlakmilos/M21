#include <bits/stdc++.h>
using namespace std;

char s[1010][1010];
int a, b;
int main()
{
    scanf ("%d%d", &a, &b);
    for (int i=0;i<a;i++) scanf ("%s",s[i]);
    printf ("1 1");

    return 0;
}
