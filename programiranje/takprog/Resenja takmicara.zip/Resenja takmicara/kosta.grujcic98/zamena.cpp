#include <bits/stdc++.h>
using namespace std;
int a, b, c;
int main()
{
    scanf ("%d%d", &a, &b);
    for (int i=0;i<a;i++) scanf ("%d", &b);
    printf ("1");

    return 0;
}
