#include <cstdio>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;
int n,m,k,dalj,b,i,j,v,mapa[1005][1005],cordx,cordy,maxx,x,y,krajx[1005],krajy[1005];
void trazi(int l, int p){

 if (b=0)
  dalj++;
 if (l<i)
  l++;
  else if (l>i)
        l--;
        else if (l=i and p<j)
              p++;
              else if (l=i and p>j)
                    p--;
 b=(b+1)%v;
 if (mapa[i][j]==0)
  mapa[i][j]=dalj;
 else mapa[i][j]=min(mapa[i][j],dalj);
 if (l!=i and p!=j)
  trazi(l,p);
}

int main(){

 scanf("%d %d %d",&n,&m,&k);
 for (int asd=1;asd<=k;asd++){
  scanf("%d %d %d",&x,&y,&v);
  krajx[asd]=x;
  krajy[asd]=y;
  for (i=1;i<=n;i++)
   for (j=1;j<=m;j++)
    if (!mapa[i][j] and x!=i and y!=j){
     dalj=0;
     b=0;
     trazi(x,y);
    }
  for (int i=1;i<=k;i++)
   mapa[krajx[i]][krajy[i]]=0;
  for (int i=1;i<=n;i++)
   for (int j=1;j<=m;j++)
    if (mapa[i][j]>maxx){
     maxx=mapa[i][j];
     cordx=i;
     cordy=j;
    }
 }

 printf("%d %d\n",cordx,cordy);

return 0;
}
