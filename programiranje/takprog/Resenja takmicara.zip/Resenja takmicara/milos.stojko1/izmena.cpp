#include <cstdio>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;
int len,x,y,k,l,minn,b;
char s[500009];
int dalj(int xcord,int ycord){
 int asd=abs(xcord-k);
 int fgh=abs(ycord-l);
 int jkl=asd+fgh;
 return jkl;
}
int main(){
 scanf("%d %d %d",&len,&k,&l);
 scanf("%s",&s);
 minn=dalj(x,y);
 for (int i=0;i<len;i++){
  minn=min(dalj(x,y),minn);
  if (s[i]=='U')
   y++;
   else if (s[i]=='D')
         y--;
         else if (s[i]=='R')
               x++;
               else x--;
 }

 b=minn+(len-minn)/2;
 printf("%d %d\n",minn,b);

return 0;
}
