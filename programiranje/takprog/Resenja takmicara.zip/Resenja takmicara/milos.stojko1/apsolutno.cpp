#include <cstdio>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;
int sum,a[100005],b,c;
long long n,suml,sum1,sum2;
int main(){

 scanf("%lld",&n);
 if (n<=1000){
  for (int i=1;i<=n;i++)
   scanf("%d",&a[i]);
  for (int i=1;i<=n;i++){
   scanf("%d",&b);
   for (int j=1;j<=n;j++)
    sum+=abs(b-a[j]);
  }
  printf("%d\n",sum);
 }
 else {
  for (int i=1;i<=n;i++){
   scanf("%d",&c);
   sum1+=c;
  }
  for (int i=1;i<=n;i++){
   scanf("%d",&c);
   sum2+=c;
  }
  suml=sum2*(n-sum1);
  suml+=(n-sum2)*sum1;
  printf("%lld\n",suml);
 }

return 0;
}
