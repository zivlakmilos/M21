#include <cstdio>
#include <algorithm>
using namespace std;
#define maxN 100000
#define maxA 1000000

long long a[maxN + 2], b[maxN + 2], n, sum = 0;
long long a1[maxN + 2], b1[maxN + 2], u = 0, d = 0;


int main(){
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%lld", &a[i]);
    for (int i = 0; i < n; i++)
        scanf("%lld", &b[i]);
    sort(a, a + n);
    sort(b, b + n);
    a[n] = b[n] = maxA + 200;
    while (u < n && d < n)
    {
        if (a[u] > b[d]){
           b1[d] = u;
           d++;
        }
        else{
             a1[u] = d;
             u++;
        }
    }
    while (u < n)
          a1[u++] = n;
    while (d < n)
          b1[d++] = n;
    for (int i = 0; i < n; i++)
        sum += (a[i] * (2 * a1[i] - n)) + (b[i] * (2 * b1[i] - n));
    printf("%lld", sum);
    return 0;
}
