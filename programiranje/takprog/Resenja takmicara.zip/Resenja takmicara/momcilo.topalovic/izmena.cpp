#include <cstdio>
#include <cmath>
using namespace std;
#define maxN 500000

int L = 0, R = 0, U = 0, D = 0;
int n, x, y, A = maxN + 200, B, absXY;
char tmp;

void add(){
     if (tmp == 'U'){
         U++;
     }
     else if (tmp == 'D'){
         D++;
     }
     else if (tmp == 'L'){
         L++;
     }
     else{
         R++;
     }
}

int distance(){
    int y1 = U - D;
    int x1 = R - L;
    int dX = x > x1? x - x1 : x1 - x;
    int dY = y > y1? y - y1 : y1 - y;
    if ((dX + dY) & 1 == 1)
       return -1;
    else
        return (dX + dY) / 2;
}

int main(){
    scanf("%d %d %d", &n, &x, &y);
    absXY = x > 0? x : -x;
    absXY += y > 0? y : -y;
    for (int i = 0; i < n; i++){
        scanf("%c", &tmp);
        add();
        if(i + 1 >= absXY){
             B = distance();
             if (B > -1 && B < A)
                 A = B; 
        }
    }
    printf("%d %d", A, B);
    return 0;
}
