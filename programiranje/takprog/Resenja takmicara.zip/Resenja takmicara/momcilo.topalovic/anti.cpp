#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;
#define maxN 1000

struct point{
       int x, y;
       };
struct hunter{
       int v;
       point p;
};

vector<point> q;
int mark[maxN][maxN], been[maxN][maxN], n, m, k;
hunter h[maxN];
point sol;

bool in(int x, int y)
{
     return x >=0 && y >= 0 && x < m && y < n;
 }

int find()
{
    int maxi = 0;
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
            if(mark[i][j] > maxi)
            {
                          maxi = mark[i][j];
                          sol.x = i;
                          sol.y = j;
            }
}

void bfs()
{
     for (int s = 0; s < q.size(); s++)
     {
         int x = q[s].x;
         int y = q[s].y;
         int t = been[x][y];
         for (int i = t; i > 0 ; i--)
         {
             for (int j = t - i - 1; j > i - t; j--)
             {
                 if (in(x - i, y + j) && mark[x - i][y + j] > mark[x][y])
                 {
                 if (been[x- i][y + j] < been[x][y]){
                             been[x- i][y + j] = been[x][y];
                              mark[x - i][y + j] = mark[x][y] + 1;
                              }
                 }
             }
             int j = t - i;
             point p;
             if (in(x - i, y + j) && mark[x - i][y + j] > mark[x][y])
             {
                    mark[x - i][y + j] = mark[x][y] + 1;
                    if (been[x- i][y + j] < been[x][y]){
                             been[x- i][y + j] = been[x][y];
                              mark[x - i][y + j] = mark[x][y] + 1;
                 }
                    p.x = x - i;
                    p.y = y - i;
                    q.push_back(p);
             }
         }
     }
}

bool cmp(hunter h1, hunter h2)
{
     return h1.v <= h2.v;
}

int main(){
    scanf("%d %d %d", &n, &m, &k);
    for (int i = 0; i < k; i++)
    {
        point tmp;
        scanf("%d %d %d", &tmp.x, &tmp.y, h[i].v);
        h[i].p.x = tmp.x - 1;
        h[i].p.y = tmp.y - 1;
    }
    sort(h, h + k, cmp);
    for (int i = 0; i < m; i++)
        for (int j = 0; j < n; j++)
        {
            mark[i][j] = 2 * maxN + 2;
            been[i][j] = 0;
        }
    for (int i = 0; i < k; i++)
    {
        mark[h[i].p.x][h[i].p.y] = 0;
        been[h[i].p.x][h[i].p.y] = h[i].v;
        q.push_back(h[i].p);
    }
    bfs();
    find();
    printf("%d %d", sol.x, sol.y);
    return 0;
}
