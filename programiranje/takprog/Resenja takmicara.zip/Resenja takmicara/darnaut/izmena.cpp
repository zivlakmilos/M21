#include<cstdio>
#include<algorithm>
#include<iostream>
#include<string>
using namespace std;
int r,u,s,n,res,sol,d,l,dol,rs,po;
string q;
int main(){
    scanf("%d%d%d",&n,&r,&s);
    cin>>q;
    for(int i=0;i<n;i++){
        if(q[i]=='L')l++;
        if(q[i]=='R')d++;
        if(q[i]=='U')u++;
        if(q[i]=='D')dol++;
    }
        if(s!=0){rs=u-dol;
        if(s>0)res=min(dol,(rs-s)/2);
        else res=min(u,(rs-s)/2);
            rs=rs-res;
            po=abs(s-res);
         //   printf("%d %d",res,po);
            res=abs(res);
        if(r>0){
            l=l-po;
            res=res+po;
        }
        else  {d=d-po;
            res=res+po;}


        }
        else res=0;
        res=d-l;
        sol=(r-res)/2;
        if(sol<0)sol=0-sol;
        printf("0 %d\n",sol+res);


return 0;
}
