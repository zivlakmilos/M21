#include<cstdio>
#include<queue>
#include<algorithm>
using namespace std;
queue <int>qx,qy,qv,qr;
int n,res,m,k,x,y,v,pomx[6],pomy[6],M[1004][1004],w,r,pomo;
int main(){
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=n;i++) M[i][m+1]=-1;
    for(int i=1;i<=m;i++) M[0][i]=-1;
    for(int i=1;i<=m;i++) M[n+1][i]=-1;
    for(int i=1;i<=n;i++) M[i][0]=-1;
    for(int i=1;i<=k;i++){scanf("%d%d%d",&x,&y,&v);
        qx.push(x);
        qy.push(y);
        qv.push(v);
        qr.push(0);
        M[x][y]=-1;
    }

    pomx[1]=0;
    pomy[1]=1;
    pomx[2]=0;
    pomy[2]=-1;
    pomx[3]=1;
    pomy[3]=0;
    pomx[4]=-1;
    pomy[4]=0;
    while(qy.size()){
        for(int i=1;i<=4;i++){
            if((qr.front()+1)% qv.front()==0)pomo=(qr.front()+1) /qv.front();
            else pomo=(qr.front()+1) /qv.front()+1;
            if((M[qx.front()+pomx[i]][qy.front()+pomy[i]]>=pomo or M[qx.front()+pomx[i]][qy.front()+pomy[i]]==0) and M[qx.front()+pomx[i]][qy.front()+pomy[i]]!=-1){
                M[qx.front()+pomx[i]][qy.front()+pomy[i]]=pomo;
                qx.push(qx.front()+pomx[i]);
                qy.push(qy.front()+pomy[i]);
                qv.push(qv.front());
                qr.push(qr.front()+1);
            }
        }
     //   printf("%d y=%d v=%d r=%d m=%d\n",&qx.front(),qy.front(),qv.front(),qr.front(),M[qx.front()][qy.front()]);
        qx.pop();
        qy.pop();
        qv.pop();
        qr.pop();

    }
   /*  for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++)
            printf("%d",M[i][j]);
        printf("\n");}*/
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            if(M[i][j]>res){res=M[i][j]; w=i; r=j;}
    printf("%d %d\n",w,r);
return 0;
}
