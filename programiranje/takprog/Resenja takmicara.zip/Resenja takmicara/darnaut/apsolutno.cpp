#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int br1,br2,n,a,b,niza[100005],nizb[100005],poma[2000006],pomb[2000006];
long long suma;
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++) {scanf("%d",&a);
    poma[a+1000000]++;
    if(poma[a+1000000]==1)niza[++br1]=a;}
    for(int i=1;i<=n;i++){ scanf("%d",&b);
        pomb[b+1000000]++;
        if(pomb[b+1000000]==1)nizb[++br2]=b;}
 //   for(int i=1;i<=3;i++)printf("%d %d %d %d\n",poma[niza[i]+1000000], pomb[nizb[i]+1000000],niza[i],nizb[i]);
    for(int i=1;i<=br1;i++)
        for(int j=1;j<=br2;j++){
            long long pom=(niza[i]-nizb[j]);
              //  printf("%d ",pom);
                pom=pom*pomb[nizb[i]+1000000]*poma[niza[j]+1000000];
            if(pom<0)pom=0-pom;
            suma=suma+pom;
          //  printf("%d %d\n",i,j);
        }
    printf("%d\n",suma);
return 0;
}
