#include <iostream>
#include <cstdlib>
#include <stdio.h>


using namespace std;
int n, a[100000];

int slicni(int a, int b){
    int c = abs(a-b);
    while (c > 10){
        if (c%10 != 0)
            return 0;
        c /= 10;
    }
    return c;
}

int jakoGlupo(int x,int amax, int i){
    int bmax = 0,y=0, am =0;
    for (int j=i; j<n; j++)
        if (slicni(x,a[j])){
            y= jakoGlupo(a[j],amax,j);
            if (y > bmax)
                bmax= y;
            am = amax+slicni(x,a[j])+bmax;
        }
   return am;
}

int main()
{
    scanf("%d",&n);
    for(int i=0; i<n; i++)
        scanf("%d",&a[i]);
    int maxx=0;
    for (int i=0; i<n; i++){
        int x = jakoGlupo(a[i+1],0,i+1);
        if (x > maxx)
            maxx = x;
    }

    printf ("%d \n",maxx);

    return 0;
}
