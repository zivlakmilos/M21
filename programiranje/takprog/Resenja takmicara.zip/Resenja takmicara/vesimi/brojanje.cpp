#include <iostream>
#include <algorithm>
#include <stdio.h>
#include <cstdlib>
#include <math.h>

using namespace std;
int n;

struct broj{
    int x,m = 0,v = 0,u;
};

broj a[1000000], b[1000000];

bool tmp(broj a, broj b){
    return  a.x > b.x ? true:false;
}

int nadji(int k, int l, int d){
    if (k == b[l].x)
        return b[l].u;
    if (k > b[l].x)
        return 0;
    if (k == b[d].x)
        return b[d].u;
    if (k < b[d].x)
        return 0;
    if (k == b[(l+d)/2].x)
        return b[(l+d)/2].u;
    if(k > b[(l+d)/2].x)
        return nadji(k, l, (l+d)/2-1);
    if (k < b[(l+d)/2].x)
        return nadji(k,(l+d)/2+1, d);
    if (l == d)
        return 0;
    return 0;
}

int main()
{
    scanf ("%d",&n);
    for(int i=0; i<n;i++){
        scanf("%d",&a[i].x);
        int j = i-1;
        while((a[j].x < a[i].x) && (j>=0)){
            a[i].m ++;
            j --;
        }
    }
    for (int i=0; i<n; i++){
        int j=i+1;
        while ((a[i].x>a[j].x) && (j <n)){
            a[i].v++;
            j++;
        }
        a[i].u = ((a[i].m+1)*(a[i].v+1))%1000000007;
    }
    sort(a, a+n, tmp);
    b[0] = a[0];
    int j=1;
    for (int i=1; i< n; i++){
        if (a[i].x != a[i-1].x){
            b[j]=a[i];
            j++;
        }
        else{
            b[j-1].u = (b[j-1].u + a[i].u)%1000000007;
        }
    }
    int q=j;
    int z;
    scanf ("%d",&z);
    for(int i = 0; i<z; i++){
        int o;
        scanf ("%d",&o);
        printf ("%d\n",nadji(o,0,q));
        }


    printf("\n");
    return 0;
}
