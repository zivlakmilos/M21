#include <cstdio>
#include <algorithm>
using namespace std;

const int MaxEl = 100000;

int main() {
    //freopen("input.txt", "r", stdin);   ///ZAKOMENTARISI NA KRAJU


    int n;
    int a[MaxEl] = {}, b[MaxEl] = {};
    scanf("%d", &n);
    for(int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for(int i = 0; i < n; i++) {
        scanf("%d", &b[i]);
    }

    sort(a, a+n); sort(b, b+n);

    unsigned long long sum = 0;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            if(a[i] > b[j]) sum += a[i]-b[j];
            else if(a[i] < b[j]) sum += b[j]-a[i];
        }
    }
    printf("%lld\n", sum);     ///<-------------IZMENI NA KRAJU U %LLD
    return 0;
}
