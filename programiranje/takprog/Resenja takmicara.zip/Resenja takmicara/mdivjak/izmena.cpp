#include <cstdio>
#include <algorithm>
//#include <cstring>
using namespace std;

const int Max = 500001;
int n, r, s;
char q[Max] = {};
//int potezi = 0;
char gore_dole = 'Q', levo_desno = 'Q';

inline int abs(int a) {
    return (a>=0)?a:-a;
}

int minProlaz() {
    int potezi = abs(r) + abs(s);
    //char put[Max] = {};

    sort(q, q+potezi);
    //q[potezi] = '\0';

    //char gore_dole = 'Q', levo_desno = 'Q';
    if(s < 0) gore_dole = 'D';
    else if(s > 0) gore_dole = 'U';
    //s = abs(s);

    if(r < 0) levo_desno = 'L';
    else if(r > 0) levo_desno = 'R';
    //r = abs(r);

    /*int x;
    for(x = 0; x < s; x++) {
        put[x] = gore_dole;
    }
    for(x = s; x < s + r; x++) {
        put[x] = levo_desno;
    }
    put[potezi] = '\0';
    sort(put, put+potezi);*/
    //printf("%s\n", q);
    //printf("%s\n", put);

    int brgd = 0, brld = 0;
    for(int i = 0; i < potezi; i++) {
        if(q[i] == gore_dole) ++brgd;
        if(q[i] == levo_desno) ++brld;
    }
    return potezi-brgd-brld;
}

int minKraj() {
    sort(q, q+n);
    int brlevo = 0, brdesno = 0, brgore = 0, brdole = 0;
    for(int i = 0; i < n; i++) {
        switch(q[i]) {
            case 'D': ++brdole; break;
            case 'L': ++brlevo; break;
            case 'R': ++brdesno; break;
            case 'U': ++brgore;
        }
    }
    //int potezi = abs(r) + abs(s);
//    char gore_dole = 'Q', levo_desno = 'Q';
    if(s < 0) gore_dole = 'D';
    else if(s > 0) gore_dole = 'U';
    //s = abs(s);

    if(r < 0) levo_desno = 'L';
    else if(r > 0) levo_desno = 'R';

    //int brgd = 0, brld = 0;
    if(levo_desno == 'L') brlevo -= abs(r);
    else if(levo_desno == 'R') brdesno -= abs(r);
    //else if(levo_desno == 'Q') brld = 0;

    if(gore_dole == 'D') brdole -= abs(s);
    else if(gore_dole == 'U') brgore -= abs(s);
    //else if(gore_dole == 'Q') brgd = 0;

    /*int promene;
    promene = (abs(brdesno - brlevo) + abs(brgore-brdole))/2;*/

    return (abs(brdesno - brlevo) + abs(brgore-brdole))/2;
}

int main() {

    scanf("%d %d %d", &n, &r, &s);
    scanf("%s", q);

    //printf("%d ", minProlaz());
    //sort(q, q+n);
    //printf("%s\n", q);
    printf("%d %d", minProlaz(), minKraj());

    return 0;
}
