#include<cstdio>
#include<algorithm>
#include<map>
using namespace std;
map <int,int>b;
int n,a[100100],c[100100],d[100100],q,k,w;
int main(){
    
    scanf("%d",&n);
    
    for (int i=1;i<=n;i++) scanf("%d",&a[i]);
    
  
      
  /*    for (int i=1;i<=n;i++)
       {
               if (a1[i]!=a1[i-1]){ w++; a[w]=a1[i]; }
                    
       } kapnuce neki poen valjda
       
       n=w;
 */      
   //    for (int i=1;i<=n;i++) printf("%d ",a[i]);
    
    
  for (int i=1;i<=n;i++)
    for (int j=i;j<=n;j++)
      {
             if (a[i]<a[j]) break;
             c[i]++;       
      }
      
    for (int i=n;i>=1;i--)
     for (int j=i;j>=1;j--)
      {
              if (a[j]>a[i]) break;
              d[i]++;        
              
      }
           
    
    
    for (int i=1;i<=n;i++){
        if (a[i]!=a[i-1]){
      b[a[i]]=b[a[i]]+(c[i]*d[i])%1000000007;
      b[a[i]]=b[a[i]]%1000000007;} else
        {
              b[a[i]]=b[a[i]]+c[i];
              b[a[i]]=b[a[i]]% 1000000007;                           
        }
      }
    
    
    scanf("%d",&q);
   for (int i=1;i<=q;i++){
       
       scanf("%d",&k);
       printf("%d\n",b[k]);
       
       }
    
    /*
     printf("\n");
    for (int i=1;i<=n;i++) printf("%d ",c[i]);
    printf("\n");
    for (int i=1;i<=n;i++) printf("%d ",d[i]);
    */
  //  scanf("%d");//IZBRISI OVO OBAVEZNO!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    return 0;
}
