#include <iostream>
#include <cstdio>
using namespace std;

int main()
{
    int N, M, K, ucit;
    scanf("%d %d", &N, &M);
    for(int i = 0; i<N; i++)
    {
         scanf("%d", &ucit);
    }
    scanf("%d", &K);
    for(int i = 0; i <K; i++)
      scanf("%d %d", &ucit, &ucit);

    printf("%d %d", M, N); //BOZ' POMOZI!

    return 0;
}
