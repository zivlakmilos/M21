#include <iostream>
#include <stdio.h>
using namespace std;

int main()
{
    int N, Q, unos, pocetni, brojac = 0, dzobra_car = 0;
    scanf("%d", &N);

    int niz[N];
    for(int i = 0; i < N; i++)
        scanf("%d", &niz[i]);
    scanf("%d", &Q);

    //DOSADNOOOOOOOOST
    for(int i = 0; i <Q; i++)
    {
        scanf("%d", &unos);
        brojac = 0;

        for(int j = 0; j < N; j++)
        {
            dzobra_car = 0;
            pocetni = j;
            while(niz[pocetni] <= unos)
            {
               if(niz[pocetni] == unos && niz[pocetni+1] <= unos )
                {
                    dzobra_car = unos;
                    brojac++;
                }
                else if(niz[pocetni] == unos) //CAOOO NIKOOLA, STA RADIIIS TOOOO?!?!?!?
                    dzobra_car = unos;
                pocetni++;
                if(niz[pocetni]>unos && dzobra_car == unos)
                    brojac++;
            }
        }
            printf("%d\n", brojac % (10^9 + 7)); //POGRESNOOOOOOOOOOO AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
    }


    return 0;
}
