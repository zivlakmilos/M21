#include <iostream>
#include <cstdlib>
#include <stdio.h>
#include <cstring>

#define MAPLIMIT 1000
#define KLIMIT 1000000

using namespace std;

// @Author FansteKaRiNa1998 [SRB]
//         stefan.djordjevic98

int N, M;
int Map[MAPLIMIT][MAPLIMIT][1];

int K;
int X[KLIMIT], Y[KLIMIT], V[KLIMIT];
int Min = 0;
int x0 = -1,
    y0 = -1;

void DFS(int X, int Y, int v, int koraci, int b) {
     if(koraci <=0) {
               koraci = v;
               b--;
               }
     if(X + 1 <= N - 1) {
     if(Map[X + 1][Y][0] == 0 || Map[X + 1][Y][0] <=b) {
              Map[X + 1][Y][0] = b;
              DFS(X + 1, Y, v, koraci - 1, b);
              } }
     if(X - 1 >= 0) {
     if(Map[X - 1][Y][0] == 0 || Map[X - 1][Y][0] <=b) {
              Map[X - 1][Y][0] = b;
              DFS(X - 1, Y, v, koraci - 1, b);
              } }
     if(Y + 1 <= M - 1) {
     if(Map[X][Y + 1][0] == 0 || Map[X][Y + 1][0] <=b) {
                 Map[X][Y + 1][0] = b;
                 DFS(X, Y + 1, v, koraci - 1, b);
                 } }
     if(Y - 1 >= 0) {
     if(Map[X][Y - 1][0] == 0 || Map[X][Y - 1][0] <=b) {
                 Map[X][Y - 1][0] = b;
                 DFS(X, Y - 1, v, koraci - 1, b);
                 } }
}

void Unos() {
     scanf("%d%d", &N, &M);
     
     char jedanred[MAPLIMIT];
     char POMOCNA = '0';
     int pomocna = (int) POMOCNA;
     int jedanchar;
     for(int l = 0; l < N; l++) {
             scanf("%s", jedanred);
             for(int j = 0; j < M; j++) {
                     jedanchar = ((int) jedanred[j]) - pomocna;
                     Map[l][j][0] = jedanchar;
                     }        
     }
     
     scanf("%d", &K);
     for(int l = 0; l <K; l++) {
             scanf("%d%d%d", &X[l], &Y[l], &V[l]);
             X[l]--;
             Y[l]--;
             Map[X[l]][Y[l]][0] = -1;
             }
}

void Razrada() {
     for(int l = 0; l < K; l++) DFS(X[l], Y[l], V[l], V[l], -2);
}

void Ispis() {
     Min = Map[X[0]][Y[0]][0];
     x0 = X[0];
     y0 = Y[0];
     for(int l = 0; l < N; l++)
     for(int j = 0; j < M; j++) {
             if(Min >Map[l][j][0]) {
                    Min = Map[l][j][0];
                    x0 = l;
                    y0 = j;
                    }
             }
     printf("%d %d", x0 + 1, y0 + 1);
}

int main() {
    Unos();
    Razrada();
    Ispis();
    
    return 0;   
}
