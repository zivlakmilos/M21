#include <iostream>
#include <cstring>

#define NLIMIT 100000
#define ALIMIT 8

using namespace std;

// @Author FansteKaRiNa1998 [SRB]
//         stefan.djordjevic98

int N;
int Prog[NLIMIT][ALIMIT];
int Alength;
int MAX[NLIMIT];
bool Oznacen[NLIMIT];
int Max = 0;

void Unos() {
     scanf("%d", &N);
     int i = 1;
     int A;
     for(int l = 0; l < N; l++) {
             scanf("%d", &A);
             i = 1;
             while(A > 0) {
                     Prog[l][i - 1] = A % 10;
                     A /= 10;
                     i++;
                     }
             }
     if(i != 1) Alength = i - 1;
     else Alength = i;
}

int Dobitak(int l, int j) { // l je kasniji broj, a j raniji
    int Suma = 0;
    for(int i = 0; i < 8; i++) {
            if(Suma != 0 && Prog[l][i] != Prog[j][i]) return 0;
            else Suma += Prog[l][i] - Prog[j][i];
            }
    return Suma;
}

void Rekurz(int index) {
     for(int l = index - 1; l >= 0; l--) {
             if(Dobitak(index, l) != 0)
             if(MAX[l] < Dobitak(index, l) + MAX[index]) {
                       MAX[l] = Dobitak(index, l) + MAX[index];
                       Oznacen[l] = true;
                       Rekurz(l);
                       }
             }
     }

void Razrada() {
     for(int l = N - 1; l >= 0; l--) {
             if(!Oznacen[l]) Rekurz(l);
             }
     for(int l = 0; l < N; l++) {
             if(MAX[l] > Max) Max = MAX[l];
             }    
}

void Ispis() {
     printf("%d", Max);
}

int main() {
    Unos();
    Razrada();
    Ispis();
    
    return 0;
}
