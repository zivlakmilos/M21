#include <iostream>
#include <cstring>

#define NLIMIT 1000000
#define MODUL 1000000007

using namespace std;

// @Author FansteKaRiNa1998[SRB]
//         stefan.djordjevic98

int N, Q;
int Zad[NLIMIT], Querry[NLIMIT];
int Chlen[NLIMIT][2];

long long Output[NLIMIT];

void Unos() {
     scanf("%d", &N);
     for(int l = 0; l < N; l++) {
             scanf("%d", &Zad[l]);
             Chlen[l][0] = Zad[l];
             Chlen[l][1] = l;
             }
}

void zameni(int l, int j, int Pos[][2]) {
     int q = Pos[l][0];
     int r = Pos[l][1];
     
     Pos[l][0] = Pos[j][0];
     Pos[l][1] = Pos[j][1];
     
     Pos[j][0] = q;
     Pos[j][1] = r;
     }

int perm(int leva, int desna, int Pos[][2]) {
     int k = leva;
     for(int l = leva + 1; l < desna; l++)
             if(Pos[k][0] > Pos[l][0]) {
                          zameni(k + 1, l, Pos);
                          zameni(k, k + 1, Pos);
                          k++;
                          }
     if(Pos[k][0] > Pos[desna][0]) {
     if(k == desna - 1) {
          zameni(k, desna, Pos);
          k++;
          }
     else {
          zameni(k + 1, desna, Pos);
          zameni(k, k + 1, Pos);
          k++;
          }     
          }
     return k;
}

void quicksort(int l, int d, int Pos[][2]) {
     if(l >= d) return;
     
     int k = perm(l, d, Pos);
     quicksort(l, k - 1, Pos);
     quicksort(k + 1, d, Pos);     
}

void Quicksort(int Pos[][2], int length) {
     quicksort(0, length - 1, Pos);     
}

void priprema() {
     Quicksort(Chlen, N);
}

int RelIndex(int broj, int l, int d) { // nalazi relativni indeks u Chlenu
    if(l > d) return -1; // -1 oznacava da ne postoji
    if(l == d)
    if(Chlen[l][0] == broj) return l;
    else return -1;
    if(l == d - 1)
    if(Chlen[l][0] == broj) return l;
    if(Chlen[d][0] == broj) return d;
    if(Chlen[(l + d) / 2][0] > broj) return RelIndex(broj, l, (l + d) / 2);
    else return RelIndex(broj, (l + d) / 2, d);
}

int RelIndex(int broj) {
    return RelIndex(broj, 0, N - 1);
}

long long komb1(int index) {
     int bl = 1, bd = 1;
     for(int l = index - 1; l >= 0 && Zad[l] <= Zad[index]; l--) bl++;
     for(int l = index + 1; l < N && Zad[l] <= Zad[index]; l++) bd++;
     return bl*bd;           
}

long long komb(int broj) {
     long long suma = 0;
     int i = RelIndex(broj);
     for(int l = i - 1; l >= 0 && Chlen[l][0] == broj; l--) {
             int b = Chlen[l][1];
             suma += komb1(b);            
             }
     for(int l = i; l < N && Chlen[l][0] == broj; l++) {
             int b = Chlen[l][1];
             suma += komb1(b);
             }
     
     return suma;
}

void Razrada() {
     scanf("%d", &Q);
     for(int l = 0; l < Q; l++) {
             scanf("%d", &Querry[l]);
             Output[l] = komb(Querry[l]);
     }
}

void ispis() {
     for(int l = 0; l < Q; l++) printf("%lld\n", Output[l] % MODUL);   
}

int main() {
    Unos();
    priprema();
    Razrada();
    ispis();
    
    return 0;
}
