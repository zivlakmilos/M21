#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <queue>

#define MAXN 1005
#define MAXT 1000005
using namespace std;
struct razlomak
{
       int br,im;
};
struct polje 
{
       bool moze;
       razlomak t; 
       int poslednji,brp;//da li je vec bio ovde    
};
struct clan
{
       razlomak t;
       int i,j,brp,v;
};
struct tragac
{
       int v,i,j;
};
polje a[MAXN][MAXN];
//queue <clan> r;
tragac t[MAXT];
int nzd(int a,int b)
{
    if (b==0)
    {
       return a;
    }
    if (b==1)
    {
       return 1;
    }
    return nzd(b,a%b);
}
int nzs(int a,int b)
{
    return a*b/nzd(a,b);
}
razlomak saberi(razlomak r1,razlomak r2)
{
         int zim=nzs(r1.im,r2.im);
         razlomak rez;
         rez.im=zim;
         rez.br=zim/r1.im*r1.br+zim/r2.im*r2.br;
         return rez;
}
bool veci(razlomak r1,razlomak r2)
{
         long long p1,p2;
         p1=(long long)(r1.br)*(long long)(r2.im);
         p2=(long long)(r2.br)*(long long)(r1.im);
         if (p1>p2)
         {
            return true;
         }
         return false;
}
void ucitajred(string s,int i,int m)
{
     int j;
     for (j=0;j<m;j++)
     {
         if (s[j]=='0')
         {
            a[i][j].moze=true;
         }
         else
         {
             a[i][j].moze=false;
         }
         a[i][j].t.br=10000;
         a[i][j].t.im=1;
         a[i][j].poslednji=-1;
         a[i][j].brp=10000;
     }
}
bool moze(int i,int j,int n,int m,int ind)
{
     if (i>=0 && j>=0 && i<n && j<m && a[i][j].moze && a[i][j].poslednji!=ind)
     {
        return true;
     }
     return false;
}
void bfs(tragac t,int ind,int n,int m)
{
     clan pom;
     queue <clan> r;
     int i,j,brp,v;
     razlomak r1,r2;
     clan cl;
     cl.i=t.i;
     cl.j=t.j;
     cl.t.br=0;
     cl.t.im=1;
     cl.brp=0;
     cl.v=0;
     r.push(cl);
     a[t.i][t.j].poslednji=ind;
     while (!r.empty())
     {
           
           i=r.front().i;
           j=r.front().j;
           //cout<<i<<" "<<j<<"\n";
           r1=r.front().t;
           if (r.front().v<=0)
           {
              v=t.v-1;
              brp=r.front().brp+1;
           }
           else
           {
               v=r.front().v-1;
               brp=r.front().brp;
           }
           if (moze(i,j+1,n,m,ind))
           {
              pom.i=i;
              pom.j=j+1;
              r2.br=1;
              r2.im=t.v;
              pom.t=saberi(r2,r1);
              pom.brp=brp;
              pom.v=v;
              a[pom.i][pom.j].poslednji=ind;
              if (pom.brp<a[i][j+1].brp)
              {
                 a[i][j+1].t=pom.t;
                 a[i][j+1].brp=pom.brp;
              }
              r.push(pom);
           }
           if (moze(i,j-1,n,m,ind))
           {
              pom.i=i;
              pom.j=j-1;
              r2.br=1;
              r2.im=t.v;
              pom.t=saberi(r2,r1);
              pom.brp=brp;
              pom.v=v;
              a[pom.i][pom.j].poslednji=ind;
              if (pom.brp<a[i][j-1].brp)
              {
                 a[i][j-1].t=pom.t;
                 a[i][j-1].brp=pom.brp;
              }
              r.push(pom);
           }
           if (moze(i-1,j,n,m,ind))
           {
              pom.i=i-1;
              pom.j=j;
              r2.br=1;
              r2.im=t.v;
              pom.t=saberi(r2,r1);
              pom.brp=brp;
              pom.v=v;
              a[pom.i][pom.j].poslednji=ind;
              if (pom.brp<a[i-1][j].brp)
              {
                 a[i-1][j].t=pom.t;
                 a[i-1][j].brp=pom.brp;
              }
              r.push(pom);
           }
           if (moze(i+1,j,n,m,ind))
           {
              pom.i=i+1;
              pom.j=j;
              r2.br=1;
              r2.im=t.v;
              pom.t=saberi(r2,r1);
              pom.brp=brp;
              pom.v=v;
              a[pom.i][pom.j].poslednji=ind;
              if (pom.brp<a[i+1][j].brp)
              {
                 a[i+1][j].brp=pom.brp;
              }
              r.push(pom);
           }
           r.pop();
     }
}
int main(int argc, char *argv[])
{
    int n,m,i,j,q,maxi=0,maxj=0;
    string red;
    scanf("%d%d",&n,&m);
    for (i=0;i<n;i++)
    {               
        cin>>red;
        ucitajred(red,i,m);  
    }
    scanf("%d",&q);
    for (i=0;i<q;i++)
    {
        scanf("%d%d%d",&t[i].i,&t[i].j,&t[i].v);
        t[i].i--;
        t[i].j--;
        a[t[i].i][t[j].j].t.br=0;
        a[t[i].i][t[j].j].t.im=1;
        a[t[i].i][t[j].j].brp=0;
    }
    for (i=0;i<q;i++)
    {
        bfs(t[i],i,n,m);
    }
    int max;
    bool init=false;
    /*for (i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            cout<<a[i][j].brp<<" ";
        }
        cout<<"\n";
    }*/
    for (i=0;i<n;i++)
    {
        for (j=0;j<m;j++)
        {
            if (a[i][j].moze && (!init || (a[i][j].brp>max)))
            {
               init=true;
               max=a[i][j].brp;
               maxi=i;
               maxj=j;
            }
        }
    }
    printf("%d %d",maxi+1,maxj+1);
    //system("PAUSE");
    return 0;
}
