#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;

char s[9];
int main(int argc, char *argv[])
{
    int n,i,a,m;
    scanf("%d",&n);
    for (i=0;i<n;i++)
    {
        scanf("%s",&s);
        m=string(s).length();
    }
    printf("%d",n+n/2-3);
    //system("PAUSE");
    return 0;
}
