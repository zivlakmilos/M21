#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <stack>

#define MAXN 1000005
#define MAXQ 1000005
#define MOD 1000000007
using namespace std;
struct maksimum
{
       int v,poz;
       long long br;
};
struct smaksimum
{
       int v;
       long long br;
};
maksimum a[MAXN];
smaksimum b[MAXN];
stack <maksimum> levi;
stack <maksimum> desni;
int k[MAXQ],levin[MAXN],desnin[MAXN],duz=0;
void testmax(maksimum t[],int n)
{
     int i;
     for (i=0;i<n;i++)
     {
         cout<<t[i].br<<" ";
     }cout<<"\n";
}
void testn(int t[],int n)
{
     int i;
     for (i=0;i<n;i++)
     {
         cout<<t[i]<<" ";
     }cout<<"\n";
}
void sredil(maksimum pom)
{
     while(!levi.empty())
     {
        if (pom.v>=levi.top().v)
        {
           levi.pop();
        }
        else
        {
            return;
        }
     }
}
void genl(int n)
{
     int i;
     levin[0]=0;
     for (i=1;i<n;i++)
     {
         sredil(a[i]);
         if (levi.empty())
         {
            levin[i]=i;
         }
         else
         {
             levin[i]=i-levi.top().poz-1;
         }
         levi.push(a[i]);
     }
     //testn(levin,n);
}
void sredid(maksimum pom)
{
     while(!desni.empty())
     {
        if (pom.v>desni.top().v)
        {
           desni.pop();
        }
        else
        {
            return;
        }
     }
     
}
void gend(int n)
{
     int i;
     desnin[n-1]=0;
     desni.push(a[n-1]);
     for (i=n-2;i>=0;i--)
     {
         sredid(a[i]);
         if (desni.empty())
         {
           desnin[i]=n-1-i;
         }
         else
         {
             desnin[i]=desni.top().poz-1-i;
         }
         desni.push(a[i]);
     }
     //testn(desnin,n);
}
void genmax(int n)
{
     int i;
     genl(n);
     gend(n);
     for (i=0;i<n;i++)
     {
         a[i].br=((long long)(levin[i]+1)*(long long)(desnin[i]+1))%MOD;
     }
}
int cmp(const void *i1,const void *i2)
{
     const maksimum *m1,*m2;
     m1=(maksimum *)(i1);
     m2=(maksimum *)(i2);
     return m1->v-m2->v;
}
void merge(int n)
{
     int i;
     for (i=0;i<n;i++)
     {
         if (i==0)
         {
            b[duz].v=a[i].v;
            b[duz++].br=a[i].br;
            continue;
         }
         if (a[i].v!=a[i-1].v)
         {
            b[duz].v=a[i].v;
            b[duz++].br=a[i].br;
         }
         else
         {
             b[duz-1].br=(b[duz-1].br+a[i].br)%MOD;
         }
     }
}
int bin(smaksimum b[],int l,int d,int tr)
{
    int s=(l+d)/2;
    if (l<=d)
    {
             if (b[l].v==tr)
             {
                return l;
             }
             if (b[d].v==tr)
             {
                return d;
             }
             if (b[s].v==tr)
             {
                return s;
             }
             if (b[s].v<tr)
             {
                return bin(b,s+1,d,tr);
             }
             return bin(b,l,s-1,tr);
    }
    return -1;
}
int main(int argc, char *argv[])
{

    int n,q,i,j,ind;
    scanf("%d",&n);
    for (i=0;i<n;i++)
    {
        scanf("%d",&a[i].v);
        a[i].poz=i;
    }
    scanf("%d",&q);
    for (i=0;i<q;i++)
    {
        scanf("%d",&k[i]);
    }
    genmax(n);
    //testn(levin,n);
    //testn(desnin,n);
    //testmax(a,n);
    qsort(a,n,sizeof(maksimum),cmp);
    merge(n);
    for (i=0;i<q;i++)
    {
        ind=bin(b,0,duz-1,k[i]);
        if (ind==-1)
        {
           printf("0\n");
        }
        else
        {
            printf("%lld\n",b[ind].br);
        }
    }
    //system("PAUSE");
    return 0;
}
