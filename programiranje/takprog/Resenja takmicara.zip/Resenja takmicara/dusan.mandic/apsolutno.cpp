#include <cstdio>
#include <algorithm>
#include <functional>
#include <string>
#include <math.h>
#include <iostream>

using namespace std;

const int MAX_MAT = 100005;
int n,i;
long a[MAX_MAT],b[MAX_MAT],temp;
long long suma,lltemp,ak,bk;
bool nule;
int main ()
{
    scanf("%d",&n);
    nule = true;

    for (int i = 0; i < n; i++)
    {
        scanf("%d",&a[i]);
        if (a[i] > 1)
            nule = false;
            if (a[i] == 1)
                ak += 1;
    }

    for (int i = 0; i < n; i++)
    {
        scanf("%d",&b[i]);
        if (b[i] > 1)
            nule = false;
            if (b[i] == 1)
                bk += 1;

    }


    if (nule == true)
    {
        suma += ak * (n - bk);
        suma += bk * (n - ak);
    }



    else
    {


    for (int i = 0; i < n; i++)
{
        for (int j = 0; j < n; j++)
        {
            temp = abs(a[i] - b[j]);
            lltemp = temp;
            suma += lltemp;
        }
}
    }
    printf("%lld",suma);






    return 0;
}
