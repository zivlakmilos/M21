#include<iostream>
#include<stdio.h>
#include<math.h>

using namespace std;

int main()
{
 int n,r,s,x1=0,y1=0,x=0,y=0,br2,br1=n;
 cin>>n>>r>>s;   
 char a[n];
 cin>>a;
 
 for(int i=0;i<r+s;i++)
   {
         
       
  if(a[i]=='U')
  y1++;
  
  else if(a[i]=='D')
  y1--;
  
  else if(a[i]=='R')        
  x1++;
  
  else if(a[i]=='L')
  x1--;  
               
   }      

 for(int i=r+s;i<n;i++){
 
 
  if(a[i]=='U')
  y1++;
  
  else if(a[i]=='D')
  y1--;
  
  else if(a[i]=='R')        
  x1++;
  
  else if(a[i]=='L')
  x1--;
 
  if(br1>(abs(x1-r)+abs(y1-s))/2)
  br1=(abs(x1-r)+abs(y1-s))/2;
  if(i==n-1)
  br2= (abs(x1-r)+abs(y1-s))/2;  
     
  
  } 
 


  cout<<br1<<" "<<br2;
    
 return 0;    
}
