#include<iostream>
#include<stdio.h>
#include<math.h>
#include<algorithm>

using namespace std;

int suma(long long b[],int n)
{
    int sum=0;
    for(int i=0;i<n;i++)
       sum+=b[i];
            
    return sum;
}

int main()
{

 long long a[100000],b[100000],zbir=0,sumbp,sumbn,gr;
 int n;
 cin>>n;
 
 for(int i=0;i<n;i++)
 cin>>a[i];    

 for(int i=0;i<n;i++)
 {
  cin>>b[i];

 }
 
 sort(a,a+n);
 sort(b,b+n);
 
 sumbn=suma(b,n);
 sumbp=0;
 gr=n-1;
 for(int i=n-1;i>=0;i--)
 {
         
 for(int j=gr;j>=0;j--)
 {
 
  if(a[i]>=b[j])
    { gr=j;break;} 
  
   sumbn-=b[j];
   sumbp+=b[j];
          
 }
 
 zbir+=(gr+1)*a[i]-(n-gr-1)*a[i]+sumbp-sumbn; 
 }
 cout<<zbir;

 return 0;  
}
