#include<iostream>
#include<stdio.h>
#include<math.h>


using namespace std;

long long mat[1000][1000];

int main()
{
    
 int n,m,k,v,x,y,max=0,maxx,maxy,a;
 cin>>n>>m>>k;
 
 for(int i=0;i<n;i++)
         for(int j=0;j<m;j++)  
                 mat[i][j]=m+n+1;
         
 for(int i=0;i<k;i++)
 {
 
  cin>>x>>y>>v;
  x--;y--;

  for(int j=0;j<n;j++)
          for(int z=0;z<m;z++)
                 { if((abs(x-j)+abs(y-z))%v==0) a=(abs(x-j)+abs(y-z))/v;
                   else a=(abs(x-j)+abs(y-z)+v-(abs(x-j)+abs(y-z))%v)/v;
                  if(mat[j][z]>a)
                    mat[j][z]=a;
                    }
 }
  for(int i=0;i<n;i++)
          for(int j=0;j<m;j++)
          if(max<mat[i][j])
          {max=mat[i][j];maxx=i;maxy=j;}
          
 
 maxx++;maxy++;
 cout<<maxx<<" "<<maxy; 
  
 return 0;     
}
