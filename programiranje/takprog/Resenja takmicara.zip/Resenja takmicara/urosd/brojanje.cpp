#include<stdio.h>
#include<iostream>
#include<algorithm>
#include<cstdlib>
using namespace std;
int n,q,a[1000000],b[1000000],c[1000000],l[1000000],r[1000000],i,j,k,p,t;
bool cmp (int x,int y)
         {
              if (a[x]<a[y])
                 return true;
              return false;
         }
int findx (int x,int y,int z)
          {
               int t = (x+y)/2;
               if (a[t]==z)
                  return t;
               if (a[t]>z)
                    return findx(x,t,z);
               return findx (t+1,y,z);
          }
int main()
    {
          scanf("%d",&n);
          for (i=0;i<n;i++)
              scanf("%d",&a[i]);
          l[0]=1;
          for (i=1;i<n;i++)
              {
               for (j=i;j>=0;j--)
                   {
                    if (a[i]>=a[j])
                       l[i]++;
                    else 
                    break;
                   }    
              }
          r[n-1]=1;
          for (i=n-2;i>=0;i--)
              {
               r[i]++;
               for (j=i+1;j<=n-1;j++)
                   {
                    if (a[i]>a[j])
                       r[i]++;
                    else
                    break;
                   }
              }
          for (i=0;i<n;i++)
              {
               l[i]*=r[i];
              }
          for (i=0;i<n;i++)
              {
               r[i]=i;
              }    
          sort (r,r+n,cmp);    
          for (i=0;i<n;i++)
              {
               p=r[i];
               b[i]=l[p];
               c[i]=a[p];
              }
          j=0;
          l[0]=b[0];
          a[0]=c[0];
          for (i=1;i<n;i++)
              {
               if (c[i]==c[i-1])
                  l[j]+=b[i];
               else 
                    {
                     l[j+1]=b[i];
                     a[j+1]=c[i];
                     j+=1;
                    } 
              }
          scanf("%d", &q);
          for (i=0;i<q;i++)
              {
              scanf("%d",&p);
              k=findx(0,j,p);
              c[i]=l[k];
              }
          for (i=0;i<q;i++)
              printf ("%d\n",c[i]);
          return 0;    
    }
