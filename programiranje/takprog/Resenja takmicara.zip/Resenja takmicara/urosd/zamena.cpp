#include<stdio.h>
#include<iostream>
int n,a[1000000],i;
int main()
      {
       scanf("%d", &n);
       for (i=0;i<n;i++)
           scanf("%d", &a[i]);
       printf ("23");
       return 0;
      }
      
