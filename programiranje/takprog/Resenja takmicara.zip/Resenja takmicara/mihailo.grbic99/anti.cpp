#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;
int n,m,k,x,y,y1;
int a[1010][1010];
struct trag{
  int x;
  int y;
  long long v;       
}t[1010];
int abs(int w){
  if(w>=0){
    return w;         
  }
  return -w;    
}
int main(int argc, char *argv[])
{
    int min,max=-1;
    scanf("%d %d %d",&n,&m,&k);
    for(int i=0;i<k;i++){
      scanf("%d %d %d",&t[i].x,&t[i].y,&t[i].v);
      t[i].x--;
      t[i].y--;        
    }
    int q;
    
    for(int i=0;i<m;i++){
      for(int j=0;j<n;j++){
        min=-1;
        for(int b=0;b<k;b++){
          q=abs(i-t[b].x)+abs(j-t[b].y);
          if(q%t[b].v==0){
            q/=t[b].v;                
          }else{
            q/=t[b].v;
            q++;      
          }
          
          if((q<min)||(min==-1)){
            min=q;
              
                                   
          }  
        }
        if((j==0)&&(i==0)){
                             
        }
        if((max<min)){
          max=min;
          
          x=i;
          y=j;                               
        }        
      }
              
    }
    
    x++;
    y++;
    printf("%d %d",y,x);
    //4 4 2 2 3 1 4 1 4
    
    return EXIT_SUCCESS;
}
