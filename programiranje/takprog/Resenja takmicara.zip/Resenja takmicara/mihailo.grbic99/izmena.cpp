#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;
long long n,r,s,L=0,R=0,D=0,U=0,b,q,L1,D1,U1,R1,t,m;
char a[500010],e;
int abs(int w){
  if(w>=0){
    return w;         
  }
  return -w;     
}
int main(int argc, char *argv[])
{
    scanf("%lld %lld %lld",&n,&r,&s);
    m=abs(r)+abs(s);
    scanf("%c",&e);
    q=-1;
    for(int i=0;i<n;i++){
      scanf("%c",&a[i]);
      if(a[i]=='L'){
        L++;              
      }else{
        if(a[i]=='R'){
          R++;              
        }else{
          if(a[i]=='D'){
            D++;              
          }else{
            U++;      
          }      
        }      
      }
    
    if(r>0){
      R1=r;        
    }else{
      L1=-r;      
    }
    if(s>0){
      U1=s;        
    }else{
      D1=-s;      
    }
    }
    t=n;
    
    
    if((U1<U)&&(D1<D)&&(t>m)){
      
      if((U-U1)>(D-D1)){
        if(t-2*(D-D1)>=m){
        U1+=D-D1;
        t-=2*(D-D1);
        D1=D;}else{
          U1+=t-m;
          D1+=t-m;
          t=m;
                     
        }                  
      }else{
        if(t-2*(U-U1)>=m){
        D1+=U-U1;
        t-=2*(U-U1);
        U1=U;}else{
          D1+=t-m;
          U1+=t-m;
          t=m;         
        }      
      }                   
    }
    
    if((R1<R)&&(L1<L)&&(t>m)){
      if((R-R1)>(L-L1)){
        if(t-2*(L-L1)>=m){
        R1+=L-L1;
        t-=2*(L-L1);
        L1=L;}else{
          R1+=(t-m)/2;
          L1+=(t-m)/2;
          t=m;         
        }                  
      }else{
        if(t-2*(R-R1)>=m){
        L1+=R-R1;
        t-=2*(R-R1);
        R1=R;}else{
          L1+=(t-m)/2;
          R1+=(t-m)/2;
          t=m;           
        }      
      }                   
    }
   
    if((U>=U1)&&(D<=D1)&&(t>m)){
      if(t-2*(U-U1)>=m){
      
      D1+=U-U1;
      t-=2*(U-U1);
      U1=U;
      }else{
            
        D1+=(t-m)/2;
        U1+=(t-m)/2;
        t=m;      
      }                     
    }
    
    if((D>=D1)&&(U<U1)&&(t>m)){
      if(t-2*(D-D1)>=m){
      U1+=D-D1;
      t-=2*(D-D1);
      D1=D;}else{
        U1+=(t-m)/2;
        D1+=(t-m)/2;
        t=m;           
      }                     
    }
    
    if((L>=L1)&&(R<=R1)&&(t>m)){
      if(t-2*(L-L1)>=m){
      R1+=L-L1;
      t-=2*(L-L1);
      L1=L;
      }else{
        R1+=(t-m)/2;
        L1+=(t-m)/2;
        t=m;      
      }                     
    }
    
    if((R>=R1)&&(L<=L1)&&(t>m)){
      if(t-2*(R-R1)>=m){
      L1+=R-R1;
      t-=2*(D-D1);
      R1=R;}else{
        L1+=(t-m)/2;
        R1+=(t-m)/2;
        t=m;           
      }                     
    }
    
    U1+=(t-m)/2;
    D1+=(t-m)/2;
    b=abs(U-U1)+abs(D-D1)+abs(L-L1)+abs(R-R1);
    b/=2;
    
    
              
    
    q=b/2;
    
    printf("%lld %lld",q,b);
    
    return EXIT_SUCCESS;
}
