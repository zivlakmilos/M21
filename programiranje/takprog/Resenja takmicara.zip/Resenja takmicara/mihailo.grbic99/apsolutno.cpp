#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <stdio.h>
using namespace std;
int a[100010],b[100010],n;
long long c[100010],sum=0;
int main(int argc, char *argv[])
{
    scanf("%d",&n);
    for(int i=0;i<n;i++){
      scanf("%d",&a[i]);        
    }
    for(int i=0;i<n;i++){
      scanf("%d",&b[i]);        
    }
    sort(b,b+n);
    sort(a,a+n);
    c[0]=0;
    for(int i=0;i<n;i++){
      c[i+1]=c[i]+b[i];        
    }
    
    int j=0,q=n;
    for(int i=0;i<n;i++){
      while((a[i]>b[j])&&(j!=n)){
        if(j==n){
          q=i;
          
          break;         
        }else{
              
          j++;
        }           
      }
      sum+=c[n]-2*c[j]+(j+j-n)*a[i];        
    }
    
    for(q;q<n;q++){
      sum+=n*a[q]-c[n];             
    }
    printf("%lld",sum);
    
    
    
    return EXIT_SUCCESS;
}
