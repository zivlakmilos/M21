#include <cstdio>
#include <cstdlib>
#include <cmath>

using namespace std;

int main()
{
    //input
    long long n, i, j;
    scanf("%lld",&n);
    long long a[n];
    long long b[n];
    for(i=0L;i<n;i++) scanf("%lld",&a[i]);
    for(i=0L;i<n;i++) scanf("%lld",&b[i]);

    //variables
    long long sum = 0;

    //solution
    for(i=0L;i<n;i++)
    {
        //take the sum
        for(j=0L;j<n;j++)
        {
            sum+=abs(a[j]-b[j]);
        }
        //rotate
        for(j=n-1;j>=0;j--) a[j+1]=a[j];
        a[0] = a[n];
        a[n] = 0;
    }

    //output
    printf("%lld\n",sum);
    return 0;
}
