#include <cstdio>
#include <cstring>
#include <cstdlib>
using namespace std;

int main()
{
    int n, r, s,i;
    scanf("%d %d %d",&n,&r,&s);
    int x0 = 0;
    int y0 = 0;
    char potezi[n];
    for(i=0;i<n;i++) scanf("%c",&potezi[i]);
    int a=0, b=0;

    int U = 0,D = 0,L = 0,R = 0;
    int brPromena;
    int minBr;
    int x,y;
    /*for(i=0;i<n;i++)
    {
        if(potezi[i]=='R') R+=1;
            else
                if(potezi[i]=='L') L+=1;
                else
                    if(potezi[i]=='U') U+=1;
                    else D+=1;
        x=R-L;
        y=U-D;
    }*/

    int x = 0, y = 0, dX, dY, minX, minY, minBr;
    dX= r;
    dY= s;
    minX = dX;
    minY = dY;
    minBr = 0;

    for(i=0;i<n;i++)
    {
        if(potezi[i]=='R') x+=1;
        else
            if(potezi[i]=='L') x-=1;
            else
                if(potezi[i]=='U') y+=1;
                else y-=1;
        dX= r-x;
        dY= s-y;
        if(abs(dX)+abs(dY)<abs(minX)+abs(minY))
        {
            minX=dX;
            minY=dY;
            minBr=i+1;
        }
    }

    printf("%d %d",abs(minX)+abs(minY),b);

    return 0;
}
