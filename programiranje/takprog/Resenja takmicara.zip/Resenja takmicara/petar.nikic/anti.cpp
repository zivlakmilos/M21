#include <cstdio>
#include <cmath>
#include <cstdlib>
using namespace std;

int daljina(int x, int y, int trgX, int trgY, int trgV)
{
    int distX = abs(x-trgX);
    int distY = abs(y-trgY);
    if((distX+distY)%trgV!=0) return (distX+distY)/trgV+1;
    return (distX+distY)/trgV;
}

int popuniPolje(int x, int y, int trgX[], int trgY[], int trgV[], int k)
{
    int i;
    //int daljine[k];
    //daljine[0] = daljina(x,y,trgX[0],trgY[0],trgV[0]);
    int min = daljina(x,y,trgX[0],trgY[0],trgV[0]);
    for(i=0;i<k;i++)
    {
        int d = daljina(x,y,trgX[i],trgY[i],trgV[i]);
        if(d<min) min = d;
    }
    return min;
}

int main()
{
    int n,m,k,i,j;
    scanf("%d %d %d",&n,&m,&k);
    int skr[n][m]; //m=>x n=>y
    int trgX[k];
    int trgY[k];
    int trgV[k];
    for(i=0;i<k;i++)
    {
        scanf("%d %d %d",&trgY[i],&trgX[i],&trgV[i]);
        trgY[i]-=1;
        trgX[i]-=1;
    }
    int max = 0,maxX=0,maxY=0;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            skr[i][j]=popuniPolje(j,i,trgX,trgY,trgV,k);
            if(skr[i][j]>max)
            {
                max = skr[i][j];
                maxX = j+1;
                maxY = i+1;
            }
        }
    }
    printf("%d %d\n",maxY,maxX);
    return 0;
}
