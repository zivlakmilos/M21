#include <stdio.h>
#include <map>
#include <utility>
#include <algorithm>
using namespace std;

int x[1000006],s,e,mid,res,vp,p[1000006],pos[1000006],q,w;

long long l[1000006],d,i,n;

map <int,long long> m;

int main()
{
    scanf ("%lld",&n);
    scanf ("%d",&x[1]);
    l[1]=0;
    vp=1;
    p[1]=x[1];
    pos[1]=1;
    for (i=2;i<=n;i++)
    {
        scanf ("%d",&x[i]);
        s=1;
        e=vp;
        res=0;
        while (s<=e)
        {
              mid=(s+e)/2;
              if (x[i]>p[mid])
              {
                  e=mid-1;
                  continue;
              }
              if (x[i]<=p[mid])
              {
                  s=mid+1;
                  res=mid;
                  continue;
              }
        }
        if (res!=0)
        l[i]=pos[res];
        else
        l[i]=0;
        vp=res+1;
        p[vp]=x[i];
        pos[vp]=i;
    }
    d=n+1;
    m[x[n]]=((i-l[n])*(d-n-1)+n-l[n])%1000000007;
    vp=1;
    p[1]=x[n];
    pos[1]=n;
    for (i=n-1;i>=1;i--)
    {
        s=1;
        e=vp;
        res=0;
        while (s<=e)
        {
              mid=(s+e)/2;
              if (x[i]>=p[mid])
              {
                 e=mid-1;
                 continue;
              }
              if (x[i]<p[mid])
              {
                 s=mid+1;
                 res=mid;
                 continue;
              }
        }
        if (res!=0)
        d=pos[res];
        else
        d=n+1;
        vp=res+1;
        p[vp]=x[i];
        pos[vp]=i;
        m[x[i]]=((i-l[i])*(d-i-1)+i-l[i]+m[x[i]])%1000000007;
    }
    scanf ("%d",&q);
    for (i=1;i<=q;i++)
    {
        scanf ("%d",&w);
        printf ("%lld\n",m[w]);
    }
}
        
              
        
