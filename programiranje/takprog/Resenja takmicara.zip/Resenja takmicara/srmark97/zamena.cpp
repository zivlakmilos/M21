#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <map>
using namespace std;

int n,i,j,a,d1[20],d2[20][20],d3[100005],q1[20],q2[20][20],sol,pom,bc,t,c[100005][20],br,r,co,mn;

map <int,int> mm[20],rr[20],ii[20];

int main()
{
    scanf ("%d",&n);
    for (i=1;i<=n;i++)
    {
        scanf ("%d",&t);
        pom=t;
        bc=0;
        while (pom>0)
        {
              bc++;
              c[i][bc]=pom%10;
              pom=pom/10;
        }
    }
    if (bc==1)
    {
              for (i=2;i<=n;i++)
              {
                  sol=sol+abs(c[i][1]-c[i-1][1]);
              }
              printf ("%d",sol);
    }
    else
    {
        if (bc==2)
        {
                  for (i=1;i<=n;i++)
                  {
                      for (j=0;j<10;j++)
                      {
                          if ((d2[j][c[i][2]]+abs(j-c[i][1])>d2[c[i][1]][c[i][2]])&&(q2[j][c[i][2]]==1))
                          d2[c[i][1]][c[i][2]]=d2[j][c[i][2]]+abs(j-c[i][1]);
                          if ((d2[c[i][1]][j]+abs(j-c[i][2])>d2[c[i][1]][c[i][2]])&&(q2[c[i][1]][j]==1))
                          d2[c[i][1]][c[i][2]]=d2[c[i][1]][j]+abs(j-c[i][2]);
                      }
                      q2[c[i][1]][c[i][2]]=1;
                  }
                  sol=0;
                  for (i=1;i<10;i++)
                  {
                      for (j=0;j<10;j++)
                      {
                          if (d2[i][j]>sol)
                          sol=d2[i][j];
                      }
                  }
                  printf ("%d",sol);
        }
        else
        {
            if (n<=1000)
            {
            sol=0;
            for (i=2;i<=n;i++)
            {
                for (j=i-1;j>=1;j--)
                {
                    br=0;
                    for (a=1;a<=bc;a++)
                    {
                        if (c[i][a]!=c[j][a])
                        {
                           br++;
                           r=abs(c[i][a]-c[j][a]);
                        }
                        if (br>1)
                        break;
                    }
                    if ((br==1)&&(d3[j]+r>d3[i]))
                    {
                    d3[i]=d3[j]+r;
                    }
                }
                if (d3[i]>sol)
                sol=d3[i];
            }
            printf ("%d",sol);
            }
            else
            {
                sol=0;
                for (i=1;i<=n;i++)
                {
                    for (j=1;j<=bc;j++)
                    {
                        co=1;
                        br=0;
                        for (a=1;a<=bc;a++)
                        {
                            if (a!=j)
                            {
                                     br=br+co*c[i][a];
                                     co=co*10;
                            }
                            else
                            mn=c[i][a];
                        }
                        if (ii[j][br]==1)
                        {
                             mm[j][br]=mm[j][br]+abs(rr[j][br]-mn);
                        }
                        ii[j][br]=1;
                        rr[j][br]=mn;
                        if (mm[j][br]>sol)
                        sol=mm[j][br];
                    }
                }
                printf ("%d",sol);
            }             
        }
    }
}
                    
                        
                          
                          
                          
                          
                          
                          
                          
              
