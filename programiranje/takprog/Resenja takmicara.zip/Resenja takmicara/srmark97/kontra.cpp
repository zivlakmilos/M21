#include <stdio.h>
#include <queue>
using namespace std;

int n,m,k,bk,bio[1005][1005],p1,p2;

char t[1006][1006],c;

long long m1,m2,vmax,v;

struct moja
{
       int x,y;
       long long v1,v2;
}r[10];

priority_queue <struct moja> pq;

bool operator< (struct moja qq,struct moja ww)
{
     return (qq.v1*ww.v2>qq.v2*ww.v1);
}

void dijkstra (int q)
{
     int xx,yy;
     if (q>n*m)
     return;
     while (1)
     {
           r[1]=pq.top();
           pq.pop();
           if (bio[r[1].x][r[1].y]==1)
           {
               continue;
           }
           else
           break;
     }
     bio[r[1].x][r[1].y]=1;
     if (r[1].v1*m2>m1*r[1].v2)
     {
         m1=r[1].v1;
         m2=r[1].v2;
         p1=r[1].x;
         p2=r[1].y;
     }
     xx=r[1].x;
     yy=r[1].y;
     if (t[xx-1][yy]=='0')
        {
              r[0].x=xx-1;
              r[0].y=yy;
              r[0].v1=r[1].v1+1;
              r[0].v2=r[1].v2;
              pq.push(r[0]);
        }
        if (t[xx+1][yy]=='0')
        {
              r[0].x=xx+1;
              r[0].y=yy;
              r[0].v1=r[1].v1+1;
              r[0].v2=r[1].v2;
              pq.push(r[0]);
        }
        if (t[xx][yy-1]=='0')
        {
              r[0].x=xx;
              r[0].y=yy-1;
              r[0].v1=r[1].v1+1;
              r[0].v2=r[1].v2;
              pq.push(r[0]);
        }
        if (t[xx][yy+1]=='0')
        {
              r[0].x=xx;
              r[0].y=yy+1;
              r[0].v1=r[1].v1+1;
              r[0].v2=r[1].v2;
              pq.push(r[0]);
        }
        dijkstra(q+1);
        return;
}
                                      


int main()
{
    int xx,yy,i,j;
    scanf ("%d%d",&n,&m);
    scanf ("%c",&c);
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=m;j++)
        {
            scanf ("%c",&t[i][j]);
            if (t[i][j]=='1')
            bk++;
        }
        scanf ("%c",&c);
    }
    scanf ("%d",&k);
    for (i=1;i<=k;i++)
    {
        scanf ("%d%d%d",&xx,&yy,&v);
        bio[xx][yy]=1;
        if (t[xx-1][yy]=='0')
        {
              r[0].x=xx-1;
              r[0].y=yy;
              r[0].v1=1;
              r[0].v2=v;
              pq.push(r[0]);
              p1=xx-1;
              p2=yy;
        }
        if (t[xx+1][yy]=='0')
        {
              r[0].x=xx+1;
              r[0].y=yy;
              r[0].v1=1;
              r[0].v2=v;
              pq.push(r[0]);
              p1=xx+1;
              p2=yy;
        }
        if (t[xx][yy-1]=='0')
        {
              r[0].x=xx;
              r[0].y=yy-1;
              r[0].v1=1;
              r[0].v2=v;
              pq.push(r[0]);
              p1=xx;
              p2=yy-1;
        }
        if (t[xx][yy+1]=='0')
        {
              r[0].x=xx;
              r[0].y=yy+1;
              r[0].v1=1;
              r[0].v2=v;
              pq.push(r[0]);
              p1=xx;
              p2=yy+1;
        }
    }
    m1=1;
    m2=1;
    if (k==n*m-bk)
    {
    p1=xx;
    p2=yy;
    }
    dijkstra(k+bk+1);
    printf ("%d %d",p1,p2);
}
    
    
    
              
