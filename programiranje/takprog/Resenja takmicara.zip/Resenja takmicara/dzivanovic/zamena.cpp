#include <cstdio>
using namespace std;
int pows[8] = {1,10,100,1000,10000,100000,1000000,10000000};
#define abs(a) ( (a) > 0  ? (a) : -(a))
struct
{
    int sol;
    char cif;
    bool is;
} dp[7][1000100];
int n;
int a[100100];
int sol;
int num;
int main()
{
    sol = 0;
    scanf("%d",&n);
    for(int i = 0; i < n; i++)
        scanf("%d",&a[i]);
    while (pows[num]<=a[0])
        num++;
    for(int i = 0; i < n; i++)
    {
        int tmp = 0;
        for(int j = 0; j < num; j++)
        {
            int w = a[i]/pows[j+1]*pows[j]+a[i]%pows[j];
            int c = (a[i]/pows[j])%10;
            if ( dp[j][w].is && dp[j][w].sol + abs(c-dp[j][w].cif) > tmp)
                tmp = dp[j][w].sol+abs(c-dp[j][w].cif);
        }
        if (tmp > sol)
            sol = tmp;
        for(int j = 0; j < num; j++)
        {
            int w = a[i]/pows[j+1]*pows[j]+a[i]%pows[j];
            int c = (a[i]/pows[j])%10;
            dp[j][w].cif = c;
            dp[j][w].is = true;
            dp[j][w].sol = tmp;
        }
    }
    printf("%d\n",sol);
    return 0;
}
/*
6
8823
2145
2185
3385
4145
4445

*/
