#include <cstdio>
#include <algorithm>
#define M 1000000007
using namespace std;
struct zad
{
    int dos;
    int l,d;
} a[1000100];
bool cmp(const zad a, const zad b)
{
    return a.dos < b.dos;
}
struct stt
{
    int dos;
    int pos;
} st[1000100];
struct sol
{
    int dos;
    int val;
} b[1000100];
int k;
int stn;
int n;
int main()
{
    scanf("%d",&n);
    for(int i =0 ;i < n; i++)
        scanf("%d",&a[i].dos);
    st[0].dos = 1000000010;
    st[0].pos = -1;
    stn = 1;
    for(int i = 0; i < n; i++)
    {
        stt tren;
        tren.dos = a[i].dos;
        tren.pos = i;
        while(tren.dos >= st[stn-1].dos)
            stn--;
        a[i].l = tren.pos-st[stn-1].pos;
        st[stn++] = tren;
    }
    st[0].pos = n;
    stn = 1;
    for(int i = n-1; i >= 0; i--)
    {
        stt tren;
        tren.dos = a[i].dos;
        tren.pos = i;
        while(stn && tren.dos > st[stn-1].dos)
            stn--;
        a[i].d = st[stn-1].pos-tren.pos;
        st[stn++] = tren;
    }
    sort(a,a+n,cmp);
   // for(int i = 0; i < n; i++)
   //     printf("%d %d\n",a[i].dos,a[i].l*a[i].d);
    b[0].dos = -1;
    k = 1;
    for (int i = 0; i < n; i++)
    {
        if (a[i].dos == b[k-1].dos)
            b[k-1].val = (1ll*b[k-1].val + 1ll*a[i].l*a[i].d)%M;
        else
        {
            b[k].dos = a[i].dos;
            b[k++].val = (1ll*a[i].l*a[i].d)%M;
        }
    }
    //for(int i = 0; i < k; i++)
    //     printf("%d %d\n",b[i].dos,b[i].val);
    int q;
    scanf("%d",&q);
    for(int i = 0; i < q; i++)
    {
        int x;
        scanf("%d",&x);
        int bot = 0, top = k-1,mid;
        while(bot <= top)
        {
            mid = (top+bot)/2;
            if (b[mid].dos > x)
                top = mid-1;
            else if (b[mid].dos < x)
                bot = mid+1;
            if (b[mid].dos == x)
                break;
        }
        if (x == b[mid].dos)
            printf("%d\n",b[mid].val);
        else printf("0\n");
    }
    return 0;
}
/*
5
1 2 3 4 3
3
2
3
4

6
3 3 2 3 3 4
3
3
2
4
*/
