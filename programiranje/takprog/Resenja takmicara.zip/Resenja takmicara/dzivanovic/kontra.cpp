#include <cstdio>
#include <queue>
using namespace std;
int dx[] = {-1,0,1,0};
int dy[] = {0,1,0,-1};
struct gl
{
    int x,y;
    int t,k,v;
};
gl makeGl(int x, int  y,int t,int k, int v)
{
    gl a;
    a.x = x; a.y = y; a.t =t; a.k =k; a.v = v;
    return a;
}
queue<gl> q[2];
int n,m,k;
int a[1010][1010];
int b[1010][1010];
int fre;
int main()
{
    scanf("%d %d",&n,&m);

    fre = 0;
    for(int i = 0; i < n; i++)
    {
        char s[1010];
        scanf("%s",s);
        for(int j = 0; j < m; j++)
        {
            if (s[j] == '0')
                fre++;
            else
                a[i][j] = -1;
        }
    }
    scanf("%d",&k);
    for(int i = 0; i < k; i++)
    {
        int x,y,v;
        scanf("%d %d %d",&x,&y,&v);
        q[1].push(makeGl(x-1,y-1,1,v-1,v));
    }
    bool pot = 1;
    while (fre)
    {
        while(!q[pot].empty())
        {
            gl g = q[pot].front();
            q[pot].pop();
            if (a[g.x][g.y] != 0 && a[g.x][g.y] <= g.t && b[g.x][g.y] >= g.v)
                continue;
            if (a[g.x][g.y] == 0)
                fre--;
            if (a[g.x][g.y] > g.t || a[g.x][g.y] == 0)
            {
                a[g.x][g.y] = g.t;
                b[g.x][g.y] = g.v;
            }
            for(int w = 0; w < 4; w++)
            {

                int x = g.x+dx[w];
                int y = g.y+dy[w];
                if (x < 0 || x>=n || y < 0 || y >= m)
                    continue;
                int v = g.v;
                int k = g.k+1;
                int t = g.t+k/v;
                k = k % v;
                if (a[x][y] == 0)
                {
                    q[t%2].push(makeGl(x,y,t,k,v));
                }
                else
                {
                    if (a[x][y] == -1)
                        continue;
                    if (a[x][y] <= t && b[x][y] > v)
                        continue;
                    q[t%2].push(makeGl(x,y,t,k,v));
                }
            }
        }
        pot = !pot;
    }
    int mx = -1;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            if (a[i][j] > mx)
                mx = a[i][j];
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            if (a[i][j] == mx)
        {
            printf("%d %d\n",i+1,j+1);
            return 0;
        }
    return 0;
}
/*
5 7
0010000
0100000
0000110
0000000
0000000
2
1 2 3
4 4 1
*/
