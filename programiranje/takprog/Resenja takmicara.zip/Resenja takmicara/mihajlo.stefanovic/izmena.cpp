#include <bits/stdc++.h>

using namespace std;

int main()
{
    char q[500000];
    int i,n,r,s,x=0,y=0,minn,px=0,py=0,stampa=0,pr,ps;
    scanf("%d%d%d",&n,&r,&s);
    scanf("\n");
    minn=abs(r-x)+abs(s-y);
    if(x<r) pr=0;
            else if(x>r)pr=1;
            else pr=-1;
            if(y<s) ps=0;
            else if(y>s)ps=1;
            else ps=-1;
    scanf("%s",q);
    for(i=0;i<n;i++)
    {
        if(q[i]=='R') x+=1;
        else if(q[i]=='L') x-=1;
        else if(q[i]=='U') y+=1;
        else if(q[i]=='D') y-=1;
        if(abs(r-x)+abs(s-y)<minn)
        {
            minn=abs(r-x)+abs(s-y);
            px=x;
            py=y;
            if(x<r) pr=0;
            else if(x>r)pr=1;
            else pr=-1;
            if(y<s) ps=0;
            else if(y>s)ps=1;
            else ps=-1;
        }
    }
    printf("%d%d",px,py);
    ///////////////////////////
       if(pr==0)
       {
           for(i=0;i<n;i++)
           {
            if(q[i]=='L')
            {
                px+=2;
                stampa+=1;
            }
            if(px==r-1||px==r) break;
           }
    while(px!=r)
    {
        if(ps==0)
        {
                py+=1;
                px+=1;
                stampa+=1;
        }
        else if(ps==1)
        {
            py-=1;
            px+=1;
            stampa+=1;
        }
        else
        {
            px+=1;
            stampa+=1;
        }
    }
       }
    if(pr==1)
       {
           for(i=0;i<n;i++)
           {
            if(q[i]=='R')
            {
                px-=2;
                stampa+=1;
            }
            if(px==r+1||px==r) break;
           }
    while(px!=r)
    {
        if(ps==0)
        {
                py+=1;
                px-=1;
                stampa+=1;
        }
        else if(ps==1)
        {
            py+=1;
            px-=1;
            stampa+=1;
        }
        else
        {
           px-=1;
            stampa+=1;
        }
    }
       }
    ////////////////////////////
    if(ps==0)
       {
           for(i=0;i<n;i++)
           {
            if(q[i]=='D')
            {
                py+=2;
                stampa+=1;
            }
            if(py==s-1||py==s) break;
           }
           printf("%d",s);
    while(py!=s)
    {
        if(pr==0)
        {
                px+=1;
                py+=1;
                stampa+=1;
        }
        else if(pr==1)
        {
            px-=1;
            py+=1;
            stampa+=1;
        }
        else
        {
            py+=1;
            stampa+=1;
        }
    }
    }
    else if(ps==1)
       {
           for(i=0;i<n;i++)
           {
            if(q[i]=='U')
            {
                py-=2;
                stampa+=1;
            }
            if(py==r+1||py==r) break;
           }
    while(py!=s)
    {
        if(pr==0)
        {
                px+=1;
                py-=1;
                stampa+=1;
        }
        else if(pr==1)
        {
            px-=1;
            py-=1;
            stampa+=1;
        }
        else
        {
             py-=1;
            stampa+=1;
        }
    }
    }
    printf("%d %d",stampa,4);
    return 0;
}
