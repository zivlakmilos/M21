#include <bits/stdc++.h>
#define par pair<long long,int>
using namespace std;

int comp(void const *a,void const *b)
{
    return *(int*)a-*(int*)b;
}

int main()
{
    int n,i,p1=0,prvi[100000],drugi[100000];
    long long sumsum=0,sum=0;
    par pomoc[100000];
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
    scanf("%d",&prvi[i]);
    }
    qsort(prvi,n,4,comp);
    for(i=0;i<n;i++)
    {
        scanf("%d",&drugi[i]);
    }
    qsort(drugi,n,4,comp);
    for(i=0;i<n;i++)
    {
        while(drugi[i]>prvi[p1])
        {
            pomoc[p1].first=sum;
            pomoc[p1].second=i;
            p1+=1;
            if(p1==n) break;
        }
        sum+=drugi[i];
        if(p1==n) break;
    }
    for(i=p1;i<n;i++)
    {
        sumsum+=prvi[i]*n-sum;
    }
    for(i=0;i<p1;i++)
    {
        sumsum+=(prvi[i]*pomoc[i].second)-pomoc[i].first;
        sumsum+=sum-pomoc[i].first-(prvi[i]*(n-pomoc[i].second));
    }
    printf("%lld",sumsum);
    return 0;
}
