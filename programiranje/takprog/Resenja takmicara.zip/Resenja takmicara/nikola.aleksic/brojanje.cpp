#include<stdio.h>
#include<algorithm>
using namespace std;
long long int n,q,a[1000001],b[1000001],c[1000001],x[1000001],j,i,k,upit,l,d,m,maxi;
int main()
{
	scanf("%lld",&n);
	for(i=1;i<=n;i++)
	{scanf("%lld",&a[i]);
	 b[i]=a[i];
	 c[i]=0;
	} sort(b+1,b+n+1);
	x[1]=b[1];
	j=2;
	for(i=2;i<=n;i++)
	if(b[i]!=b[i-1])
     {
     	x[j]=b[i];
     	j++;
     }
	for(i=1;i<=n;i++)
	{maxi=a[i];
	for(k=i;k<=n;k++)
	{if(a[k]>maxi)
	maxi=a[k];
	l=1;
	d=j-1;
	while(l<d)
	{m=(l+d)/2;
	if(x[m]==maxi)
	  {c[m]=(c[m]+1)%1000000007;
	   break;
	  }else if(x[m]<maxi)
	         l=m+1;
	         else d=m;

	} if(l==d && x[l]==maxi)
	  c[l]=(c[l]+1)%1000000007;
	}
	}
  scanf("%lld",&q);
  for(i=0;i<q;i++)
  {scanf("%lld",&upit);
	l=1;
	d=j-1;
	k=0;
	while(l<d)
	{
		m=(l+d)/2;
		if(x[m]==upit)
	  {printf("%lld\n",c[m]);
	   k=1; break;
	  }else if(x[m]<upit)
	         l=m+1;
	         else d=m;


	}
	if(k==0)
	if(l==d)
	{
		if(x[l]==upit)
	printf("%lld\n",c[l]);
	else
	printf("0\n");

	}


} return 0;
}
