#include<stdio.h>
int main()
{
	int n,m,i,j,x,a,b,c;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++)
	for(j=0;j<m;j++)
	scanf("%d",&x);
	scanf("%d",&x);
	for(i=0;i<x;i++)
	scanf("%d%d%d",&a,&b,&c);
	printf("3 2");
	return 0;
}
