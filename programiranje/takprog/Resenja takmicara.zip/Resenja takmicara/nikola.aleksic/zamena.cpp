#include<stdio.h>
#include<algorithm>
#include<set>
using namespace std;

int n,i,j,d=0,pom,r,k,t,sol=0;
int a[100000],b[10000000];

set<int> x;
int stepen(int d)
{
	if(d==0)
	return 1;
	if(d==1)
	return 10;
	if(d==2)
	return 100;
	if(d==3)
	return 1000;
	if(d==4)
	return 10000;
	if(d==5)
	return 100000;
	if(d==6)
	return 1000000;
	if(d==7)
	return 10000000;
}
int main()
{
  scanf("%d",&n);
  for(i=0;i<n;i++)
     {
     	scanf("%d",&a[i]);
        b[a[i]]=0;
	 }
	 for(i=0;i<10000000;i++)
	 b[i]=0;
	 pom=a[0];
	 while(pom>0)
      {
      	pom/=10;
      	d++;
      }
      x.insert(a[0]);
	 for(i=1;i<n;i++)
	   { r=a[i];
	   	for(j=0;j<d;j++)
	   	  {
	   	 	pom=(r/stepen(j))%10;
	   	 	for(k=0;k<=pom;k++)
	   	 	 {if(x.erase(a[i]-k*stepen(j))!=0)
              {if(b[a[i]-k*stepen(j)]+k>b[a[i]])
              b[a[i]]=b[a[i]-k*stepen(j)]+k;
              x.insert(a[i]-k*stepen(j)); }
	   	 	 }
	   	 	 for(k=0;k<=9-pom;k++)
	   	 	 {if(x.erase(a[i]+k*stepen(j))!=0)
              {if(b[a[i]+k*stepen(j)]+k>b[a[i]])
              b[a[i]]=b[a[i]+k*stepen(j)]+k;
              x.insert(a[i]+k*stepen(j)); }
	   	 	 }
	   	 	 	   	  }
	   	 	 	   	  x.insert(a[i]);
	   } for(i=0;i<n;i++)
          if(b[a[i]]>sol)
          sol=b[a[i]];
          printf("%d",sol);
          return 0;

}
