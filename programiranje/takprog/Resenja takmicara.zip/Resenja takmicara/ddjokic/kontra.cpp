#include <cstdio>
#include <cstdlib>
#include <queue>
#include <utility>

#define X_cor first
#define Y_cor second

#define INF 10000001

using namespace std;

int N,M,K;

int sol_dist;
pair<int, int> sol;

int Z[1001][1001];
int dist[1001][1001];
int bfs[1001][1001];

queue< pair<int, int> > q;

char t;
int x,y,v;

void update(int x, int y, int x_prev, int y_prev)
{
    if (x >= 1 && x <= N && y >= 1 && y <= M && !Z[x][y])
    {
        if (dist[x][y] > (bfs[x_prev][y_prev] + 1) / v  )
        {
           bfs[x][y] = bfs[x_prev][y_prev] + 1;
           dist[x][y] = bfs[x][y] / v;

           q.push( make_pair(x, y) );

           if (dist[x][y] > sol_dist)
           {
               sol_dist = dist[x][y];
               sol = make_pair(x,y);
           }
        }
    }
}


int main()
{

    scanf("%d %d", &N, &M);

    for (int i = 1; i <= N; i++)
    {
        scanf("\n");
        for (int j = 1; j <= M; j++)
        {
            scanf("%c", &t);
            if (t == '1') Z[i][j] = 1;
            else Z[i][j] = 0;
            dist[i][j] = INF;
        }
    }


    scanf("%d", &K);

    sol_dist = 0;

    for (int i = 1; i <= K; i++)
    {
        scanf("%d %d %d", &x, &y, &v);

        // bfs, x, y, v;
        bfs[x][y] = 0;

        q.push( make_pair(x, y) );

        while(!q.empty())
        {
            pair<int, int> C = q.front();

            update( C.X_cor+1, C.Y_cor, C.X_cor, C.Y_cor);
            update( C.X_cor-1, C.Y_cor, C.X_cor, C.Y_cor);
            update( C.X_cor, C.Y_cor+1, C.X_cor, C.Y_cor);
            update( C.X_cor, C.Y_cor-1, C.X_cor, C.Y_cor);

            q.pop();
        }
    }


    printf("%d %d\n", sol.X_cor, sol.Y_cor);


    return 0;
}
