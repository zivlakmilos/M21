#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>

using namespace std;

int A[1000001];
int ST_Max[1000001]; // Segment tree max
int N;
int Q;

void init_st(int idx, int L, int R)
{
    if (L==R)
    {
        ST_Max[idx] = A[L];
        return;
    }

    int mid = (L+R)/2;

    init_st(2*idx, L, mid);
    init_st(2*idx+1, mid+1, R);

    ST_Max[idx] = max(ST_Max[2*idx], ST_Max[2*idx+1]);
}


int get_st(int idx, int L, int R, int A, int B)
{
    if (L == A && R == B) return ST_Max[idx];

    int mid = (L+R) / 2;

    if (A > mid)   return get_st(2*idx+1, mid+1, R, A, B);
    if (B < mid+1) return get_st(2*idx, L, mid, A, B );

    return max(get_st(2*idx, L, mid, A, mid), get_st(2*idx+1, mid+1, R, mid+1, B));
}


int main()
{
    scanf("%d", &N);

    for (int i = 1; i <= N; i++)
    {
        scanf("%d", A+i);
    }

    init_st(1, 1, N);


    scanf("%d", &Q);

    for (int test = 1; test <= Q; test++)
    {
        int k;
        scanf("%d", &k);

        int sol = 0;

        for (int i = 1; i <= N; i++)
            for (int j = i; j <= N; j++)
            {
                if ( get_st(1,1,N,i,j) == k) sol++;
            }

        printf("%d\n", sol);

    }



    return 0;
}
