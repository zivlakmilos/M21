// zamena
#include <cstdlib>
#include <cstdio>
#include <map>
#include <cmath>

using namespace std;

int A[10][1000001]; // ~ 38 MiB
int Z[10001]; // < 1 MiB
int D[10001][10]; // < 1 MiB
int id;
int C;
int sol;

int update(int x, int idx)
{
    int d = 1;
    int y;
    int z;
    for (int t = 1; t <= C; t++)
    {
        y = (x/(d*10))*(d) + x%d;  // ostatak
        z = x/(d)%10;              // t-ta cifra
        d*=10;
        D[idx][t] = z;

        if (A[t][y] == 0) A[t][y] = idx;
        else
        {
            if (Z[idx] < Z[A[t][y]] + abs(D[A[t][y]][t] - z))
            {
                  Z[idx] = Z[A[t][y]] + abs(D[A[t][y]][t] - z);
                  if (Z[idx] > sol) sol = Z[idx];
            }
        }
    }
}

int find_C(int x)
{
    C = 0;
    while(x>0)
    {
        x/=10;
        C++;
    }
}


int main()
{
    int N;

    scanf("%d", &N);

    for (int idx = 1; idx <= N; idx++)
    {
        scanf("%d", &id);
        if (idx==1) find_C(id);
        update(id, idx);
    }

    printf("%d\n", sol);

    return 0;
}
