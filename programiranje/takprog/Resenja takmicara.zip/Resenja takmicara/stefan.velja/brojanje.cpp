#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

struct query
{
    int broj, index, rez; // Broj za koji pita, index kao koji kveri je po redu, rez kao rezultat
};

struct broj
{
    int val, rb;
};

const int N=1000005;
//const int D=1048580;
const int D=16;
const int MOD=1000000007;

query q[N];
broj a[N];

int n, qn;
int aa[N];
int drvo[2*D];

bool s1(query q1, query q2)
{
    return q1.broj>q2.broj;
}

bool s2(query q1, query q2)
{
    return q1.index<q2.index;
}

bool operator<(broj b1, broj b2)
{
    return b1.val>b2.val;
}

int finddrvol(int index, int l, int r, int l0, int r0) // mesto koje trazi, leva granica trazenog, desna granica trazenog, leva/desna granica posmatranog
{
    if(r0<l) return -1;
    if(l0>r) return -1;
    if(drvo[index]==0) return -1;
    if(l0>=l && r0<=r)
    {
        if(l0==r0) return index;
        if(drvo[2*index+1]) return finddrvol(2*index+1, l, r, (l0+r0)/2+1, r0);
        else return finddrvol(2*index, l, r, l0, (l0+r0)/2);
    }
    else return max(finddrvol(2*index+1, l, r, (l0+r0)/2+1, r0), finddrvol(2*index, l, r, l0, (l0+r0)/2));
}

int finddrvod(int index, int l, int r, int l0, int r0) // mesto koje trazi, leva granica trazenog, desna granica trazenog, leva/desna granica posmatranog
{
    if(r0<l) return 3*D;
    if(l0>r) return 3*D;
    if(drvo[index]==0) return 3*D;
    if(l0>=l && r0<=r)
    {
        if(l0==r0) return index;
        if(drvo[2*index]) return finddrvod(2*index, l, r, l0, (l0+r0)/2);
        else return finddrvod(2*index+1, l, r, (l0+r0)/2+1, r0);
    }
    else return min(finddrvod(2*index+1, l, r, (l0+r0)/2+1, r0), finddrvod(2*index, l, r, l0, (l0+r0)/2));
}

void push(int index)
{
    while(index>0)
    {
        drvo[index]=1;
        index/=2;
    }
}

int main()
{
    scanf("%i", &n);
    for(int i=0; i<n; i++)
    {
        scanf("%i", &a[i].val);
        a[i].rb=i;
        aa[i]=a[i].val;
    }
    scanf("%i", &qn);
    for(int i=0; i<qn; i++)
    {
        scanf("%i", &q[i].broj);
        q[i].index=i;
    }
    sort(q, q+qn, s1); // Sortira po brojevima opadajuce
    sort(a, a+n); // Sortira svejedno, opadajuce
    push(D);
    push(D+n+1);
    int br=0;
    for(int i=0; i<qn; i++)
    {
        if(i>0 && q[i].broj==q[i-1].broj)
        {
            q[i].rez=q[i-1].rez;
            continue;
        }
        if(q[i].broj>a[br].val)
        {
            q[i].rez=0;
            continue;
        }
        else if(q[i].broj<a[br].val)
            while(q[i].broj<a[br].val)
            {
                push(D+a[br].rb+1);
                br++;
                /*int step=2;
                for(int ii=1; ii<2*D; ii++)
                {
                    //for(int k=0; k<32/step; k++) printf(" ");
                   // printf("%i", drvo[ii]);
                    //for(int k=0; k<32/step; k++) printf(" ");

                    if((ii+1)%step==0)
                    {
                        cout << endl;
                        step *=2;
                    }
                }
                cout << endl << endl;*/
            }
        //cout << q[i].broj << endl;
        while(q[i].broj==a[br].val)
        {
            int drvol=finddrvol(1, D, a[br].rb+D, D, 2*D-1); // trazi najdesnije drvo
            int drvod=finddrvod(1, a[br].rb+D+2, 2*D-1, D, 2*D-1);
            drvol-=D+1;
            drvod-=D+1;
            long long rez2=(a[br].rb-drvol)*(drvod-a[br].rb);
            rez2=rez2%MOD;
            q[i].rez+=rez2;
            //printf("## %i  %i %i %i      %i\n", q[i].broj, a[br].rb, drvol, drvod, q[i].rez);
            push(a[br].rb+D+1);
            //int drvod=finddrvod(a[br].rb+1);
            br++;
        }
    }
    sort(q, q+qn, s2);
    for(int i=0; i<qn; i++)
        printf("%i\n", q[i].rez);
    return 0;
}
/*
11
10 1 2 4 5 3 10 8 7 9 2
5
2
7
6
1
4

5
1 2 3 4 3
3
2
3
4
*/
