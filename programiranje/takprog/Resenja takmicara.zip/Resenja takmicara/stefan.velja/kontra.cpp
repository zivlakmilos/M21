#include <iostream>
#include <cstdio>
#include <queue>
#include <algorithm>

using namespace std;

struct polje
{
    int x, y; // Koordinate
    int drvo; // Prohodno ili ne
    int s; // Skrivenost (trenutna)
    int p; // preostalo kretanje lika sto je tu krocio
};

struct tragac
{
    int x, y, v; // koordinate i brzina
};

bool operator<(tragac t1, tragac t2)
{
    return t1.v>t2.v;
}

int n, m, k;
const int N=1005;
polje a[N][N];
tragac t[N*N];
const int dx[]={1, 0, -1, 0};
const int dy[]={0, 1, 0, -1};
queue <polje> q;

bool operator<(polje p1, polje p2)
{
    if(p1.s == p2.s) return p1.p>p2.p;
    return p1.s<p2.s;
}

void bfs(int ti) // indeks tragaca
{
    a[t[ti].x][t[ti].y].s=0;
    a[t[ti].x][t[ti].y].p=0;
    q.push(a[t[ti].x][t[ti].y]);
    while(!q.empty())
    {
        int x=q.front().x;
        int y=q.front().y;
        polje tmp;
        tmp.s=q.front().s;
        tmp.p=q.front().p-1;
        if(tmp.p<0)
        {
            tmp.p+=t[ti].v;
            tmp.s++;
        }
        for(int i=0; i<4; i++)
            if(!a[x+dx[i]][y+dy[i]].drvo && tmp<a[x+dx[i]][y+dy[i]])
            {
                a[x+dx[i]][y+dy[i]].p=tmp.p;
                a[x+dx[i]][y+dy[i]].s=tmp.s;
                q.push(a[x+dx[i]][y+dy[i]]);
            }
        q.pop();
    }
}

int main()
{
    scanf("%i %i", &n, &m);
    for(int i=1; i<=n; i++)
        for(int j=1; j<=m; j++)
        {
            char c;
            scanf(" %c", &c);
            a[i][j].drvo=c-'0';
            a[i][j].y=j; //! obrati paznju!!!
            a[i][j].x=i; //! obrati paznju!!!
            if(!a[i][j].drvo) a[i][j].s=5*N*N;
        }
    for(int i=0; i<=n+1; i++)
    {
        a[i][0].drvo=1;
        a[i][m+1].drvo=1;
    }
    for(int j=0; j<=m+1; j++)
    {
        a[0][j].drvo=1;
        a[n+1][j].drvo=1;
    }
    scanf("%i", &k);
    for(int i=0; i<k; i++)
    {
        scanf("%i %i %i", &t[i].x, &t[i].y, &t[i].v);
    }
    sort(t, t+k);
    for(int i=0; i<k; i++)
        bfs(i);
    int max1=0;
    int indexx, indexy;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=m; j++)
            if(a[i][j].s>max1)
            {
                max1=a[i][j].s;
                indexx=i;
                indexy=j;
            }
    printf("%i %i\n", indexx, indexy);
    return 0;
}
/*
5 7
0010000
0100000
0000110
0000000
0000000
2
1 2 3
4 4 1

7 7
0100010
0101010
0101010
0101010
0101010
0101010
0001000
2
1 1 27
4 7 1

10 10
0000000000
0000000000
0000000000
0000000000
0000000000
0000000000
0000000000
0000000000
0000000000
0000000000
5
1 1 2
8 6 3
9 1 1
2 4 5
5 5 20
*/
