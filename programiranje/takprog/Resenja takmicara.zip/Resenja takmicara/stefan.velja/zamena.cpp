#include <iostream>
#include <cstdio>
#include <algorithm>

//Nisam fudbaler, a ni vlasnik splava, al' sam dobar drug Seselj Vojislava

using namespace std;

const int N=100005;
const int D=1000005;

int n, c; // Broj elemenata i duzina a[i]
int a[N], d[D][9], bio[D][9];

void findc()
{
    int tmp=a[0];
    while(tmp>0)
    {
        c++;
        tmp/=10;
    }
}

void solve(int i)
{
    int step=10;
    int tmp[10];
    int max1=-500;
    for(int j=0; j<c; j++)
    {
        tmp[j]=(a[i]-a[i]%step+(10)*(a[i]%(step/10)))/10;
        if(bio[tmp[j]][j]) d[tmp[j]][j]+=abs(bio[tmp[j]][j]-((a[i]%step-a[i]%(step/10))/(step/10)));
        if(d[tmp[j]][j]>max1) max1=d[tmp[j]][j];
        bio[tmp[j]][j]=(a[i]%step-a[i]%(step/10))/(step/10);
        step*=10;
    }
    for(int j=0; j<c; j++)
        d[tmp[j]][j]=max1;
}

int main()
{
    //freopen("in.txt", "r", stdin);
    scanf("%i", &n);
    for(int i=0; i<n; i++)
        scanf("%i", &a[i]);
    findc();
    for(int i=n-1; i>=0; i--)
        solve(i);
    int max1=-5;
    for(int i=0; i<D-5; i++)
        for(int j=0; j<c; j++)
            if(d[i][j]>max1) max1=d[i][j];
    printf("%i\n", max1);
    return 0;
}
/*
6
8823
2145
2185
3385
4145
4445

20
1999999
9999999
1999999
9999999
1999999
9999999
1999999
9999999
1999999
9999999
1999999
9999999
1999999
9999999
1999999
9999999
1999999
9999999
1999999
9999999

*/
