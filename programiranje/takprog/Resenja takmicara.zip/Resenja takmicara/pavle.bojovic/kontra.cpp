#include <stdio.h>
#include <iostream>
#include <algorithm>
using namespace std;

int n, m, a[1001][1001], v;

void ucitaj(int a[][1001], int n)
{
		 static char s[1001];
		 for(int i=0;i<n;i++)
		 {
         scanf("%s",&s);
				 for(int j=0;j<strlen(s);j++)
				 {
				     a[i][j]='0'-s[j];
				     if(a[i][j]==0) a[i][j]=-2;
				 }
		 }
}

void potraga1(int x, int y, int k, int p)
{
		     if(k>0)
				 {
						 if(p<a[x][y] || a[x][y]==-2) a[x][y]=p;
						 if(x+1<n && (p<a[x+1][y] || a[x+1][y]==-2)) potraga1(x+1,y,k-1,p);
		         if(x>0 && (p<a[x-1][y] || a[x-1][y]==-2)) potraga1(x-1,y,k-1,p);
		         if(y+1<m && (p<a[x][y+1] || a[x][y+1]==-2)) potraga1(x,y+1,k-1,p);
		         if(y>0 && (p<a[x][y-1] || a[x][y-1]==-2)) potraga1(x,y-1,k-1,p);
		     }
		     else potraga1(x,y,v,p+1);
}

int main()
{
		static int k, x, y, max=0, mx, my;
		scanf("%d %d",&n,&m);
		ucitaj(a,n);
		scanf("%d",&k);
		for(int i=0;i<k;i++)
  	{
   	    scanf("%d %d %d",&x,&y,&v);
	 			a[x-1][y-1]=0;
   			potraga1(x-1,y-1,v+1,1);
		}

		for(int i=0;i<n;i++)
				for(int j=0;j<m;j++)
						if(a[i][j]>=max)
						{
								max=a[i][j];
								mx=i+1;
								my=j+1;
						}
		printf("%d %d",mx,my);
		for(;;);
}
