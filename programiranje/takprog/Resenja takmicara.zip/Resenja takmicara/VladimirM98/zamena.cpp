#include <bits/stdc++.h>
using namespace std;
const int MAXN=100010;
map<int,vector<int> > idx;
map<int, bool> poj;
int a[MAXN];
int n,len,best;
vector<int> adj[MAXN];
vector<int> weg[MAXN];
int step10[10];
int dp[MAXN];
/*
Ideja je da od broja a do broja b napravim edge ukoliko broj a moze da se izmeni, po uslovima, u broj b, i weight tog edge-a ce biti broj bodova koji se  koristi za tu izmenu.
To bi potencijalno bilo n^2, ali iz broja duzine l cifara moze da se dodje samo u 9*l brojeva, pa je Emax=9*maxlen*n, sto bi trebalo da prodje za vreme
JEL MOZE DA SE ISKLJUCI OVO SRANJE STO ZUJI????
*/
void prepare()//Works perfectly
{
    step10[0]=1;
    for(int i=1;i<=9;i++) step10[i]=10*step10[i-1];
}
void read()//Works perfectly
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++) {scanf("%d",&a[i]);idx[a[i]].push_back(i);poj[a[i]]=true;}
    int tmp=a[1];
    while(tmp)
    {
        tmp/=10;
        len++;
    }
}
void addEdge(int i,int j,int w)//Works perfectly
{
    //Dodajem obrnut edge, tj u j dodajem sve one koji ulaze u j da bi mi bilo lakse da posle dpujem
    //printf("%d %d %d\n",a[i],a[j],w);
    //adj[i].push_back(j);
    adj[j].push_back(i);
    //weg[i].push_back(w);
    weg[j].push_back(w);
}
int findNext(int i,int number)//Ima da radi perfectly hahahh
{
    //U idx[number] se sigurno ne pojavljuje i, dakle isti kurac mi je da li je upper ili lower bound
    //Jer je idiotski dodavati edge od x do x, samo bi ga gurnuo napred pa to nikako ne moze biti optimalan potez
    //Ako je ret idx[number].size onda su svi takvi brojevi iza njega pa takav ne postoji
    int ret=lower_bound(idx[number].begin(),idx[number].end(),i)-idx[number].begin();
    if(ret==idx[number].size()) return -1;
    else return idx[number][ret];
}
void makeGraph()//Works
{
    for(int i=1;i<=n;i++)
    {
        for(int cif=1;cif<=len;cif++)
        {
            int cur=(a[i]/step10[cif-1])%10;
            //Enumeratujem cifru koja ce da ide na cif mesto
            for(int put=0;put<=9;put++)
            {
                if(put==cur) continue;
                int newNumber=a[i]+(put-cur)*step10[cif-1];
                int wcur=abs(put-cur);
                int findd=findNext(i,newNumber);
                if(findd!=-1) addEdge(i,findd,wcur);//Svi putevi idu u -1 not going to happen
            }
        }
    }
}
int len0()
{
    int ans=0;
    for(int i=2;i<=n;i++) ans+=abs(a[i]-a[i-1]);
    printf("%d\n",ans);
    exit(0);
}
int longestPath()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<adj[i].size();j++)
        {
            int prev=adj[i][j];
            dp[i]=max(dp[i],dp[prev]+weg[i][j]);
        }
    }
    int ans=0;
    for(int i=1;i<=n;i++) ans=max(ans,dp[i]);
    return ans;
}
int main()
{
    prepare();
    read();
    if(len<2) len0();
    makeGraph();
    printf("%d\n",longestPath());
    return 0;
}
