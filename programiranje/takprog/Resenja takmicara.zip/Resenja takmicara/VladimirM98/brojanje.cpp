#include <bits/stdc++.h>
#define mid (left+right)/2
using namespace std;
typedef long long ll;
const int INF=2000000000;
const int MAXN=1000010;
int a[MAXN];
int RMQ[4*MAXN];
map<int,ll> sol;
int n;
set<int> exists;
map<int,vector<int> >idx;
const long long MOD=1000000007ll;
//Na kraju sam stavio ovaj brut fors za malo n(40 poena valjda), ako mi se sjebe neki +-1 ko na okruznom da ne padne sve
/*
O(Nlog^2N), dodje mu negde oko 4*10^8 za dve sekunde, valjda ce da radi
Imam RMaxQ, ove dve funkcije mi traze prvi levi i prvi desni veci od trazenog u nizu
Onda imam tipa levi isti isti isti veci
I sa tim skrljam u koliko je "isti" maksimum, kao svi minus oni gde nije maksimum
Kad sam kucao firsttry mi je radio i testirao sam na nekim malim, nema feedback jbg, valjda ce da prodje
Nlog^N priblizno 4*1e8, za 2s bi trebalo ~8e8, jes' da imam konstantu ali ima da prodje!!!

*/
void InitTree(int idx,int left,int right)
{
    if(left==right) {RMQ[idx]=a[left];return;}
    InitTree(2*idx,left,mid);
    InitTree(2*idx+1,mid+1,right);
    RMQ[idx]=max(RMQ[2*idx],RMQ[2*idx+1]);
}
int Query(int idx,int left,int right,int l,int r)
{
    if(r<left||l>right) return -INF;
    if(l<=left&&right<=r) return RMQ[idx];
    int ret=-INF;
    ret=max(ret,Query(2*idx,left,mid,l,r));
    ret=max(ret,Query(2*idx+1,mid+1,right,l,r));
    return ret;
}
int firstLeft(int i)
{
    int srch=a[i];
    int lo=1;
    int hi=i-1;
    if(Query(1,1,n,1,i-1)<=srch) return 0;
    while(lo<hi)
    {
        int midd=(lo+hi)/2;
        if(Query(1,1,n,midd+1,i-1)<=srch) hi=midd;
        else lo=midd+1;
    }
    return lo;
}
int firstRight(int i)
{
    int srch=a[i];
    int lo=i+1;
    int hi=n;
    if(Query(1,1,n,i+1,n)<=srch) return n+1;
    while(lo<hi)
    {
        int midd=(lo+hi)/2;
        if(Query(1,1,n,i+1,midd)<=srch) lo=midd+1;
        else hi=midd;
    }
    return lo;
}
ll c2(int x)
{
    return 1ll*x*(x+1)/2;
}
void work(int x,vector<int> adj)
{
    ll ans=0;
    for(int i=0;i<adj.size();)
    {
        int proc=adj[i];
        int leva=firstLeft(proc);
        int desna=firstRight(proc);
        ans+=c2(desna-leva-1);
        ans-=c2(proc-leva-1);
        int j=i+1;
        while(j<adj.size()&&adj[j]<desna)
        {
            ans-=c2(adj[j]-adj[j-1]-1);
            j++;
        }
        ans-=c2(desna-adj[j-1]-1);
        i=j;
    }
    sol[x]=ans;
}
void process()
{
    for(int i=1;i<=n;i++) {idx[a[i]].push_back(i);exists.insert(a[i]);}
    set<int>::iterator it;
    for(it=exists.begin();it!=exists.end();it++)
    {
        work(*it,idx[*it]);
    }
}
int main()
{
    //freopen("in.txt","r",stdin);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&a[i]);
    }
    InitTree(1,1,n);
    if(n<=100)
    {
        for(int i=1;i<=n;i++) for(int j=i;j<=n;j++) sol[Query(1,1,n,i,j)]++;
        int k;
        scanf("%d",&k);
        while(k--)
        {
            int jbgsamo50;
            scanf("%d",&jbgsamo50);
            printf("%lld\n",sol[jbgsamo50]%MOD);
        }
        return 0;
    }
    process();
    int k;
    scanf("%d",&k);
    while(k--)
    {
        int willbe100;
        scanf("%d",&willbe100);
        printf("%lld\n",sol[willbe100]%MOD);
    }
    return 0;
}
