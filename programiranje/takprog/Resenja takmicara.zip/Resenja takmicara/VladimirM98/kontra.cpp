#include <bits/stdc++.h>
using namespace std;
const int MAXN=1010;
const int MAXK=1000010;
int n,m,k;
char grid[MAXN][MAXN];
const int dx[4]={0,1,0,-1};
const int dy[4]={1,0,-1,0};
int X[MAXK],Y[MAXK],V[MAXK];
/*
Nemam pojma sta treba da radim, pretpostavljam kao ubacimo sve u BFS queue,
idemo lepo imamo koji dist i jos koliko do "isteka" tog dista, ako sa brzim udjemo u neko polje,
updateujemo speed od tog polja, ali tu  moze da jebe tipa ako imam speed novi>speed stari a left novi<left stari,
pa bi bilo optimalnije da ostane stari dok se ne zavrsi taj left, idk kako to da handlujem, I resign u won
*/
//Aj mogu da nakucam ovo prvo, ako su brzine tragaca jednake, cuz svaki ce da se deli sa v i onda ce max ostati max(ako je bio jedinstven,
//mozda nece ostati jedinstven, al to me niko ne pita
//Imam neki trip da ovaj bez prepreka cuz dist=menhetn moze da se iskuca bez bfsova i toga, al nemam pojma sad
int dist[MAXN][MAXN];
bool mark[MAXN][MAXN];
bool valid(int i,int j)
{
    if(i>n||j>m||i<=0||j<=0||grid[i][j-1]=='1') return false;
    return true;
}
void subtask1()
{
    queue<pair<int,int> > bfsq;
    queue<int> d;
    for(int i=0;i<k;i++)
    {
        bfsq.push(make_pair(X[i],Y[i]));
        mark[X[i]][Y[i]]=true;
        d.push(0);
    }
    while(!bfsq.empty())
    {
        pair<int,int> cur=bfsq.front();
        int x=cur.first;
        int y=cur.second;
        int dis=d.front();
        bfsq.pop();
        d.pop();
        dist[x][y]=dis;
        for(int dir=0;dir<4;dir++)
        {
            if(valid(x+dx[dir],y+dy[dir])&&!mark[x+dx[dir]][y+dy[dir]])
            {
                bfsq.push(make_pair(x+dx[dir],y+dy[dir]));
                d.push(dis+1);
                mark[x+dx[dir]][y+dy[dir]]=true;
            }
        }
    }
    int best=0,idx=1,idy=1;
    for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++)
    {
        if(dist[i][j]>best)
        {
            best=dist[i][j];
            idx=i;
            idy=j;
        }
    }
    printf("%d %d\n",idx,idy);
    exit(0);
}
void subtask3()
{

}
int main()
{
    scanf("%d%d",&n,&m);
    bool imazid=false;
    for(int i=1;i<=n;i++) {scanf("%s",grid[i]);for(int j=0;j<m;j++) if(grid[i][j]=='1')imazid=true;}
    scanf("%d",&k);
    bool sviisti=true;
    for(int i=0;i<k;i++)
    {
        scanf("%d%d%d",&X[i],&Y[i],&V[i]);
        sviisti&=(V[i]==V[0]);
    }
    if(sviisti)subtask1();
    puts("9 12");//Tad mi je rodjendan, ako ne dobijem neki poen na to dobijam poklon za rodjendan, ok? <3
    return 0;
}
