#include <iostream>
using namespace std;
int a[10000],b=3,i,n,m;

int slican(int p, int q);
void komb(int i, int br);
int abs(int p);

void komb(int t,int br)
{
    for (int j=t+1;j<=n;j++)
        if (slican(a[t],a[j])!=-1)
        {
            komb(j,br+m);
        }
    if (br>b) b=br;
    return;
}
int slican(int p,int q)
{
    for (int i=10;i<=10000000;i*=10)
    {
        if ((p/i==q/i) && (p%(i/10)==q%(i/10)))
        {
            m=abs(((p%i)/(i/10))-((q%i)/(i/10)));
            return m;
        }
    }
    return -1;
}

int abs(int p)
{
    if (p<0) p*=-1;
    return p;
}

int main()
{
    cin >>n;
    for (i=1;i<=n;i++) cin >>a[i];
    for (i=1;i<n;i++) komb(i,0);
    cout <<b;
    return 0;
}
