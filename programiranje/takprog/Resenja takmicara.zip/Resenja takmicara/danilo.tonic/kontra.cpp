#include <iostream>
#include <queue>
using namespace std;

int v[1000],x[1000],y[1000],a[1000][1000],b[1000][1000];
char unos[1000];
queue<int> red,kolona;



int main()
{
    int i,j,m,n,k,p,q,mx=0,c,d;
    cin >>n>>m;
    for (i=1;i<=n;i++)
       {
           cin >>unos;
            for (j=0;j<m;j++)
            {
                if (unos[j]-'0'==1) a[i][j+1]=-1;
                else if (unos[j]-'0'==0) a[i][j+1]=-2;
            }
       }

    cin >>k;
    for (i=1;i<=k;i++) cin >>x[i]>>y[i]>>v[i];
    for (i=1;i<=k;i++)
    {

        b[x[i]][y[i]]=v[i];
        red.push(x[i]);
        kolona.push(y[i]);
        a[x[i]][y[i]]=1;
        while (!red.empty()&&!kolona.empty())
        {

                p=red.front();
                q=kolona.front();

                red.pop();
                kolona.pop();
                if (p>1) if (((b[p][q]>0 && (a[p-1][q]>=a[p][q] || a[p-1][q]==-2)) || (b[p][q]==0 && (a[p-1][q]>=a[p][q]+1 || a[p-1][q]==-2))) && a[p-1][q]!=-1)
                    {
                        red.push(p-1);
                        kolona.push(q);
                        if (b[p][q]>0) {b[p-1][q]=b[p][q]-1; a[p-1][q]=a[p][q];}
                        else {b[p-1][q]=v[i]-1; a[p-1][q]=a[p][q]+1;}

                    }
                if (q>1) if (((b[p][q]>0 && (a[p][q-1]>=a[p][q] || a[p][q-1]==-2)) || (b[p][q]==0 && (a[p][q-1]>=a[p][q]+1 || a[p][q-1]==-2))) && a[p][q-1]!=-1)
                    {
                        red.push(p);
                        kolona.push(q-1);
                        if (b[p][q]>0) {b[p][q-1]=b[p][q]-1; a[p][q-1]=a[p][q];}
                        else {b[p][q-1]=v[i]-1; a[p][q-1]=a[p][q]+1;}

                    }
                if (p<n) if (((b[p][q]>0 && (a[p+1][q]>=a[p][q] || a[p+1][q]==-2)) || (b[p][q]==0 && (a[p+1][q]>=a[p][q]+1|| a[p+1][q]==-2))) && a[p+1][q]!=-1)
                    {
                        red.push(p+1);
                        kolona.push(q);
                        if (b[p][q]>0) {b[p+1][q]=b[p][q]-1; a[p+1][q]=a[p][q];}
                        else {b[p+1][q]=v[i]-1; a[p+1][q]=a[p][q]+1;}

                    }
                if (q<m) if (((b[p][q]>0 && (a[p][q+1]>=a[p][q] || a[p][q+1]==-2)) || (b[p][q]==0 && (a[p][q+1]>=a[p][q]+1 || a[p][q+1]==-2))) && a[p][q+1]!=-1)
                    {
                        red.push(p);
                        kolona.push(q+1);
                        if (b[p][q]>0) {b[p][q+1]=b[p][q]-1; a[p][q+1]=a[p][q];}
                        else {b[p][q+1]=v[i]-1; a[p][q+1]=a[p][q]+1;}

                    }

        }
        a[x[i]][y[i]]=0;
    }
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=m;j++)
        {
            if (a[i][j]>mx) {mx=a[i][j];c=i;d=j;}
        }
    }

    cout <<c <<" " <<d;

    return 0;
}
