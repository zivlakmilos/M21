#include <iostream>
using namespace std;

int a[1000000],b[1000000],srt[1000000],index[1000000],n,k,b1=0,b2=0,c=0,d,z;
void quick(int t1,int t2);
void binarna(int m,int indx1,int indx2);

void quick(int t1,int t2)
{
    int pivot;
    pivot=srt[t2];
    int i,j;
    i=t1;
    j=t2-1;
    while (true)
    {
        while (srt[i]<=pivot) i++;
        while (srt[j]>=pivot) j--;

        if (j-i==-1)
        {
            for(z=t2;z>j+1;z--) {swap(srt[z],srt[z-1]); swap(index[z],index[z-1]);}
            goto a;
        }
        else {swap(srt[i],srt[j]); swap(index[i],index[j]);}
    }
    a:
    if (j-t1>1) quick(t1,j);
    else if (j-t1==1) if (srt[j]<srt[t1]) swap(srt[j],srt[t1]);
    if (t2-j-2>1) quick(j+2,t2);
    else if (t2-j-2==1) if (srt[t2]<srt[j+2]) swap(srt[j],srt[t1]);
    return;
}

void binarna(int m,int indx1,int indx2)
{
    if (m<srt[(indx1+indx2)/2]) binarna(m,indx1,(indx1+indx2)/2);
    else if (m>srt[(indx1+indx2)/2]) binarna(m,(indx1+indx2)/2,indx2);
    else
    {
        d=(indx1+indx2)/2;
        while (m==srt[d])
        {
            if (m==srt[d-1]) d--;
        }

        return;
    }
}



int main()
{
    int i,j,t;
    cin >>n;
    for (i=1;i<=n;i++) {cin >>a[i]; srt[i]=a[i]; index[i]=i;}
    cin >>k;
    for (i=1;i<=k;i++) cin >>b[i];
    quick(1,n);
    for (int i=1;i<=k;i++)
    {
        c=0;

        binarna(b[i],1,n);
        cout <<endl <<d;
        t=d;
        while (srt[t]==srt[d]){
        j=index[d];
        while (a[index[d]]>a[j])
        {
            b1++;
            j--;
        }
        j=index[d]+1;
        while (a[index[d]]>a[j])
        {
            b2++;
            j++;
        }
        c+=(b2+1)*(b1+1);
        b2=0;b1=0;
        d++;
        }
        cout <<c%(1000000000+7) <<endl;

    }
    return 0;
}
