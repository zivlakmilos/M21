#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <queue>
#include <vector>
#include <algorithm>

using namespace std;

int n;
int bc;
int res[100005];
int org[100005];
int maxx;

struct sss1
{
    int a;
    int p;
    int cif;
};

sss1 b[8][100005];
sss1 tr,pombin,tren;

int gc(int x)
{
    int pom=x;
    while(pom>0)
    {
        pom/=10;
        bc++;
    }
}

int namcif()
{
    int pom=1,pom1=0;
    for(int i=0;i<bc;i++)
    {
        for(int j=0;j<n;j++)
        {
            pom1=b[i][j].a%pom;
            b[i][j].a/=pom;
            b[i][j].cif=b[i][j].a%10;
            b[i][j].a/=10;
            b[i][j].a=b[i][j].a*pom+pom1;
        }

        pom*=10;
    }

    return 0;
}

sss1 morf1(int x,int red,int poz)
{
    int pom1=0,pom2=1;

    sss1 rr;
    rr.a=x;
    rr.p=poz;

    for(int i=0;i<red;i++)
    {
        pom2*=10;
    }

    pom1=rr.a%pom2;
    rr.a/=pom2;
    rr.cif=rr.a%10;
    rr.a/=10;
    rr.a*=pom2;
    rr.a+=pom1;

    return rr;
}

int ispisi()
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<bc;j++)
        {
            printf("%d %d %d ",b[j][i].a,b[j][i].cif,b[j][i].p);
        }
        printf("\n");
    }

    return 0;

}

bool cmp(sss1 x,sss1 y)
{
    if(x.a==y.a)
    {
        if(x.cif==y.cif)
        {
            return x.p<y.p;
        }
        else
        {
            return x.cif<y.cif;
        }
    }
    else
    {
        return x.a<y.a;
    }
}

sss1 bin(int red,sss1 tr)
{
    int l=0,d=n-1;
    sss1 lb,db,sr;

        lb=b[red][l];
        db=b[red][d];

    while(l!=d&&l!=d-1)
    {
        sr=b[red][(l+d)/2];
        if(sr.a==tr.a)
        {
            if(sr.cif==tr.cif)
            {
                if(sr.p>tr.p)
                {
                    d=(l+d)/2;
                }
                else
                {
                    l=(l+d)/2;
                }
            }
            else if(sr.cif>tr.cif)
            {
                d=(l+d)/2;
            }
            else
            {
                l=(l+d)/2;
            }
        }
        else if(sr.a>tr.a)
        {
            d=(l+d)/2;
        }
        else
        {
            l=(l+d)/2;
        }
    }

    //printf("%d %d %d %d %d %d\n\n",b[red][l].a,b[red][l].cif,b[red][d].a,b[red][d].cif,tr.a,tr.cif);

    if(tr.cif==b[red][d].cif&&tr.p>b[red][d].p&&tr.a==b[red][d].a)
    {
        return b[red][d];
    }
    else if(tr.cif==b[red][l].cif&&tr.p>b[red][l].p&&tr.a==b[red][l].a)
    {
        return b[red][l];
    }
    return tren;
}

int main()
{
    scanf("%d",&n);

    for(int i=0;i<n;i++)
    {
        scanf("%d",&b[0][i].a);
        b[0][i].p=i;
        org[i]=b[0][i].a;
    }

    gc(b[0][0].a);

    for(int i=0;i<bc;i++)
    {
        for(int j=0;j<n;j++)
        {
            b[i][j].a=b[0][j].a;
            b[i][j].p=b[0][j].p;
        }
    }

    for(int i=0;i<bc;i++)
    {
        for(int j=0;j<n;j++)
        {
            b[i][j].a=b[0][j].a;
            b[i][j].p=b[0][j].p;
        }
    }

    namcif();

    for(int i=0;i<bc;i++)
    {
        sort(b[i],b[i]+n,cmp);
    }

    for(int i=1;i<n;i++)
    {
        for(int j=0;j<bc;j++)
        {

            tr=morf1(org[i],j,i);
            tren=morf1(org[i],j,i);


            for(int k=0;k<10;k++)
            {
                tr.cif=k;
                pombin=bin(j,tr);

                //printf("%d %d %d %d %d %d %d\n\n",i,j,org[i],tr.a,tr.cif,pombin.a,pombin.cif);


                if(res[pombin.p]+abs(pombin.cif-tren.cif)>res[i])
                {
                    res[i]=res[pombin.p]+abs(pombin.cif-tren.cif);
                }
            }
        }

        if(maxx<res[i])
        {
            maxx=res[i];
        }
    }

    //ispisi();

    printf("%d",maxx);

    return 0;
}
