#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <queue>
#include <vector>
#include <algorithm>

using namespace std;

int n,m,k;
int a[1005][1005];
bool vis[1005][1005];
char c[1005];

int pbr;
int brzt;
int dis[1000005];
int xp,yp;
int mpom;
int brprolaza;

struct zaque
{
    int x;
    int y;
    int brzt;
};

zaque pzq;

struct kurac
{
    int brz;
    zaque zq;
    queue <zaque> que;
};

queue <int> uni;

kurac g[1000005];

bool cmp(kurac a, kurac b)
{
    return a.brz>b.brz;
}

int ispisi()
{
    for(int i=1;i<n+1;i++)
    {
        for(int j=1;j<m+1;j++)
        {
            printf("%d  ",a[i][j]);
        }
        printf("\n");
    }
}

int main()
{
    scanf("%d %d",&n,&m);

    for(int i=1;i<n+1;i++)
    {
        scanf("%s",c);
//printf("%s",c);
        for(int j=1;j<m+1;j++)
        {

            if(c[j-1]=='1')
            {
                a[i][j]=-1;

            }

            a[0][j]=-1;
            a[n+1][j]=-1;

        }
         a[i][0]=-1;
            a[i][m+1]=-1;
    }
//ispisi();
    scanf("%d",&k);

    for(int i=0;i<k;i++)
    {
        scanf("%d %d %d",&g[i].zq.x,&g[i].zq.y,&g[i].brz);
        a[g[i].zq.x][g[i].zq.y]=0;
        vis[g[i].zq.x][g[i].zq.y]=true;
        g[i].zq.brzt=1;
        g[i].que.push(g[i].zq);
        //printf("  %d  ",que[i].empty());
    }

    sort(g,g+k,cmp);
    //printf(" a ");

    brprolaza=1;

    uni.push(0);
    for(int i=1;i<k+1;i++)
    {
        if(g[i].brz==g[i-1].brz)
        {
            uni.push(i);
        }
        else
        {

        brprolaza=1;

        while(!uni.empty())
        {

        if(uni.front()<pbr)
        {
            brprolaza++;
        }

        pbr=uni.front();
printf(" a ");
        //printf("%d %d %d\n\n",i,pbr,que[pbr].empty());

        dis[pbr]++;

        //pintf("%d %d %d %d\n\n",i,brz)

        while(!g[pbr].que.empty()&&g[pbr].brz*brprolaza>=g[pbr].que.front().brzt)
        {
            xp=g[pbr].que.front().x;
            yp=g[pbr].que.front().y;
            brzt=g[pbr].que.front().brzt;

            printf("A %d %d %d %d %d %d\n\n",i,pbr,xp,yp,brzt,brprolaza);

            if(a[xp+1][yp]!=-1&&(vis[xp+1][yp]==false||a[xp+1][yp]>dis[pbr]))
            {
                pzq.x=xp+1;
                pzq.y=yp;
                pzq.brzt=brzt+1;
                g[pbr].que.push(pzq);
                vis[xp+1][yp]=true;
                a[xp+1][yp]=dis[pbr];
            }

            if(a[xp-1][yp]!=-1&&(vis[xp-1][yp]==false||a[xp-1][yp]>dis[pbr]))
            {
                pzq.x=xp-1;
                pzq.y=yp;
                pzq.brzt=brzt+1;
                g[pbr].que.push(pzq);
                vis[xp-1][yp]=true;
                a[xp-1][yp]=dis[pbr];
            }

            if(a[xp][yp+1]!=-1&&(vis[xp][yp+1]==false||a[xp][yp+1]>dis[pbr]))
            {
                pzq.x=xp;
                pzq.y=yp+1;
                pzq.brzt=brzt+1;
                g[pbr].que.push(pzq);
                vis[xp][yp+1]=true;
                a[xp][yp+1]=dis[pbr];
            }

            if(a[xp][yp-1]!=-1&&(vis[xp][yp-1]==false||a[xp][yp-1]>dis[pbr]))
            {
                pzq.x=xp;
                pzq.y=yp-1;
                pzq.brzt=brzt+1;
                g[pbr].que.push(pzq);
                vis[xp][yp-1]=true;
                a[xp][yp-1]=dis[pbr];
            }

            g[pbr].que.pop();
        }
        uni.pop();


        if(!g[pbr].que.empty())
        {
            uni.push(pbr);
        }

        }
        uni.push(i);
        }
    }

    //ispisi();

    int max1=0,maxi=0,maxj=0;

    for(int i=1;i<=n;i++)
    {

    for(int j=1;j<=m;j++)
    {
        if(a[i][j]>max1)
        {
            max1=a[i][j];
            maxi=i;
            maxj=j;
        }
    }
    }
printf("%d %d",maxi,maxj);
    return 0;
}
