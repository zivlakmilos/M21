#include <stdio.h>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

int n,k = 0,maks = 0;
queue <int> q;

struct str1
{
    int d,in;
}niz[100000];

struct str2
{
    int d,mark,sc;
    vector <int> pok;
}org[100000];

int cmp(str1 a,str1 b)
{
    if(a.d < b.d) return 1;
    else if( a.d == b.d && a.in < b.in) return 1;
    return 0;
}

int raz(int a,int b)
{
    int p = a-b;
    if(p < 0) p = -p;
    while(p > 9) p /= 10;
    return p;
}

int main()
{
    scanf("%d",&n);
    for(int i = 0;i<n;i++)
    {
        scanf("%d",&org[i].d);
        org[i].mark = 0;
        org[i].sc = 0;
    }
    int p1 = 10,p2 = 1;
    while(k == 0)
    {
        if(org[0].d < p1) k = p2;
        else
        {
            p1 *= 10;
            p2 += 1;
        }
    }
    p1 = 1,p2 = 1;
    for(int i = 0;i<k;i++)
    {
        if(i == 1)
        {
            p1 = 10;
            p2 = 100;
        }
        else
        {
            p1*=10;
            p2*=10;
        }
        for(int j = 0;j<n;j++)
        {
            niz[j].in = j;
            niz[j].d = 0;
            if(i == 0)
            {
                niz[j].d = org[j].d / 10;
            }
            else
            {
                niz[j].d += org[j].d % p1;
                niz[j].d += (org[j].d / p2)*p1;
            }
        }
        sort(niz,niz+n,cmp);
        for(int j = 0;j<n-1;j++)
        {
            if(niz[j].d == niz[j+1].d)
            {
                int p3 = 0;
                for(int y = 0;y < org[niz[j].in].pok.size();y++)
                {
                    if(org[niz[j].in].pok[y] == niz[j+1].in)
                    {
                        p3 = 1;
                        break;
                    }
                }
                if(!p3)
                {
                    org[niz[j].in].pok.push_back(niz[j+1].in);
                    org[niz[j+1].in].mark = 1;
                }
            }
        }
    }
    for(int i = 0;i<n;i++)
    {
        if(org[i].mark == 0)
        {
            q.push(i);
        }
    }
    while(!q.empty())
    {
        int p4 = q.front();
        q.pop();
        for(int j = 0;j<org[p4].pok.size();j++)
            {
                int p5 = org[p4].pok[j];
                if(org[p5].sc < org[p4].sc + raz(org[p4].d,org[p5].d))
                {
                    org[p5].sc = org[p4].sc + raz(org[p4].d,org[p5].d);
                }
                q.push(p5);
            }
        if(maks < org[p4].sc) maks = org[p4].sc;
    }
    printf("%d",maks);
    return 0;
}
