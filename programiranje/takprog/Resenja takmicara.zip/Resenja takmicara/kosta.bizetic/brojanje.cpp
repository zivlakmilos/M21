#include <stdio.h>
#include <stack>
#include <algorithm>
using namespace std;

int n,q;
stack <int> b,c;

struct str
{
    int d,pd,pl,in;
}a[1000000],upit[1000000];

int cmp1(str a,str b)
{
    if(a.d < b.d) return 1;
    else if(a.d == b.d && a.in < b.in) return 1;
    return 0;
}

int cmp2(str a,str b)
{
    if(a.in < b.in) return 1;
    return 0;
}

long long mod(long long a)
{
    while(a >= 1000000007) a -= 1000000007;
    return a;
}

int b_search(str niz[],int l,int d,int k)
{
    int p = (l + d + 1)/2;
    if(l>d) return -1;
    if(k > niz[p].d) return b_search(niz,p+1,d,k);
    else if(k < niz[p].d) return b_search(niz,l,p-1,k);
    else if (k == niz[p].d)
    {
        while(p >= 0 && niz[p].d == k) p--;
        return p + 1;
    }
    else if(l >= d) return -1;
}

int main()
{
    scanf("%d",&n);
    for(int i = 0;i<n;i++)
    {
        scanf("%d",&a[i].d);
        a[i].in = i;
        a[i].pd = n;
        while(!b.empty() && a[b.top()].d < a[i].d)
        {
            a[b.top()].pd = i;
            b.pop();
        }
        b.push(i);
    }
    for(int i = 0;i<n;i++)
    {
        a[n-1-i].pl = -1;
        while(!c.empty() && a[c.top()].d < a[n-1-i].d)
        {
            a[c.top()].pl = n-1-i;
            c.pop();
        }
        c.push(n-1-i);
    }
    sort(a,a+n,cmp1);
    scanf("%d",&q);
    for(int i = 0;i<q;i++)
    {
        scanf("%d",&upit[i].d);
        upit[i].in = i;
    }
    sort(upit,upit + q,cmp1);
    for(int i = 0;i<q;i++)
    {
        int j = b_search(a,0,n-1,upit[i].d);
        if(i>0 && upit[i].d == upit[i-1].d)
        {
            upit[i].pd = upit[i-1].pd;
        }
        else if(j != -1)
        {
            long long u = 0;
            while(a[j].d == upit[i].d)
            {
                long long p1 = a[j].in - a[j].pl;
                if(j+1 < n && a[j+1].d == a[j].d)
                {
                    if(a[j+1].in < a[j].pd)
                    {
                        u += (long long) p1*(a[j+1].in - a[j].in);
                        u = mod(u);
                        p1 = a[j+1].in - a[j+1].pl;
                    }
                    else
                    {
                        u += (long long) p1*(a[j].pd - a[j].in);
                        u = mod(u);
                        p1 = a[j+1].in - a[j+1].pl;
                    }
                }
                else
                {
                    u += (long long) p1*(a[j].pd - a[j].in);
                    u = mod(u);
                }
                j++;
            }
            upit[i].pd = u;
        }
        else
        {
            upit[i].pd = 0;
        }
    }
    sort(upit,upit+q,cmp2);
    for(int i = 0;i<q;i++)
        {
            printf("%d\n",upit[i].pd);
        }
    return 0;
}
