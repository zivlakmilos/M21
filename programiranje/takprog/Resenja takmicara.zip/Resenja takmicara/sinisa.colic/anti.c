#include <stdio.h>
#include <stdlib.h>
struct tragac{
    int x;
    int y;
    long v;
};
struct tragac tragaci[1000];
int n,m,k;
int vece = 0;
long i,j,l;
long distanca;
long vr = 0;
int park[1000][1000];
void krug(int x, int y, int r, int vrednost){
    int x1,y1;
    r++;
    //prvi kvadrant
    x1 = x+r;
    y1 = y;
    while(x1>=x){
        if(park[x1][y1]>vrednost||park[x1][y1]==0||x1>=0||y1>=0||x1<=m||y1<=n){
            park[x1][y1]=vrednost;
        }
        x1--;
        y1++;
    }
    //drugi kvadrant
    x1 = x;
    y1 = y+r;
    while(y1>=y){
        if(park[x1][y1]>vrednost||park[x1][y1]==0||x1>=0||y1>=0||x1<=m||y1<=n){
            park[x1][y1]=vrednost;
        }
        y1--;;
        x1--;
    }
    //treci
    x1 = x-r;
    y1 = y;
    while(x1<=x){
        if(park[x1][y1]>vrednost||park[x1][y1]==0||x1>=0||y1>=0||x1<=m||y1<=n){
            park[x1][y1]=vrednost;
        }
        x1++;
        y1--;
    }
    //cetvrti kvadrant
    x1 = x;
    y1 = y-r;
    while(y1<=y){
        if(park[x1][y1]>vrednost||park[x1][y1]==0||x1>=0||y1>=0||x1<=m||y1<=n){
            park[x1][y1]=vrednost;
        }
        x1++;
        y1++;;
    }
}
int main()
{
    scanf("%d %d %d",&n,&m,&k);
    for(i=0;i<k;i++){
        scanf("%d %d %ld",&tragaci[i].x,&tragaci[i].y,&tragaci[i].v);
    }
    for(i=1;i<=n;i++){
        for(j=1;j<=m;j++){
            /*for(l=0;l<k;l++){
                distanca = (i-tragaci[l].x)*(i-tragaci[l].x)+(j-tragaci[l].y)*(j-tragaci[l].y);
            }*/
            park[i][j] = 0;
        }
    }
    /*for(i=0;i<k;i++){
        vece = 2;
        for(j=0;j<=vece;j++){
            for(l=0;l<tragaci[i].v;l++){
                krug(tragaci[i].x,tragaci[i].y,(j-1)*tragaci[i].v+l,j);
            }
        }
    }*/

    for(i=0;(m>n)?i<m:i<n;i++){
        for(i=i;i<i+tragaci[0].v;i++){
            krug(tragaci[0].x,tragaci[0].y,i,vr);
        }
        vr++;
    }
    for(i=1;i<=n;i++){
        for(j=1;j<=m;j++){
            /*for(l=0;l<k;l++){
                distanca = (i-tragaci[l].x)*(i-tragaci[l].x)+(j-tragaci[l].y)*(j-tragaci[l].y);
            }*/
            printf("%d",park[i][j]);
        }
        printf("\n");
    }
    return 0;
}
