#include <stdio.h>
#include <stdlib.h>
long N,r,s;
char Q[500000];
long Ls = 0;
long Rs = 0;
long Ds = 0;
long Us = 0;
long posx = 0;
long posy = 0;
unsigned long najblizi = ~0;
long najblizix = 0;
long najbliziy = 0;
long najblizin = 0;
char c;
long x,y;
long broj=0; //broj polja od najblizeg do rs
void oduzmi(){
    if(Ls>0){
        Ls--;
    }else if(Rs>0){
        Rs--;
    }else if(Us>0){
        Us--;
    }else if(Ds>0){
        Ds--;
    }
}
int main()
{
    scanf("%ld %ld %ld",&N,&r,&s);
    long i = 0;
    long distanca = 0;//kvadrat
    distanca = (posx-r)*(posx-r)+(posy-s)*(posy-s);
    if(distanca<najblizi){
        najblizin = i;
        najblizix = posx;
        najbliziy = posy;
        najblizi = distanca;
    }
    while((c = getchar())){
        if(i>=N)break;
        if(c=='\n'||c=='\r'){

        }else{
            Q[i] = c;
            switch(c){
                case 'L':
                    Ls++;
                    posx--;
                    break;
                case 'R':
                    Rs++;
                    posx++;
                    break;
                case 'D':
                    Ds++;
                    posy--;
                    break;
                case 'U':
                    Us++;
                    posy++;;
                    break;
            }
            distanca = (posx-r)*(posx-r)+(posy-s)*(posy-s);
            if(distanca<najblizi){
                najblizin = i;
                najblizix = posx;
                najbliziy = posy;
                najblizi = distanca;
            }
            printf("%ld",distanca);
            //printf("%d %d",posx,posy);


            i++;
        }
    }
    //najkrace rastojanje izmedju (najblizix,najbliziy) i (r,s)
    x = najblizix;
    y = najbliziy;
    while(x!=r&&y!=s){
        //ako je gore
        if(y<r){
            //ako je levo
            while(r-y>=2 && Ds>0){
                y=y-2;
                Ds--;
                broj++;
            }
            while(r-y>0){
                y--;
                oduzmi();
                broj++;
            }
            if(x<s){
                while(s-x>=2 && Rs>0){
                    x=x-2;
                    Rs--;
                    broj++;
                }
            }else if(x>s){
                //ako je desno
            }
        }else if(y>r){
            //dole
            if(x<s){

            }else if(x>s){
                //ako je desno
            }else{
                //pravo dole
            }
        }else{
            if(x<s){
                //ako je levo
            }else if(x>s){
                //ako je desno
            }else{

            }
        }
    }
    printf("%d",broj);
    return 0;
}
