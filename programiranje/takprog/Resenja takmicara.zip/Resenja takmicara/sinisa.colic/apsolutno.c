#include <stdio.h>
#include <stdlib.h>
#include <math.h>
long A[100000];
long B[100000];
long N;
long sum(long start){
    long i;
    long broj_brojeva=start;
    long sum=0;
    for(i=0;i<N;i++){
        sum = sum + (long)abs(A[broj_brojeva] - B[i]);
        broj_brojeva++;
        if(broj_brojeva==N){
            broj_brojeva=0;
        }
    }
    return sum;
}
int main()
{

    long i;
    long suma = 0;
    scanf("%ld",&N);
    for(i=0;i<N;i++){
        scanf("%ld",&A[i]);
    }
    for(i=0;i<N;i++){
        scanf("%ld",&B[i]);
    }

    for(i=0;i<N;i++){
        suma = suma + sum(i);
    }
    printf("%ld",suma);
    return 0;
}
