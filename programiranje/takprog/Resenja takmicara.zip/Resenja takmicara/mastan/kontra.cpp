#include <cstdio>
#include <algorithm>
#include <queue>

using namespace std;

int mov[4][2]=
{
    1,0,
    -1,0,
    0,1,
    0,-1,
};

char base[1005][1005];
int mark[1005][1005];

int n,m,k;

struct tragac
{
    int x,y;
    int dst;
    inline bool operator < (const tragac &cpr) const
    {
        return dst>cpr.dst;
    }
    inline int range(int tme)
    {
        return min(1ll*n*m+20,1ll*tme*dst+1);
    }
};

int sc;
tragac seek[1000005];
queue <int> kju;

int main()
{
    //freopen("in.txt","r",stdin);
    scanf("%d%d",&n,&m);
    for (int i=1; i<=n; i++)
        scanf("%s",base[i]+1);
    scanf("%d",&sc);
    for (int i=1; i<=sc; i++)
        scanf("%d%d%d",&seek[i].x,&seek[i].y,&seek[i].dst);
    sort(seek+1,seek+1+sc);


    int top=n*m;
    int bot=0;
    int sx,sy;
    sx=-1;
    sy=-1;
    while (top>=bot)
    {
        int tr=(top+bot+1)>>1;
        for (int i=1; i<=n; i++)
            for (int j=1; j<=m; j++)
                mark[i][j]=0;
        if (tr>0)
        {
            int x,y;
            x=seek[1].x;
            y=seek[1].y;
            mark[x][y]=seek[1].range(tr);
            kju.push(x*1337+y);
            int cur=2;
            while (kju.size())
            {
                x=kju.front()/1337;
                y=kju.front()%1337;
                kju.pop();
                int left=mark[x][y];
                while (cur<=sc && seek[cur].range(tr)+1>=left)
                {
                    int nx,ny;
                    nx=seek[cur].x;
                    ny=seek[cur].y;
                    if (mark[nx][ny]<seek[cur].range(tr));
                    {
                        mark[nx][ny]=seek[cur].range(tr);
                        kju.push(nx*1337+ny);
                    }
                    cur++;
                }
                if (left>1)
                    for (int d=0; d<4; d++)
                    {
                        int nx=x+mov[d][0];
                        int ny=y+mov[d][1];
                        if (base[nx][ny]=='0')
                            if (mark[nx][ny]<left-1)
                            {
                                mark[nx][ny]=left-1;
                                kju.push(nx*1337+ny);
                            }
                    }
            }
        }
        int ok=0;
        for (int i=1; i<=n; i++)
            for (int j=1; j<=m; j++)
                if (base[i][j]=='0')
                    if (mark[i][j]==0)
                    {
                        ok=1;
                        sx=i;
                        sy=j;
                    }
        if (ok)
            bot=tr+1;
        else
            top=tr-1;
    }
    printf("%d %d\n",sx,sy);
}
