//Once a Bandle gunner, always a Bandle gunner!
#include <cstdio>
#include <algorithm>

using namespace std;

int vals[100005];

int cnt;
int srt[100005];
int sols[100005];

inline int nadji(int x)
{
    int top=cnt;
    int bot=1;
    int tr;
    while (top>bot)
    {
        tr=(top+bot)>>1;
        if (srt[tr]>=x)
            top=tr;
        else
            bot=tr+1;
    }
    if (srt[top]==x)
        return top;
    return -1;
}

inline int aps(int x)
{
    if (x<0)
        return -x;
    return x;
}

int n;
int ln;

int main()
{
    //freopen("in.txt","r",stdin);
    scanf("%d",&n);
    for (int i=1; i<=n; i++)
    {
        scanf("%d",&vals[i]);
        srt[i]=vals[i];
    }
    {
        int cc=vals[1];
        ln=0;
        while (cc)
        {
            ln++;
            cc/=10;
        }
    }
    sort(srt+1,srt+1+n);
    cnt=1;
    for (int i=2; i<=n; i++)
        if (srt[i]!=srt[cnt])
            srt[++cnt]=srt[i];
    for (int i=1; i<=cnt; i++)
        sols[i]=-1000000000;
    int ret=0;
    for (int it=1; it<=n; it++)
    {
        int pl=nadji(vals[it]);
        sols[pl]=max(sols[pl],0);
        for (int pos=0,ex=1; pos<ln; pos++,ex*=10)
        {
            int dig=(vals[it]/ex)%10;
            for (int nw=0; nw<10; nw++)
            {
                if (nw==dig || (nw==0 && pos==ln-1))
                    continue;
                int broj=vals[it]+ex*(nw-dig);
                int from=nadji(broj);
                if (from!=-1)
                    sols[pl]=max(sols[pl],sols[from]+aps(dig-nw));
            }
        }
        ret=max(ret,sols[pl]);
    }
    printf("%d\n",ret);

}
