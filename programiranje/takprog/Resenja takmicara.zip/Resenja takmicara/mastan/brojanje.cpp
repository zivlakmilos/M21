#include <cstdio>
#include <algorithm>
#define mod (1000000007ll)

using namespace std;

struct vrednost
{
    int pl,val;
    inline bool operator < (const  vrednost &cpr) const
    {
        return val<cpr.val;
    }
};

int n;
int broj[1000005];

int cnt;
vrednost vals[1000005];


long long ret[1000005];
vrednost stk[1000005];
int sze;

inline long long izbroji(long long d)
{
    return ((d*(d+1))>>1ll)%mod;
}

int main()
{
    scanf("%d",&n);
    for (int i=1; i<=n; i++)
    {
        scanf("%d",&broj[i]);
        vals[i].pl=i;
        vals[i].val=broj[i];
    }
    sort(vals+1,vals+1+n);
    cnt=1;
    broj[vals[1].pl]=1;
    for (int i=2; i<=n; i++)
    {
        if (vals[i].val!=vals[cnt].val)
            vals[++cnt]=vals[i];
        broj[vals[i].pl]=cnt;
    }
    n++;
    broj[n]=mod-1;
    sze=1;
    stk[1].val=mod;
    stk[1].pl=0;
    for (int it=1; it<=n; it++)
    {
        sze++;
        stk[sze].val=broj[it];
        stk[sze].pl=it;
        while (stk[sze].val>stk[sze-1].val)
        {
            ret[stk[sze-1].val]+=izbroji(stk[sze].pl-stk[sze-2].pl-1);
            ret[stk[sze-1].val]%=mod;
            ret[stk[sze-1].val]-=izbroji(stk[sze].pl-stk[sze-1].pl-1);
            ret[stk[sze-1].val]%=mod;
            if (ret[stk[sze-1].val]<0)
                ret[stk[sze-1].val]+=mod;
            stk[sze-1]=stk[sze];
                sze--;
        }
        if (broj[it]<=n)
        {
            ret[stk[sze].val]-=izbroji(stk[sze].pl-stk[sze-1].pl-1);
            ret[stk[sze].val]%=mod;
            if (ret[stk[sze].val]<0)
                ret[stk[sze].val]+=mod;
        }
        while (stk[sze].val==stk[sze-1].val)
        {
            stk[sze-1]=stk[sze];
            sze--;
        }
    }
    int q;
    scanf("%d",&q);
    while (q--)
    {
        int x;
        scanf("%d",&x);
        int top,bot,tr;
        top=cnt;
        bot=1;
        while (top>bot)
        {
            tr=(top+bot)>>1;
            if (vals[tr].val>=x)
                top=tr;
            else
                bot=tr+1;
        }
        if (vals[top].val==x)
            printf("%lld\n",ret[top]);
        else
            printf("0\n");
    }
}
