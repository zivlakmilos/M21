#include<stdio.h>
#include<stdlib.h>
#include<math.h>


int main(){
int N, M, K;
int i, j, l;
int T[1005][2];
long long V[1005];
int max=-1, min=-1, r, p;
int mx[2];

scanf("%d %d %d", &N, &M, &K);
for(l=0; l<K; l++)
scanf("%d %d %lld", &T[l][0], &T[l][1], &V[l]);

for(i=1; i<=N; i++)
for(j=1; j<=M; j++, min=-1){
for(l=0; l<K; l++){
r=(sqrt((T[l][0]-i)*(T[l][0]-i)) + sqrt((T[l][1]-j)*(T[l][1]-j)));
for(p=0; r>0; p++)
r=r-V[l];
if(min==-1 || p<min)
min=p;
}
if(min>max){
max=min;
mx[0]=i;
mx[1]=j;
}
}
printf("%d %d", mx[0], mx[1]);




return 0;
}

