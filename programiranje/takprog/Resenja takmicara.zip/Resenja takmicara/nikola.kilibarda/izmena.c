#include<stdio.h>
#include<string.h>

int main(){
int N, r, s;
char Q[500005];
int A=0, B=0;
int p, min=-1, max;
int i, j;
int x=0,y=0;
int x1, y1;
int L=0, R=0, D=0, U=0;

scanf("%d %d %d", &N, &r, &s);
scanf("\n");
gets(Q);
for(i=0; i<N; i++){
switch(Q[i]){
case 'L':
x--;
L++;
break;
case 'R':
x++;
R++;
break;
case 'D':
y++;
D++;
break;
case 'U':
y--;
U++;
break;
}
p=(sqrt((x-r)*(x-r)) + sqrt((y-s)*(y-s)));
x1=x;
y1=y;
if(x>r)
for(j=R; j>0 || x1==r || x1-1==r; j--)
x1--;
else if(x<r)
for(j=L; j>0 || x1==r || x1+1==r; j--)
x1--;
if(y>s)
for(j=D; j>0 || y1==s || y1-1==s; j--)
y1--;
else if(y<s)
for(j=U; j>0 || y1==s || y1+1==s; j--)
y1--;
A=(sqrt((x1-r)*(x1-r)) + sqrt((y1-s)*(y1-s)));
if(min==-1 || A<min) min=A;
}
printf("%d ", min);

x1=x;
y1=y;
if(x>r)
for(j=R; j>0 || x1==r || x1-1==r; j--)
x1--;
else if(x<r)
for(j=L; j>0 || x1==r || x1+1==r; j--)
x1--;
if(y>s)
for(j=D; j>0 || y1==s || y1-1==s; j--)
y1--;
else if(y<s)
for(j=U; j>0 || y1==s || y1+1==s; j--)
y1--;
B=(sqrt((x1-r)*(x1-r)) + sqrt((y1-s)*(y1-s)));
printf("%d ", B);

return 0;
}





