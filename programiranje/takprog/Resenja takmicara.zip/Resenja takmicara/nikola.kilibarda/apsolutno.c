#include<stdio.h>
#include<stdlib.h>


int main(){
int A[100005], B[100005], N;
long long Suma=0;
int i, j;
scanf("%d", &N);
for(i=0; i<N; i++)
scanf("%d", &A[i]);
for(i=0; i<N; i++)
scanf("%d", &B[i]);


for(i=0; i<N; i++){
for(j=N-1; j>=0; j--){
if (A[j]-B[j]>=0) Suma+=(A[j]-B[j]);
else Suma+=(B[j]-A[j]);
A[j+1]=A[j];
}
A[0]=A[N];
}
printf("%lld", Suma);
return 0;
}
