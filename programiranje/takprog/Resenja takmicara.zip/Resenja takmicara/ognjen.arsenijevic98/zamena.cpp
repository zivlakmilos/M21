#include <stdio.h>
#include <algorithm>
using namespace std;
long long int a[100001],maxi[100001];
int main()
{
    long long int n,i,pom,p,q,cif,inpom,l;
    scanf("%lld",&n);
    for(i=0;i<n;i++)
    scanf("%lld",&a[i]);
    for(i=1;i<n;i++)
    {
        for(l=i-1;l>=0;l--)
        { 
           p=a[i];
           pom=0;
           q=a[l];
           while(p>0)
           {
             if((p%10)!=(q%10))
             { 
               pom++;
               if((p%10)>(q%10))
               cif=(p%10)-(q%10);
               else
               cif=(q%10)-(p%10);
               inpom=l;
             }
             p/=10;
             q/=10;
             if(pom>1)
             break;
           }
           if(pom==1)
           {
             if((maxi[inpom]+cif)>maxi[i])
             {
                maxi[i]=maxi[inpom]+cif;
             }
           }
        }
    }
    sort(maxi,maxi+n);
    printf("%lld\n",maxi[n-1]);
    return 0;
}
