#include <stdio.h>
long long int a[1000001];
int main()
{
    long long int i,q,n,k,subarr,j,l,d,num;
    scanf("%lld",&n);
    for(i=0;i<n;i++)
    scanf("%lld",&a[i]);
    scanf("%lld",&q);
    while(q--)
    {
        subarr=0;
        scanf("%lld",&k);
        for(i=0;i<n;i++)
        {
             num=1;
             if(a[i]==k)
             {  
                d=i+1;
                while(a[d]==k)
                {
                   d++;
                   num++;
                }
                subarr+=num;
                j=i-1;
                while((a[j]<=k)&&(j>=0))
                {
                  subarr++;
                  j--;
                }
                j++;
                j=i-j;
                l=i+1;
                while((a[l]<=k)&&(l<n))
                {
                   subarr++;
                   l++;
                }
                l--;
                l=l-i;
                subarr+=((j*l)%1000000007);
                if(subarr>=1000000007)
                   subarr%=1000000007;
                num--;
                while(num--)
                {
                     i++;
                     l=i+1;
                     while((a[l]<=k)&&(l<n))
                     {
                       subarr++;
                       l++;
                     }
                     if(subarr>=1000000007)
                     subarr%=1000000007;       
                }
             }           
        }
        printf("%lld\n",subarr);
    }
    return 0;
}

