#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <queue>
#include <math.h>
#include <algorithm>

using namespace std;

static const int N = 1000;

int finalI = 1, finalJ = 1;
int n, m;
char t[N][N];
int h[N][N];
int k;
int hi[N * N];
int hj[N * N];
//int v[N * N];

struct troInt
{
    int i;
    int j;
    int v;
};

troInt niz[N * N];

bool sameSpeed()
{
    int speed = h[hi[0]][hj[0]];
    for(int i = 0; i < k; i++)
        if(h[hi[i]][hj[i]] != speed)
            return 0;
    return 1;
}

bool noTrees()
{
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            if(t[i][j] == '1')
                return 0;
    return 1;
}

int done[N][N];
int di[4] = {1, -1, 0, 0};
int dj[4] = {0, 0, 1, -1};

bool valid1(int i, int j)
{
    if(i < 0 || i >= n)
        return 0;
    if(j < 0 || j >= m)
        return 0;
    if(t[i][j] == '1')
        return 0;
    if(done[i][j])
        return 0;
    return 1;
}

bool valid2(int i, int j)
{
    if(i < 0 || i >= n)
        return 0;
    if(j < 0 || j >= m)
        return 0;
    if(t[i][j] == '1')
        return 0;
 //   if(done[i][j])
  //      return 0;
    return 1;
}

void funk1()
{
    //printf("1\n");
    queue <int> qi;
    queue <int> qj;
    for(int i = 0; i < k; i++)
    {
        qi.push(hi[i]);
        qj.push(hj[i]);
        done[hi[i]][hj[i]] = 1;
    }
    int ci, cj;
    while(!qi.empty())
    {
        ci = qi.front();
        cj = qj.front();
        qi.pop();
        qj.pop();
        for(int k = 0; k < 4; k++)
            if(valid1(ci + di[k], cj + dj[k]))
            {
                qi.push(ci + di[k]);
                qj.push(cj + dj[k]);
                done[ci + di[k]][cj + dj[k]] = 1;
            }
    }
    finalI = ci;
    finalJ = cj;
}

int pi[4];
int pj[4];

void funk2()
{
    //printf("2\n");
    pi[0] = 0;
    pi[1] = 0;
    pi[2] = n - 1;
    pi[3] = n - 1;

    pj[0] = 0;
    pj[1] = m - 1;
    pj[2] = 0;
    pj[3] = m - 1;

    int best[4] = {0, 0, 0, 0};
    for(int i = 0; i < k; i++)
    {
        for(int k = 0; k < 4; k++)
        {
            if(abs(hi[i] - pi[k]) + abs(hj[i] - pj[k]) > best[k])
            {
                best[k] = abs(hi[i] - pi[k]) + abs(hj[i] - pj[k]);
            }
        }
    }
    int fin = 0;
    finalI = 0;
    finalJ = 0;
    for(int i = 0; i < 4; i++)
        if(best[i] > fin)
        {
            printf("%i %i %i %i\n", fin, i, pi[i], pj[i]);
            fin = best[i];
            finalI = pi[i];
            finalJ = pj[i];
        }
}

void funk3()
{
    //printf("3\n");
    queue <int> qi;
    queue <int> qj;
    queue <int> s;
    for(int i = 0; i < k; i++)
    {
        qi.push(hi[i]);
        qj.push(hj[i]);
        s.push(h[hi[i]][hj[i]]);
        done[hi[i]][hj[i]] = 1;
    }
    int ci, cj, speed;
    while(!qi.empty())
    {
        ci = qi.front();
        cj = qj.front();
        speed = s.front();
        qi.pop();
        qj.pop();
        s.pop();
        for(int k = 0; k < 4; k++)
            if(valid1(ci + di[k], cj + dj[k]))
            {
                qi.push(ci + di[k]);
                qj.push(cj + dj[k]);
                done[ci + di[k]][cj + dj[k]] = 1;
            }
    }
    finalI = ci;
    finalJ = cj;
}

void panic()
{
    //printf(":D\n");
}

bool compare(troInt a, troInt b)
{
    if(a.v > b.v)
        return 1;
    return 0;
}

int main()
{
    //freopen("input.in", "r", stdin);
    scanf("%i", &n);
    scanf("%i", &m);
    for(int i = 0; i < n; i++)
        scanf("%s", t[i]);

    //printf("Prosao");
    scanf("%i", &k);
    for(int i = 0; i < k; i++)
    {
        int x, y, s;
        scanf("%i", &x);
        scanf("%i", &y);
        x--;
        y--;
        scanf("%i", &s);
        if(h[x][y] < s)
            h[x][y] = s;
    }
    k = 0;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            if(h[i][j])
            {
                hi[k] = i;
                hj[k] = j;
                k++;
            }
    if(sameSpeed())
        funk1();
    // else
    /*{
        if(noTrees())
            funk2();
        else
        {
            if(n <= 400 && m <= 400)
                funk3();
            else
                panic();
        }
    }*/
    else
    {
        for(int i = 0; i < k; i++)
        {
            niz[i].i = hi[i];
            niz[i].j = hj[i];
            niz[i].v = h[hi[i]][hj[i]];
        }
        sort(niz, niz + k, compare);
        //for(int i = 0; i < k; i++)
         //   printf("%i %i %i\n", niz[i].i, niz[i].j, niz[i].v);
        for(int i = 0; i < n; i++)
            for(int j = 0; j < m; j++)
                if(valid1(i, j))
                    done[i][j] = 10000000;
        for(int i = 0; i < k; i++)
        {
            queue <int> qi;
            queue <int> qj;
            queue <int> ras;
            qi.push(niz[i].i);
            qj.push(niz[i].j);
            ras.push(0);
            done[niz[i].i][niz[i].j] = 0;
            while(!qi.empty())
            {
                int ci, cj, rast;
                ci = qi.front();
                cj = qj.front();
                rast = ras.front();
                qi.pop();
                qj.pop();
                ras.pop();
                for(int k = 0; k < 4; k++)
                {
                    //printf("%i", valid1(ci + di[k], cj + dj[k]));
                    //system("PAUSE");
                    if((rast + 1) % niz[i].v)
                        rast += niz[i].v;
                    if(valid2(ci + di[k], cj + dj[k]) && done[ci + di[k]][cj + dj[k]] > ((rast + 1) / niz[i].v))
                    {
                        done[ci + di[k]][cj + dj[k]] = (rast + 1) / niz[i].v;
                        qi.push(ci + di[k]);
                        qj.push(cj + dj[k]);
                        ras.push(rast + 1);
                    }
                    if((rast + 1)% niz[i].v)
                        rast -= niz[i].v;
                }
            }
        }
        int best = 0;
        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < m; j++)
                if(done[i][j] > best)
                {
                    best = done[i][j];
                    finalI = i;
                    finalJ = j;
                }
        }
    }
    printf("%i %i\n", finalI + 1, finalJ + 1);
    return 0;
}
