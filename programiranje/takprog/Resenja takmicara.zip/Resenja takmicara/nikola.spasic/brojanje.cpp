#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <algorithm>
#include <math.h>

using namespace std;

static const int N = 1000000;

int niz[2 * N];

struct tree
{
    int n;
    tree()
    {
        for(int i = 0; i < N; i++)
            niz[i] = 0;
    }
    void setSize(int s)
    {
        n = 1;
        while(n < s)
            n *= 2;
        //printf("%i\n", n);
    }
    void change(int pos, int val)
    {
        pos += n;
        niz[pos] = val;
        pos /= 2;
        while(pos)
        {
            niz[pos] = max(niz[2 * pos], niz[2 * pos + 1]);
            pos /= 2;
        }
    }
    int query(int c, int gl, int gd, int l, int d)
    {
        if(l <= gl && d >= gd)
            return niz[c];
        if(l >= gd || d <= gl)
            return 0;
        int mid = (gl + gd) / 2;
        return max(query(2 * c    , gl, mid, l, d),
                   query(2 * c + 1, mid, gd, l, d));
    }
    int query(int l, int d)
    {
        return query(1, 0, n, l, d + 1);
    }
    void print()
    {
        printf("%i\n", n);
        for(int i = 1; i < 2 * n; i++)
            printf("%i ", niz[i]);
        printf("\n");
    }
};

int a[N];
int b[N];
//int c[N];
int d[N];
long long r[N];
int k;

int trazi(int x)
{
    int l = 0;
    int r = k;
    if(x == d[l])
        return 0;
    if(x == d[r])
        return k;
    while(l < r - 1)
    {
        int mid = (l + r) / 2;
        if(d[mid] < x)
            l = mid;
        if(d[mid] > x)
            r = mid;
        if(d[mid] == x)
            return mid;
    }
    return k + 1;
    /*
    for(int i = 0; i <= k; i++)
        if(d[i] == x)
            return i;
    */
}
/*
int foolNiz[100];

void fool(int n)
{
    for(int i = 0; i < n; i++)
        for(int j = i; j < n; j++)
        {
            int top = a[j];
            for(int k = i; k <= j; k++)
                if(a[k] > top)
                    top = a[k];
            foolNiz[top]++;
           // printf("%i %i %i\n", i, j, top);
        }
}
*/
int main()
{
    //freopen("input.in", "r", stdin);
    tree t;
    int n;
    scanf("%i", &n);
    //n = 100000;
    //srand(126);
    //n = rand() % 100;
    t.setSize(n);
    //printf("her");
    for(int i = 0; i < n; i++)
    {
        //printf("%i", i);
        scanf("%i", &a[i]);
       // a[i] = 1;
        //a[i] = rand() % 50;
        t.change(i, a[i]);
        b[i] = a[i];
    }
    //printf("wot?");
    //fool(n);
    sort(b, b + n);
    k = 0;
    //c[0] = 0;
    d[0] = b[0];
    for(int i = 1; i < n; i++)
    {
        if(b[i] != b[i - 1])
        {
            k++;
            d[k] = b[i];
        }
        //c[i] = k;
    }
    /*
    for(int i = 0; i < n; i++)
        printf("%i ", b[i]);
    printf("\n");
    for(int i = 0; i < n; i++)
        printf("%i ", c[i]);
    printf("\n");
    for(int i = 0; i <= k; i++)
        printf("%i ", d[i]);
    printf("\n");
    */
    int poc = 1;
    while(poc * 2 < n)
        poc *= 2;
    //    printf("damn it");
    for(int i = 0; i < n; i++)
    {
       // if(i % 100000 == 0)
       //     printf(":(");
        /*
        int l = 1;
        int d = 1;
        int j = i - 1;
        while(j >= 0 && t.query(j, i) <= a[i])
        {
            j--;
            l++;
        }
        j = i + 1;
        while(j < n && t.query(i, j) <= a[i])
        {
            j++;
            d++;
        }
        //printf("%i %i\n", l, d);
        */
        int rast = poc;
        int l = i;
        if(i != 0 && a[i - 1] < a[i])
        {
            l = i - 1;
            while(rast)
            {
                if(l - rast >= 0 && t.query(l - rast, l) < a[i])
                    l -= rast;
                rast /= 2;
            }
        }
        //if(l - 1 > 0 && a[l - 1] == a[i])
        //    l = -1;
       // printf("%i", l);

        rast = poc;
        int f = i;
        if(i != n - 1 && a[i + 1] <= a[i])
        {
            f = i + 1;
            while(rast)
            {
                if(f + rast < n && t.query(f, f + rast) <= a[i])
                    f += rast;
                rast /= 2;
            }
        }
       // printf(" %i\n", f);
       // if(l != -1)
        //printf("%i %i\n", l, f);
        int p = i - l + 1;
        p *= f - i + 1;
        //cout << p << endl;
        r[trazi(a[i])] += p;
        //printf("%i\n", trazi(a[i]));
        //r[trazi(a[i])] += l * d;
    }

    int q;
    scanf("%i", &q);
    //q = 1000000;
    //q = rand() % 1000;
    for(int br = 0; br < q; br++)
    {
        int x;
        //x = rand() % 50;
        scanf("%i", &x);
        //x = 1;
        //printf("%i ", foolNiz[x]);
        //int result = foolNiz[x];

        if(trazi(x) == k + 1)
            printf("0\n");
        //    result -= 0;
        else
            cout << r[trazi(x)] << endl;
        //    result -= r[trazi(x)];
        //if(result)
        //    printf(":(\n");
    }

    return 0;
}
