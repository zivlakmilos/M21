#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

using namespace std;

static const int N = 100000;

int niz[N];
int d[100 * N];
//int v[100 * N];
int pom[70];
int val[70];
int k;

void razlozi(int x)
{
    int a[10], b[10];
    for(int i = 0; i < 10; i++)
        a[i] = 0;
    int cur = 0;
    while(x)
    {
        a[cur] = x % 10;
        x /= 10;
        cur++;
    }
    k = 0;
    for(int i = 0; i < cur; i++)
    {
        for(int j = 0; j < cur; j++)
            b[j] = a[j];
        for(int j = 0; j < 10; j++)
        {
            if(j || i != cur - 1)
            {
                b[i] = j;
                pom[k] = 0;
                for(int l = cur - 1; l >= 0; l--)
                {
                    pom[k] *= 10;
                    pom[k] += b[l];
                }
                val[k] = a[i] - b[i];
                if(val[k] < 0)
                    val[k] *= -1;
                k++;
            }
        }
    }
    //for(int i = 0; i < k; i++)
     //   printf("%i %i\n", pom[i], val[i]);
}

int help[10000];

int cmp(int x, int y)
{
    int raz = 0;
    while(x || y)
    {
        if(y && !x)
            return 0;
        if(x && !y)
            return 0;
        if(x % 10 != y % 10)
        {
            if(raz)
                return 0;
            else
                raz = abs(x % 10 - y % 10);
        }
        x /= 10;
        y /= 10;
    }
    return raz;
}
/*
void fool(int n)
{
    //printf("%i\n", cmp(1, 10));
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < i; j++)
        {
            int k = cmp(niz[i], niz[j]);
            if(k)
            {
                if(help[i] < help[j] + k)
                    help[i] = help[j] + k;
            }
        }
       // printf("%i\n", help[i]);
    }
    int best = 0;
    for(int i = 0; i < n; i++)
        if(help[i] > best)
            best = help[i];
    printf("%i\n", best);
}
*/
int main()
{
    //freopen("input.in", "r", stdin);
    int n;
    scanf("%i", &n);
    //srand(142535);
    //n = rand() % 10000;
    for(int i = 0; i < n; i++)
    {
        //niz[i] = -i + 1 + 9000000;
        //printf("%i\n", niz[i]);
        scanf("%i", &niz[i]);
        //niz[i] = rand() % 100;
    }
    for(int i = 0; i < 10000000; i++)
        d[i] = -1;
    //fool(n);
    //printf("%i\n", niz[0]);
    for(int i = 0; i < n; i++)
    {
        razlozi(niz[i]);
        int best = 0;
        for(int j = 0; j < k; j++)
            if(d[pom[j]] != -1 && d[pom[j]] + val[j] > best)
                best = d[pom[j]] + val[j];
        d[niz[i]] = best;
        //printf("%i\n", d[niz[i]]);
    }
    int bestest = 0;
    for(int i = 0; i < 10000000; i++)
        if(d[i] > bestest)
            bestest = d[i];
    printf("%i\n", bestest);
    return 0;
}
