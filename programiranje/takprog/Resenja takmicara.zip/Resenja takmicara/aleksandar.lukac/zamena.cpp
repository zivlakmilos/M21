#include <iostream>
#include <vector>

using namespace std;

int n;
int brbodova=0;
vector <int> niz;
int maxim=0;
int vrednost[100005];

int logg(int a)
{
    int i;
    while(a>=1)
    {
        i++;
        a=a/10;
    }
    return i;
}

bool provera(int a)
{
    if((a<10)&&(a>0))
        return true;
    else
    {
        if(a%10==0)
            return provera(a/10);
        else
            return false;
    }
}

int provera1(int a)
{
    for(int i=0;i<logg(a);i++)
    {
        if(a%10!=0)
        {
            break;
        }
        a/=10;
    }
    return a;
}

void trazi(int a) // pozicija u nizu
{
    if(vrednost[a]==-1)
    {
        for(int i=a+1;i<n;i++)
        {
            int razlika=niz[i]-niz[a]; if(razlika<0) razlika=-razlika;
            if(razlika!=0){
                if(provera(razlika))
                {
                    if(vrednost[i]!=-1){
                        if(vrednost[i]+provera1(razlika)>vrednost[a])
                            vrednost[a]=vrednost[i]+provera1(razlika);}
                    else
                        {if(provera1(razlika)>vrednost[a])
                            vrednost[a]=provera1(razlika);}
                }
            }
        }
    }
}

int main()
{
    fill_n(vrednost,100005,-1);
    cin >> n;
    for(int i=0;i<n;i++)
    {
        int a;
        cin >> a;
        niz.push_back(a);
    }
    int maxx=0;
    for(int i=n-1;i>=0;i--)
    {
        trazi(i);
        if(vrednost[i]>maxx)
            maxx=vrednost[i];
    }
    cout << maxx;
    return 0;
}

/*
6
8823
2145
2185
3385
4145
4445
*/

/*
6
14231
11789
17789
77789
64231
54231
*/
