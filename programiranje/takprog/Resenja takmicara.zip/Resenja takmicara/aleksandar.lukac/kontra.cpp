#include <iostream>
#include <cmath>

using namespace std;


int n,m;
int matrica[1005][1005];
long long speed;

int spd(int a)
{
    if(a%speed==0)
        return a/speed;
    else
        return a/speed+1;
}

int main()
{
    cin >> n >> m;

    for(int i=0;i<n;i++)
        for(int j=0;j<m;j++){
            cin >> matrica[i][j]; matrica[i][j]=-1; }
    int k;
    int maxx=0,maxy=0,maxxes=0;
    cin >> k;
    for(int q=0;q<k;q++)
    {
        int x,y;
        cin >> x >> y >> speed;
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++)
            {
                if(matrica[i][j]==-1)
                {
                    matrica[i][j]=spd(sqrt((i-x)*(i-x)+(j-y)*(j-y)));
                }
                else
                {
                    matrica[i][j]=min(matrica[i][j],spd(sqrt((i-x)*(i-x)+(j-y)*(j-y))));
                }
                if(matrica[i][j]>maxxes)
                    {
                        maxxes=matrica[i][j];
                        maxx=i;
                        maxy=j;
                    }
            }
        }
    }
    cout << maxx << endl << maxy << maxxes;
    return 0;
}

/*
6 5
0 0 0 0 0
0 0 0 0 0
0 0 0 0 0
0 0 0 0 0
0 0 0 0 0
0 0 0 0 0
2
1 1 1
6 1 1
*/
