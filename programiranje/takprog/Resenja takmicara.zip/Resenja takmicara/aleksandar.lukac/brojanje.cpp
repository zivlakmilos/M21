#include <iostream>
#include <vector>

using namespace std;

int n,q;
vector <int> niz;
int upit[1000000];
int rez[1000000];

int main()
{
    cin >> n;
    for(int i=0;i<n;i++)
    {
        int a;
        cin >> a;
        niz.push_back(a);
    }
    cin >> q;
    for(int i=0;i<q;i++)
    {
        int upit;
        cin >> upit;
        long long bla=0;;
        for(int i=0;i<n;i++)
        {
            if(niz[i]==upit)
            {
                int levo=0;
                int desno=0;
                if(i<n-1)
                    for(int j=i+1;j<n;j++)
                    {
                        if(niz[j]<=niz[i])
                            { if(niz[j]!=niz[i]) desno++;}
                        else
                            break;
                    }
                if(i>0)
                    for(int j=i-1;j>=0;j--)
                    {
                        if(niz[j]<=niz[i])
                            levo++;
                        else
                            break;
                    }
                bla=(bla+(levo+1)*(desno+1))%1000000007;
            }
        }
        cout << bla << endl;
    }
    return 0;
}
