#include <cstdio>
#include <cstdlib>
#include <algorithm>


using namespace std;

const int MAXN = 1000003;
const long long mod = 1000000007;

int n,q;
long long A[MAXN];
long long Q[MAXN];
long long res[MAXN];

int L[MAXN],D[MAXN];





int main()
{

    int ind;
   scanf("%d",&n);
   for(int i = 0;i < n;i++) scanf("%lld",&A[i]);
   scanf("%d",&q);

   for(int i = 0;i < q;i++) scanf("%lld",&Q[i]);

   L[0] = D[n-1] = 0;




   for(int i = 1;i < n;i++)
   {
       if(A[i]>=A[i-1])
       L[i] = L[i-1]+1;
       else L[i] = 0;

   }

   for(int i = n-2;i >= 0;i--)
   {

     if(A[i]>=A[i+1]) D[i] = D[i+1] + 1;
     else D[i] = 0;
   }

   for(int i = 0; i < q;i++)
     for(int j = 0; j < n;j++)
         if(Q[i] == A[j] ) res[i] = (res[i]+(D[j]+1)*(L[j]+1))%mod;



   for(int i = 0; i < q;i++)
   printf("%lld ",res[i]);


   printf("\n");

   return 0;
}
