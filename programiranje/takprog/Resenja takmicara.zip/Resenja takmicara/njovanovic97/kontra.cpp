#include <cstdio>
#include <cstdlib>
#include <queue>
#include <algorithm>

using namespace std;


const int MAXN = 1003;
const int MAXK = 1000000;
const int smerX[4] = {1,0,-1,0};
const int smerY[4] = {0,1,0,-1};


char park[MAXN][MAXN];
int n,m,k;
int poljeX[MAXK],poljeY[MAXK];
int x[MAXK],y[MAXK],v[MAXK];
int maxVrednost[MAXK];




void BFS(int brojac)
{
  int x1,y1,v1,v2,vrednost;
  int maximum = 0;
  queue<int> kju;
  kju.push(x[brojac]);
  kju.push(y[brojac]);
  kju.push(v[brojac]);
  kju.push(1);
  v2 = v[brojac];

  while(!kju.empty())
{

  x1 = kju.front(); kju.pop();
  y1 = kju.front(); kju.pop();
  v1 = kju.front(); kju.pop();
  vrednost = kju.front(); kju.pop();
  maximum = max(maximum,vrednost);
  poljeX[brojac] = x1; poljeY[brojac] = y1;
  park[x1][y1] = '2';

  for(int i = 0;i < 4;i++)
  {
      if(x1+smerX[i] <0 || x1+smerX[i] > m-1 || y1+smerY[i] <0 || y1+smerY[i] > n-1) continue;
      if(park[x1+smerX[i]][y1+smerY[i]] == '1' || park[x1+smerX[i]][y1+smerY[i]] == '2') continue;

      kju.push(x1+smerX[i]);
      kju.push(y1+smerY[i]);
      if(v1 != 0)
      {
          kju.push(v1-1);
          kju.push(vrednost);
      }
      else
      {
        v1 = v2;
        kju.push(v1-1);
        kju.push(vrednost+1);
      }


  }

}

 maxVrednost[brojac] = maximum;

}


int main()
{


    scanf("%d%d",&n,&m);
    for(int i = 0;i < n;i++)
      scanf("%s",park[i]);




     scanf("%d",&k);
     for(int i = 0;i < k;i++)
       {
           scanf("%d%d%d",&x[i],&y[i],&v[i]);
           x[i]--;
           y[i]--;
       }
    for(int i = 0;i < k;i++)
     {
    BFS(i);
    for(int i = 0;i < n;i++)
      for(int j = 0; j < m;j++)
            if(park[i][j] == '2') park[i][j] = '0';


     }
     for(int i = 0;i < k;i++)
       printf("%d\n",maxVrednost[i]);

    int minVrednost = 1003,px,py;
    for(int i = 0;i < k;i++)
    {
        if(maxVrednost[i]<minVrednost)
        {
            minVrednost = maxVrednost[i];
            px = poljeX[i];
            py = poljeY[i];
        }
    }


    printf("%d %d\n",py+1,px+1);

    return 0;
}
