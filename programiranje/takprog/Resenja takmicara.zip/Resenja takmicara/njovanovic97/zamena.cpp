#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <string>
#include <iostream>

using namespace std;

const int MAXN = 10003;

int n;
char A[MAXN][10];
int graf[MAXN][MAXN];
int res;

int main()
{
  int cifra = 0,br = 0,raz,res1 = 0;

  scanf("%d",&n);
  for(int i = 0; i < n;i++)
   scanf("%s", A[i]);

 for(int i = 0 ; A[0][i];i++)
     cifra++;
for(int i = 0 ; i < n-1;i++)
   for(int j = i+1; j < n;j++)
   {
       for(int c = 0; c < cifra ;c++)
           if(A[i][c]!=A[j][c]) {raz = abs(A[i][c]-A[j][c]); br++;}



       if(br == 1)
        graf[i][j] = graf[j][i] = raz;



       br = 0;
   }


for(int i = 0 ; i < n;i++)
 {
    for(int j = 0; j < n;j++)

        res1 += graf[j][i];

    res = max(res,res1);
    res1=0;

 }



  return 0;
}
