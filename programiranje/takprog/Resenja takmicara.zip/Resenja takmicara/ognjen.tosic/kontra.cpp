#include <cstdio>
#include <queue>
#include <algorithm>
#include <iostream>

using namespace std;

int N, M;
long K;
long* V;

int* posX;
int* posY;

bool** mapa;

bool update(long** dist, bool** vis, int x, int y, int cur) {
      if(x >= 0 && y >= 0 && x < N && y < M) {    
           if(!vis[x][y] && !mapa[x][y]){
               dist[x][y] = cur+1;
               vis[x][y] =true;
               return true;
           }
      } 
      return false;
}

void istrazi(int x, int y, long** dist) {
     bool** vis = new bool*[N];
     for(int i = 0; i<N;i++) {
         vis[i] = new bool[M];
         for(int j=0;j<M;j++) { vis[i][j] =false; dist[i][j]=-1;}
     }
     vis[x][y]=true;
     dist[x][y]=0;
     queue< pair<int,int> > Q;
     Q.push(pair<int,int>(x,y));
     while(!Q.empty()) {
          pair<int,int> curr=Q.front();
          Q.pop();
          if(update(dist,vis,curr.first-1,curr.second,dist[curr.first][curr.second])) Q.push(pair<int,int>(curr.first-1,curr.second));
          if(update(dist,vis,curr.first+1,curr.second,dist[curr.first][curr.second])) Q.push(pair<int,int>(curr.first+1,curr.second));
          if(update(dist,vis,curr.first,curr.second-1,dist[curr.first][curr.second])) Q.push(pair<int,int>(curr.first,curr.second-1));
          if(update(dist,vis,curr.first,curr.second+1,dist[curr.first][curr.second])) Q.push(pair<int,int>(curr.first,curr.second+1));
     }
}
long min2(long a, long b) {
     if(a==-1 || b==-1) return a+b+1;
     return (a>b ? b : a);
}
long** skriv;
void skrivenost() {
     skriv =new long*[N];
     for(int i =0; i<N;i++) {
        skriv[i] = new long[M];
        for(int j=0;j<M;j++){
            skriv[i][j]=-1;    
        }
     }
     long** tmp = new long*[N];
     for(int i=0;i<N;i++) tmp[i]=new long[M];
     for(long i=0;i<K;i++){
         istrazi(posX[i],posY[i],tmp);
         for(int l=0;l<N;l++)
                 for(int j=0;j<M;j++) {
                     skriv[l][j]=min2(skriv[l][j], tmp[l][j] / V[i] + (tmp[l][j] % V[i] == 0 ? 0 : 1));
                  }
         for(int l=0;l<N;l++)
                 for(int j=0;j<M;j++)
                         tmp[l][j]=0;
     }
}

int main() {
    scanf("%d %d", &N, &M);
    mapa =new bool*[N];
    for(int i = 0;i<N;i++) {
        mapa[i]=new bool[M];
        string str;
        cin >> str;
        for(int j =0;j<M;j++) mapa[i][j]=(str[j] == '1');
    }
    
    scanf("%ld", &K);
    V =new long[K];
    posX =new int[K];
    posY = new int[K];
    for(long i =0;i<K;i++) {
             scanf("%d %d %ld", &posX[i],&posY[i], &V[i]);
             posX[i]--; posY[i]--;
    }
    skrivenost();
    
    long t =-1; int w, z;
    for(int i = 0;i < N;i++)
        for(int j=0;j<M;j++) 
            if(skriv[i][j]>t && !mapa[i][j]) { t=skriv[i][j]; w=i; z=j; }
    printf("%d %d", w+1, z+1);
    return 0;
}
