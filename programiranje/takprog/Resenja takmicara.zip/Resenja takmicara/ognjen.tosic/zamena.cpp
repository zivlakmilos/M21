#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string>

using namespace std;


long N;
long* A;
pair<string,long>* B;
long* d;

string to_str(long x) {
     string s = "";
     while(x>0){
                s = (char)(x%10+48)+s;
                x/=10;
     }
     return s;
}
void pop_b() {
     B=new pair<string,long>[N];
     for(long i=0;i<N;i++) B[i]=pair<string, long>(to_str(A[i]),i);
     sort(B,B+N);
     
}
long nadji(string s,long p,long q) {
     if(s<B[p].first||s>B[q].first) return -1;
     long mid=p+(q-p)/2;
     if(B[mid].first==s)return mid;
     if(B[mid].first>s) return nadji(s,p,mid);
     return nadji(s,mid+1,q);
}
long dp(long idx) {
     if(d[idx]==-1){
         d[idx]=0;
         for(int i =0;i<B[idx].first.length();i++) 
             for(int cfr=0;cfr<10;cfr++) {
                 if((char)(cfr+48)!=B[idx].first[i]){
                        string bprim = B[idx].first;
                        bprim[i] = (char)(cfr+48);
                        long h=nadji(bprim,0,N-1);
                        if(h !=-1) if(B[h].second < B[idx].second) {
                             if(dp(h) + abs(B[idx].first[i]-bprim[i])>d[idx]) d[idx]=dp(h) + abs(B[idx].first[i]-bprim[i]);
                        }
                    }
             }
     }
     return d[idx];
}

int main() {
    scanf("%ld", &N);
    A = new long[N];
    d = new long[N];
    for(long i =0; i<N;i++) {
       scanf("%ld", &A[i]);
       d[i] = -1;
    }
    pop_b();
    for(long i=0;i<N;i++) dp(i);
    long M=d[0];
    for(long i=1;i<N;i++) if(d[i]>M) M=d[i];
    printf("%ld", M);
    return 0;
}
