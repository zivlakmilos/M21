#include <cstdio>
#include <algorithm>
#include <vector>

#define MOD 1000000007

using namespace std;

long N;
long Q;
long* A;

int main() {
     scanf("%ld", &N);
     for(long i = 0;i <N; i++) scanf("%ld", &A[i]);
     scanf("%ld", &Q);
     for(long i =0; i<Q;i++) {
          long k; scanf("%ld", &k);
          vector<int> pos;
          for(long j =0;j<N;j++)
             if(A[j] ==k) pos.push_back(j);
          long* s =new long[pos.size()];
          long* e = new long[pos.size()];
          for(long j = 0;j < pos.size();j++) {
                   s[j] = pos[j];
                   for(; s[j]>=0;s[j]--) if(A[s[j]]>k) break;
                   s[j]++;
                   s[j] = pos[j] - s[j];
                   e[j]=pos[j];
                   for(; e[j]<N; e[j]++) if(A[e[j]]>k) break;
                   e[j]--;
                   e[j] -= pos[j];
          }
          long cnt = 0;
          for(long j =0; j < pos.size();j++)
                   cnt += (s[j] +1) * (e[j] + 1);
          
          printf("%ld\n", cnt);       
     }
    
    return 0;
}
