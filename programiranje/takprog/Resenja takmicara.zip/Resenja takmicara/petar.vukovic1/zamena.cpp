#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <math.h>
#include <algorithm>
#define lld long long
using namespace std;


int n;
lld A[100005];

int sli(lld a,lld b)
{
    int x=0;
    while (a>0)
    {
          if (a%10!=b%10)x++;
          a/=10;b/=10;
    }
    if (x>1)
    return 0;
    else
    return 1;
}

int raz(lld a,lld b)
{
    if(a==0)return b-a;
    if(b==0)return a-b;
    while (a>0)
    {
          if(a%10!=b%10)
          {
          if(a%10>=b%10)return a%10-b%10;
          else return b%10-a%10;
          }
          else
          {a/=10;b/=10;}
    }
    return 0;
}

int F(lld a[],int c,int r,int m)
{
    int s1=0,s2=0;
    if(r==m-1)
    {
     if(sli(a[c],a[r]))
     return raz(a[c],a[r]);
     else 
     return 0;
    }
    
    s1=F(a,c,r+1,m);
    if(sli(a[c],a[r]))
    s2=raz(a[c],a[r])+F(a,r,r+1,m);
    
    return max(s1,s2);
}

int main()
{
    
    int n;
    lld A[100005];
    scanf("%d",&n);
    for (int i=0;i<n;i++)
    scanf("%lld",&A[i]);
    int m=0;
    for (int i=0;i<n-1;i++)
    {int x=F(A,i,i,n);
     if (x>m)m=x;
    }
     printf("%d\n",m);
     
     
    
    return 0;
}
