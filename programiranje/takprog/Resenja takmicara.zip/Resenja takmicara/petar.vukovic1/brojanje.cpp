#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <math.h>
#include <algorithm>
#define lld long long
using namespace std;

int n,q;
lld a[1000005],k[1000005];

int brm(lld a[],int n,lld m)
{
    int s=0;
    for (int i=0;i<n;i++)
    if(a[i]==m)s++;
    return s;
}

int ld(lld l,lld d)
{
return ((l+1)*(d+1))%1000000007; 
}

int br(lld a[],int n,lld m)
{
    int s=0;
   
    int n1=brm(a,n,m);
    for (int j=0;j<n1;j++)
    {
     bool x=1;
     lld l=0,d=0;
     for(int i=0;i<n;i++)
     {
     if (a[i]<m){if(x)l++;else d++;}
     else
     if (a[i]==m){x=0;a[i]--;}       
     else
     if (a[i]>m){if(!x)break;else l=0;}
     }
     s+=ld(l,d);
    }
    return s;
}



int main()
{

    
    scanf("%d",&n);
    for (int i=0;i<n;i++)
    scanf("%lld",&a[i]);
    scanf("%d",&q);
    for (int i=0;i<q;i++)
    scanf("%lld",&k[i]);
    
    for (int i=0;i<q;i++)
    {
    
        printf("%d",br(a,n,k[i]));
        
    }
    
    
 return 0;   
}
