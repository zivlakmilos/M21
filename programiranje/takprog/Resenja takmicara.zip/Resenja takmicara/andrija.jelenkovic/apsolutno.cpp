#include <iostream>
#include <algorithm>
#include <stdio.h>
using namespace std;
int a[100000],b[100000],z=0;

int main()
{
    int n,s=0,k,bs=0;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=0;i<n;i++)
    {
        scanf("%d",&b[i]);
        bs+=b[i];
    }
    sort(b,b+n);
    for(int i=0;i<n;i++)
    {
        z=0;
        for(int j=0;j<n;j++)
        {
            if(b[j]>a[i])
            {
                k=j-1;
                break;
            }
            z+=b[j];
            k=j;
        }
        k++;
        s+=(a[i]*k-z)+(bs-z-a[i]*(n-k));
    }
    printf("%d",s);
    return 0;
}
