#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <math.h>
using namespace std;
int mapa[1000][1000],x[1000],y[1000],v[1000];

int mini(int x1,int y1,int k)
{
    int min,p;
    min=(abs(x[0]-x1)+abs(y[0]-y1))/v[0];
    for(int i=1;i<k;i++)
    {
        p=(abs(x[i]-x1)+abs(y[i]-y1))/v[i];
        if(p<=min)
            min=p;
    }
    return min;
}

int main()
{
    int n,m,k,maxi=-1,maxx,maxy;
    scanf("%d%d%d",&n,&m,&k);
    for(int i=0;i<k;i++)
    {
        cin>>x[i]>>y[i]>>v[i];
        x[i]--;
        y[i]--;
    }

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            mapa[i][j]=mini(j,i,k);
        }
    }


    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(mapa[i][j]>maxi)
            {
                maxi=mapa[i][j];
                maxx=j;
                maxy=i;
            }
        }
    }

    printf("%d %d",maxy+1,maxx+1);
    return 0;
}
