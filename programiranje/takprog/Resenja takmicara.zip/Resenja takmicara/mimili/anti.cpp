#include <iostream>
#include <stdio.h>
#include <cstdlib>

using namespace std;

int x[1000];
int y[1000];
int v[1000];

int mink(int i,int j,int k)
{
    int min=1000000000,s=0;
    for(int ik=0;ik<k;ik++)
    {
            s=0;


            if(x[ik]>i)
            {
                s=s+x[ik]-i;
            }
            else
            {
                s=s+i-x[ik];
            }


            if(y[ik]>j)
            {
                s=s+y[ik]-j;
            }
            else
            {
                s=s+j-y[ik];
            }


            if(s%v[ik]==0)
            {
                s=s/v[ik];
            }
            else
            {
                s=s/v[ik]+1;
            }


            if(s<min)
            {
                min=s;
            }
            if(s==0)
            break;
    }
return min;

}

int main()
{
    int n,m,k;
    int maxmin=0,min;
    int maxx,maxy;
    scanf("%d%d%d",&n,&m,&k);
    for(int i=0;i<k;i++)
    {
        scanf("%d%d%d",&x[i],&y[i],&v[i]);
    }
    if(k==0)
    {
        int maxc=0;
        int c1,c2,c3,c4;
        c1=x[0]-1+y[0]-1;
        maxc=c1;
        c2=x[0]-1+m-y[0];
        if(c2>maxc)
        {
            maxc=c2;
        }
        c3=n-x[0]+y[0]-1;
        if(c3>maxc)
        {
            maxc=c3;
        }
        c4=n-x[0]+m-y[0];
        if(c4>maxc)
        {
            maxc=c4;
        }
        if(maxc==c1)
        {
            printf("1 1");
        }
        else if(maxc==c2)
        {
            printf("1 %d",m);
        }
        else if (maxc==c3)
        {
            printf("%d 1",n);
        }
        else
        {
            printf("%d %d",n,m);
        }


    }

    else
    {
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++)
            {
                min=mink(i,j,k);
                if(maxmin<min)
                {
                    maxmin=min;
                    maxx=i;
                    maxy=j;
                }

            }
        }
        printf("%d %d",maxx,maxy);
    }

    return 0;
}
