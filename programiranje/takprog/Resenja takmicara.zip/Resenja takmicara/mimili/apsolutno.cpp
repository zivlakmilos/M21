#include <iostream>
#include <stdio.h>
#include <cstdlib>
using namespace std;
int a[100000];
int b[100000];

long long s1=0;
int main()
{
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(int i=0;i<n;i++)
    {
        scanf("%d",&b[i]);
        for(int j=0;j<n;j++)
        {
            if(a[j]-b[i]>0)
            {
                s1=s1+a[j]-b[i];
            }
            else
            {
                s1=s1+b[i]-a[j];
            }
        }
    }
    printf("%lld",s1);

    return 0;
}
