#include <cstdio>
#include <cmath>
void rotiraj (int A[], int N)
{
	int i, pom;
	pom=A[N-1];
	for (i=N-2;i>=0;i++)
		A[i+1]=A[i];
	A[0]=pom;
}
int suma(int A[], int B[], int N)
{
	int s=0, i;
	for (i=0; i<N; i++)
		s+=abs(A[i]-B[i]);
	return s;
}
int main()
{
	int N, s=0, i;
	scanf_s("%d", &N);
	int A[100000], B[100000];
	for (int i=0; i<N; i++)
		scanf_s ("%d", &A[i]);
	for (int i=0; i<N; i++)
		scanf_s ("%d", &B[i]);
	for(i=0; i<N; i++)
	{
		s+=suma(A, B, N);
		rotiraj(A, N);
	}
	printf("%d", s);
	return 0;
}