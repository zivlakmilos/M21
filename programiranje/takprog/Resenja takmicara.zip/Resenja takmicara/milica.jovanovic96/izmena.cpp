#include <cstdio>
#include <cstring>
#include <cmath>
int main()
{
	char Q[500000];
	int i, r, s, a, b, N, sum, suma=0, sumaX=0, sumaY=0, br=0, smX, smY;
	scanf("%d %d %d", &N, &r, &s);
	scanf("%s", Q); 
	if(s==0)
	{
		for (i=0; i<N; i++)
		{
			if (Q[i]=='L')
				suma+=-1;
			else if (Q[i]=='R')
				suma+=1;
		}
		sum=suma;
		a=abs(sum);
		if (a<abs(r))
			while(a<abs(r))
			{
				a+=2;
				br++;
			}
		else if (a>abs(r))
			while(a>abs(r))
			{
				a-=2;
				br++;
			}
			else br=0;
		printf ("%d ", br);
		printf ("%d", abs(suma-r)/2);
	}
	else
	{
		for (i=0; i<N; i++)
		{
			if (Q[i]=='L')
				sumaX+=-1;
			else if (Q[i]=='R')
				sumaX+=1;
			else if (Q[i]=='D')
				sumaY+=-1;
			else if (Q[i]=='U')
				sumaY+=1;
		}
		smX=sumaX;
		smY=sumaY;
		a=abs(smX);
		b=abs(smY);
		if (a<abs(r))
			while(a<abs(r))
			{
				a+=2;
				br++;
			}
		if (a>abs(r))
			while(a>abs(r))
			{
				a-=2;
				br++;
			}
		if (b<abs(r))
			while(a<abs(r))
			{
				a+=2;
				br++;
			}
		if (b>abs(r))
			while(a>abs(r))
			{
				a-=2;
				br++;
			}
		printf ("%d ", br);
		printf ("%d", abs(sumaX-r)/2+abs(sumaY-s)/2);
	}
}