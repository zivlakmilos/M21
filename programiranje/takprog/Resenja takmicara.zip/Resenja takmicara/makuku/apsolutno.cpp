#include<cstdio>
#include<iostream>
using namespace std;
int i,j,A[1000002],B[1000002],n,x;
long long int res;
int main ()
{
    scanf("%d",&n);
    for (i=1;i<=n;i++)
        scanf("%d",&A[i]);
    for (i=1;i<=n;i++)
        scanf("%d",&B[i]);

    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++)
        {
            x=A[i]-B[j];
            if (x>0) res+=x;
             else res+=-x;
        }

    printf("%d",res);
    return 0;
}
