#include<cstdio>
#include<iostream>
using namespace std;
int  i,p,put,pomX,pomY,brPOTEZA,j,l,res,Xres,Yres,n,m,k,tragRED[1004],tragKOL[1004],brz[1004],maks,proslitragac;

int main ()
{
    scanf ("%d %d %d",&n,&m,&k);
    for (i=1;i<=k;i++)
       scanf("%d %d %d",&tragRED[i],&tragKOL[i],&brz[i]);
    maks=0;
proslitragac=1001;

    for(i=1;i<=n;i++)
        for (j=1;j<=m;j++)
          {
          // proslitragac=1001;
           for(l=1;l<=k;l++)
          {
          // if ((i==tragRED[l]) and (j==tragKOL[l])) {proslitragac=1001; }

           if(i-tragRED[l]>0) pomX=i-tragRED[l];
                else if(i-tragRED[l]<0)pomX=-i+tragRED[l];

              if(j-tragKOL[l]>0) pomY=j-tragKOL[l];
                else if(j-tragKOL[l]<0)pomY=-j+tragKOL[l];

                put=pomX+pomY;
                if (put%brz[l]!=0) brPOTEZA=put/brz[l]+1;
                 else brPOTEZA=put/brz[l];
                 if (brPOTEZA<proslitragac)
                    {proslitragac=brPOTEZA;
                     pomX=i;
                     pomY=j;

                    }



          }
       if  (proslitragac>maks) {maks=proslitragac; Xres=pomX; Yres=pomY;}
        }
    printf ("%d %d",Xres,Yres);
    return 0;
}
