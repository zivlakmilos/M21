#include <iostream>
#include <stdlib.h>

using namespace std;

int main()
{
    int n,m,k,x,y,v,i,j,distanca,skrivenost[1001][1001],top; // obavezno izmeni [1001][1001]
    cin >> n >> m >> k;
    cin >> x >> y >> v;
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=m;j++)
        {
            distanca=(abs(i-x)+abs(j-y));
            skrivenost[i][j]=distanca/v;
            if (distanca%v > 0) skrivenost[i][j]++;
        }
    }
    for (k=k;k>1;k--)
    {
        cin >> x >> y >> v;
        for (i=1;i<=n;i++)
        {
            for (j=1;j<=m;j++)
            {
                distanca=(abs(i-x)+abs(j-y));
                if (distanca%v == 0) distanca=distanca/v;
                else distanca=distanca/v+1;
                if (distanca < skrivenost[i][j])
                skrivenost[i][j]=distanca/v;
            }
        }
    }
    top=0;
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=m;j++)
        {
            if (skrivenost[i][j] > top)
            {
                x=i;
                y=j;
                top=skrivenost[i][j];
            }
        }
    }
    cout << x << ' ' << y;
    return 0;
}
