#include <iostream>
#include <stdlib.h>

using namespace std;

int main()
{
    char komanda[500001];
    int n,r,s,des,gor,a,b,i;
    cin >> n >> r >> s;
    cin >> komanda;;
    des=0;
    gor=0;
    a=500001;
    for (i=0;i<n;i++)
    {
        if (komanda[i]=='L') des--;
        else if (komanda[i]=='R') des++;
        else if (komanda[i]=='U') gor++;
        else if (komanda[i]=='D') gor--;
        if (abs(r)+abs(s) <= i+1 && (i+1)%2 == abs(r+s)%2)
        {
            b=(abs(r-des)+abs(s-gor))/2;
            if (b<a) a=b;
        }
    }
    b=(abs(r-des)+abs(s-gor))/2;
    cout << a << ' ' << b;
    return 0;
}
