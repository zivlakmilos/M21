#include <iostream>
#include <stdlib.h>

using namespace std;

int main()
{
    int a[100001],b[100001],n,i,j;
    long long sum;
    cin >> n;
    for (i=1;i<=n;i++)
    {
        cin >> a[i];
    }
    for (i=1;i<=n;i++)
    {
        cin >> b[i];
    }
    sum=0;
    for (j=1;j<=n;j++)
    {
        for (i=1;i<=n;i++)
        {
            sum+=abs(a[i]-b[j]);
        }
    }
    cout << sum;
    return 0;
}
