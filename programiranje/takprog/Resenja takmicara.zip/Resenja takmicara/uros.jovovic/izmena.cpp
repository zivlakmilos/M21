#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{int n,x,y;
cin>>n>>x>>y;
string a;

        cin>>a;
        
        cout<<3<<" "<<6;
    system("PAUSE");
    return EXIT_SUCCESS;
}
