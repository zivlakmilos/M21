#include <cstdlib>
#include <iostream>

using namespace std;
int poteza(int xp,int yp,int xs,int ys,int bk){
    int xd=abs(xp-xs);
    
    int yd=abs(yp-ys);
  
    int r;
    if((xd+yd)%bk==0){r=(xd+yd)/bk;
                       return r;
                      }else{r=(xd+yd)/bk+1;return r;}
    
    
    }
int main(int argc, char *argv[])
{int n,m,k;
cin>>n>>m>>k;
int x[k],y[k],v[k];
for(int i=0;i<k;i++){
        cin>>y[i]>>x[i]>>v[i];
        }
        int max=poteza(1,1,x[0],y[0],v[0]),xmax,ymax;
        for(int i=1;i<=n;i++){
               for(int j=1;j<=m;j++){int mu=poteza(i,j,x[0],y[0],v[0]);
                for(int br=0;br<k;br++){
                        if(poteza(j,i,x[br],y[br],v[br])<mu){mu=poteza(j,i,x[br],y[br],v[br]);}
                        }
                if(mu>max){max=mu;xmax=j;ymax=i;}
                
                } 
                }
        
        
                cout<<ymax<<" "<<xmax/*<<" "<<max*/;
    system("PAUSE");
    return EXIT_SUCCESS;
}
 /* int potez=poteza(5,2,x[0],y[0],v[0]);
        for(int br=0;br<k;br++){int t=poteza(5,2,x[br],y[br],v[br]);
                 if(potez<=t){potez =t;}
                  
                  }
                  if(potez>mp){mp=potez;mx=5;my=2;}*/
