#include <cstdlib>
#include <iostream>
#include <math.h>

using namespace std;

int main(int argc, char *argv[])
{long long n;
cin>>n;

long long a[n],b[n];
for(int i=0;i<n;i++){
        cin>>a[i];
        }
for(int i=0;i<n;i++){
        cin>>b[i];
        }
        long long sum=0;
      
for(int i=0;i<n;i++){
        
for(int j=0;j<n;j++){
        sum+=abs(a[i]-b[j]);
        }
        }
        cout<<sum;
    system("PAUSE");
    return EXIT_SUCCESS;
}
