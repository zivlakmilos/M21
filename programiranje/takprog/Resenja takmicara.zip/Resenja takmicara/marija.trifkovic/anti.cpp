#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;

int main(int argc, char *argv[])
{   long long n,m,k,min,p,p1,p2,max;
    scanf("%lld%lld%lld",&n,&m,&k);
    long long x[k],y[k],v[k];
    for(int i=0;i<k;i++)
    {scanf("%lld%lld%lld",&x[i],&y[i],&v[i]);
    x[i]--;
    y[i]--;}
    for(int i=0;i<n;i++)
    {for(int j=0;j<m;j++)
      {for(int t=0;t<k;t++)
        {p=(abs(i-x[t])+abs(j-y[t]))/v[t];
        if((abs(i-x[t])+abs(j-y[t]))%v[t]!=0)
          {p++;}
          if(t==0)
            {min=p;}
          else if(min>p)
          {min=p;}
        }
        if(j==0 && i==0)
        {max=min;p1=i;p2=j;}
        else if(max<min)
        {max=min;p1=i;p2=j;}
      }
      }
    printf("%lld %lld\n",p1+1,p2+1);
    return 0;
}
