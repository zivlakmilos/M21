#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;

int main(int argc, char *argv[])
{   long long n,s=0;
    scanf("%lld",&n);
    long long a[n],b[n];
    for(int j=0;j<n;j++)
        {scanf("%lld",&a[j]);}
    for(int i=0;i<n;i++)
    {scanf("%lld",&b[i]);
    for(int j=0;j<n;j++)
      {s+=abs(b[i]-a[j]);}
    }
    printf("%lld\n",s);
    return 0;
}
