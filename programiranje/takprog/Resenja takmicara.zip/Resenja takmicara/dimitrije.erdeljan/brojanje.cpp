#include <iostream>
#include <cstdio>
#include <stack>
#include <algorithm>

//using namespace std;

const int N = 1000005;
const long long MOD = 1000000007;
int a[N], left[N], right[N];
long long sol[N];

struct stick { int pos, val; } ;
stick _s(int p, int v) { stick s; s.pos = p; s.val = v; return s; } // C++11 @ grader?

struct query { int pos, id; } ;
query _q(int p, int i) { query q; q.pos = p; q.id = i; return q; }
query qs[N];
bool qlt_p(query a, query b) { return a.pos < b.pos; }
bool qlt_i(query a, query b) { return a.id < b.id; }

struct particle { int x; long long cnt; } ;
particle tmp[N];
bool operator<(particle a, particle b) { return a.x < b.x; }

int main()
{
    //freopen("test.in", "r", stdin);

    int n;
    scanf("%i", &n);
    for(int i = 0; i < n; i++) scanf("%i", &a[i]);

    std::stack<stick> s;
    s.push(_s(-1, 1 << 30));
    for(int i = 0; i < n; i++)
    {
        while(s.top().val <= a[i]) s.pop();
        left[i] = s.top().pos;
        s.push(_s(i, a[i]));
    }
    while(!s.empty()) s.pop();

    s.push(_s(n, 1 << 30));
    for(int i = n - 1; i >= 0; i--)
    {
        while(s.top().val < a[i]) s.pop();
        right[i] = s.top().pos;
        s.push(_s(i, a[i]));
    }

    int q;
    scanf("%i", &q);
    for(int i = 0; i < q; i++)
    {
        scanf("%i", &qs[i].pos);
        qs[i].id = i;
    }

    for(int i = 0; i < n; i++)
    {
        tmp[i].x = a[i];
        tmp[i].cnt = ((long long)(right[i] - i) * (long long)(i - left[i])) % MOD;
    }

    std::sort(tmp, tmp + n);
    std::sort(qs, qs + q, qlt_p);
    int i = 0;
    for(int j = 0; j < q; j++)
    {
        if(j && qs[j].pos == qs[j - 1].pos)
            sol[qs[j].id] = sol[qs[j - 1].id];
        else
        {
            sol[qs[j].id] = 0;
            while(i < n && tmp[i].x < qs[j].pos) i++;
            for(; i < n && tmp[i].x == qs[j].pos; i++)
            {
                sol[qs[j].id] += tmp[i].cnt;
                if(sol[qs[j].id] >= MOD) sol[qs[j].id] -= MOD;
            }
        }
    }

    for(int i = 0; i < q; i++) printf("%i\n", (int)sol[i]);

    return 0;
}
