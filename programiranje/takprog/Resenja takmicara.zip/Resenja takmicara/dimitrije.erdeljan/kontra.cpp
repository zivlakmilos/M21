#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>

using namespace std;

const int N = 1005;
bool block[N][N];
int n, m;

struct hunter { int i, j, vel; } ;
hunter h[N * N];

bool operator<(hunter a, hunter b)
{
    return a.vel > b.vel;
}

struct time { int sec, bit, vel; } ;
time _t(int s, int b, int v) { time t; t.sec = s; t.bit = b; t.vel = v; return t; }
bool operator<(time a, time b)
{
    return a.sec == b.sec ? (a.bit * b.vel) < (b.bit * a.vel) : a.sec < b.sec;
}
time operator+(time t, int a)
{
    t.bit += a;
    if(t.bit >= t.vel) { t.bit -= t.vel; t.sec++; }
    return t;
}

queue<int> q_i, q_j;
time dist[N][N];

const int DI[] = { -1, 0, 1, 0 } ;
const int DJ[] = { 0, 1, 0, -1 } ;

void bfs()
{
  //  printf("%i\n", q_i.size());
    while(!q_i.empty())
    {
        int i = q_i.front(); q_i.pop();
        int j = q_j.front(); q_j.pop();

      //  printf("%i %i\n", i, j);

        for(int d = 0; d < 4; d++)
        {
            int ii = i + DI[d], jj = j + DJ[d];
            if(ii < 0 || jj < 0 || ii >= n || jj >= m) continue;
            if(!block[ii][jj] && dist[i][j] + 1 < dist[ii][jj])
            {
                dist[ii][jj] = dist[i][j] + 1;
                q_i.push(ii); q_j.push(jj);
            }
        }
    }
}

    int n_h;

void solve_sub3()
{
    int ri, rj, res = -1;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
        {
            int curr = 1 << 30;
            for(int k = 0; k < n_h && curr > res; k++)
            {
                int t = abs(i - h[k].i) + abs(j - h[k].j);
                curr = min(curr, t / h[k].vel + (t % h[k].vel > 0));
            }
            if(curr > res) { res = curr; ri = i; rj = j; }
        }
    printf("%i %i\n", ri + 1, rj + 1);
}

void print_any_empty()
{
    for(int i = 0; i < n_h; i++)
        block[h[i].i][h[i].j] = true;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            if(!block[i][j]) { printf("%i %i\n", i + 1, j + 1); return; }
}

void print_any()
{
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            if(!block[i][j]) { printf("%i %i\n", i + 1, j + 1); return; }
}

int main()
{
    //freopen("test.in", "r", stdin);
    scanf("%i %i", &n, &m);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
        {
            char c;
            scanf(" %c", &c);
            block[i][j] = c == '1';
        }

    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            dist[i][j] = _t(1 << 30, 0, 1);

    scanf("%i", &n_h);
    for(int i = 0; i < n_h; i++)
    {
        scanf("%i %i %i", &h[i].i, &h[i].j, &h[i].vel);
        h[i].i--; h[i].j--;
    }
    h[n_h].vel = 1 << 30;

        int SUB3cnt = 0;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            SUB3cnt += block[i][j];
    if(!SUB3cnt && n_h <= 1001) { solve_sub3(); return 0; }

    if(SUB3cnt + n_h == n * m) { print_any(); return 0; }

    sort(h, h + n_h + 1);
    int nbfs = 0;
    for(int i = 1; i <= n_h; i++)
    {
        if(h[i].vel != h[i - 1].vel)
        {
            bfs(); nbfs++;
            if(nbfs < 10) // cit za kada je neki jako brz, mozda donese 5pts
            {
                bool x = true;
                for(int ii = 0; ii < n; ii++)
                    for(int jj = 0; jj < m; jj++)
                        if(!block[ii][jj] && (dist[ii][jj].sec > 1 || (dist[ii][jj].sec == 1 && dist[ii][jj].bit))) x = false;
                if(x) { print_any_empty(); return 0; }
            }
        }
        dist[h[i].i][h[i].j] = _t(0, 0, h[i].vel);
        q_i.push(h[i].i); q_j.push(h[i].j);
    }
    bfs();

   //for(int i = 0; i < n; i++)
     //   for(int j = 0; j < m; j++)
        //    printf("%i%c", block[i][j] ? 9 : dist[i][j].sec + (dist[i][j].bit > 0), j == m - 1 ? '\n' : ' ');

    int r_i = 0, r_j = 0;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < m; j++)
            if(!block[i][j] && dist[r_i][r_j] < dist[i][j])
                { r_i = i; r_j = j; }

    printf("%i %i\n", r_i + 1, r_j + 1);

    return 0;
}

