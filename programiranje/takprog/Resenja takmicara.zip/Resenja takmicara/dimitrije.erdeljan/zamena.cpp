#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

const int N = 100005, L = 9;
char num[N][L];
int n;

int hash(char s[])
{
    int h = 0;
    for(int i = 0; i < L; i++)
        h = 10 * h + s[i] - '0';
    return h;
}

struct jumper { int pos, val; } ;
bool operator<(jumper a, jumper b)
{
    return a.val == b.val ? a.pos < b.pos :
                            a.val < b.val;
}
jumper jmp[N];

int binary(jumper x)
{
    int left = 0, right = n - 1;
    while(left < right)
    {
        int m = (left + right) / 2;
        if(jmp[m] < x) left = m + 1;
        else right = m;
    }
    return x < jmp[left] ? left - 1 : left;
}

int d[N];

const int POW[] = { 1,
                    10,
                    100,
                    1000,
                    10000,
                    100000,
                    1000000,
                    10000000,
                    100000000,
                    1000000000 } ; // previse za svaki slucaj

int main()
{
 //   freopen("test.in", "r", stdin);

    scanf("%i", &n);
    for(int i = 0; i < n; i++)
        //for(int j = 0; j < 6; j++) num[i][j] = '8';
        scanf(" %s", &num[i]);

    for(int i = 0; i < n; i++)
    {
        jmp[i].pos = i;
        jmp[i].val = hash(num[i]);
    }
    sort(jmp, jmp + n);

    for(int i = 0; i < n; i++)
    {
        int h = hash(num[i]);
        for(int j = 0; num[i][j]; j++)
        {
            int o = num[i][j];
            for(num[i][j] = '0'; num[i][j] <= '9'; num[i][j]++)
            {
                int hh = h + POW[L - 1 - j] * (num[i][j] - o);

                jumper t; t.pos = i - 1; t.val = hh;
                int k = binary(t);
                //printf("%i", k);
                if(k >= 0 && jmp[k].val == hh) d[i] = max(d[i], d[jmp[k].pos] + (o < num[i][j] ? num[i][j] - o : (o - num[i][j])));

                /*char tt=  num[i][j];
                num[i][j] = o;
                if(jmp[k].val == hh) printf("%s -> %s   (%i-%i)\n", num[i], num[jmp[k].pos], i, jmp[k].pos);
                num[i][j] = tt;*/
            }
            num[i][j] = o;
        }
    }

    int res = 0;
    for(int i = 0; i < n; i++)
        res = max(res, d[i]);
       // printf("\n\n\n");
    printf("%i\n", res);

    return 0;
}
