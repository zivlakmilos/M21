#include<stdio.h>
#include<stdlib.h>
int r(long long int a, long long int b) {
    int rc,k;
    rc=0;
    while(a>0&&b>0) {
     if(a%10!=b%10) {
      rc++;             
     }
     a=a/10;
     b=b/10;
    }
    return rc; 
}
int r1(long long int a, long long int b) {
    int rc,k;
    rc=0;
    while(a>0&&b>0) {
     if(a%10!=b%10) {
      rc=abs(a%10-b%10);             
      break;
     }
     a=a/10;
     b=b/10;
    }
    return rc; 
}

int main() {
    int n,i,j,s,maxi,maxuk,maxukj,maxuki,maxj;
    long long int a[100001],k,max,z,uk,izabrani,bod,sledeci;
    scanf("%i",&n);
    maxuk=0; maxuki=0; maxukj=0;maxi=0; bod=0;
    for(i=1;i<=n;i++) {
     scanf("%lli",&a[i]);             
    }
    for(i=1;i<=n;i++) {
      max=0;maxj=0;
      for(j=1;j<=n;j++) {
       if(r(a[i],a[j])==1) {
         k=r1(a[i],a[j]);
         if(k>max) {max=k; maxi=i;maxj=j;}
       }
      }
      if(max>maxuk) {maxuk=max;maxuki=maxi;maxukj=maxj;maxi=0;bod=bod+maxuk;}                  
      }
    printf("%lld",bod);
    return 0;
}
