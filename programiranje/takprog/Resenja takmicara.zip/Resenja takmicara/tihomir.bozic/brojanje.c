#include <stdio.h>
#include <math.h>
#include <stdlib.h>
int main() {
     long long int n,a[100001],q,k[100001],i,max,min,j,l,z,g,f,smeta,svijednaki,h,uz;
     int sadrzano;
     scanf("%lld",&n);
     for(i=1;i<=n;i++) {
       scanf("%lld",&a[i]);
     }
     scanf("%lld",&q);
     for(i=1;i<=q;i++) {
       scanf("%lld",&k[i]);
     }
     z=0;
     sadrzano=0;
     max=a[1];
     min=a[1];
     for(i=2;i<=n;i++) {
       if(a[i]>max) max=a[i];
       if(a[i]<min) min=a[i];
     }
     for(j=1;j<=q;j++) {
       
       if((k[j]>max)||(k[j]<min)) {
        printf("0\n");
        continue;
       }
       
       
       svijednaki=1;
       for(i=1;i<=n;i++) {
         if(a[i]==k[j]) {
           sadrzano++;
           break;
         }
       }
       for(i=1;i<=n;i++) {  
         if(a[i]!=k[j]) {svijednaki=0; break;}
       }
       if(svijednaki==1) {z=pow(2,n)-1; z=z%1000000007; printf("%lld\n",z);continue;}
       
       if(sadrzano==0) {
        printf("0\n");
        continue;
       }
       
       if(sadrzano>=1){
       for(i=1;i<=n;i++) {
           if(a[i]==k[j]) {
             l=1; 
             
             for(g=1;g<=n-i;g++) {
              if(a[i+g]>a[i]) {break;}
              else {
                l++; 
               
              }
             }
             z=z+l;
             for(g=1;g<i;g++) {
               if(a[i-g]>a[i]||a[i-g]==k[j]) {break;}
               else {
                 z=z+l;
                 
               }
             }
           }  
         }
       }
       
       z=z%1000000007; printf("%lld\n",z);
       sadrzano=0;
       z=0;
     }
    return 0;
}
