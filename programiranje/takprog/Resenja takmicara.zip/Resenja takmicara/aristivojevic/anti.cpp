#include <stdio.h>
#include <stdlib.h>
int lok [1000][2];
int v [1000];
int tabela[1000][1000]={0};
int absolute (int a)
{
    if (a>=0)
        return a;
    return (-1*a);
}
int main()
{
    int n,m,k;
    scanf ("%d%d%d",&m,&n,&k);
    for (int i=0;i<k;i++)
        {
            scanf ("%d%d%d",&lok[i][1],&lok[i][0],&v[i]);
            lok[i][1]--;
            lok[i][0]--;
        }
    int max=0;
    int maxx;
    int maxy;
    for (int i=0;i<k;i++)
    {
        for (int j=0;j<m;j++)
        {
            for (int l=0;l<n;l++)
            {
                int dis=absolute(lok[i][0]-j)+absolute(lok[i][1]-l);
                if (dis%v[i]!=0 && dis/v[i]<tabela[j][l]-1)
                    {
                        tabela[j][l]=(dis/v[i])+1;
                        if (tabela[j][l]>max)
                        {   maxx=j;
                            maxy=l;
                            max=tabela[j][l];
                        }
                    }
                else if (dis%v[i]==0 && dis/v[i]<tabela[j][l])
                         {
                             tabela[j][l]=dis/v[i];
                             if (tabela[j][l]>max)
                             {
                                maxx=j;
                                maxy=l;
                                max=tabela[j][l];

                             }
                         }


            }
        }
    }
    printf ("%d %d" ,maxy,maxx);
    return 0;
}
