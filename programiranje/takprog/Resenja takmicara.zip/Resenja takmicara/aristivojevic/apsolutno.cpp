#include <stdio.h>
#include <stdlib.h>

int a[100000];
int b[100000];
int c[200000][2];
//int a1[100000];
//int b1[100000];
int n;
/*
bool vece (int a,int b)
{
    if (a>=b)
        return true;
    return false;
}
*/
void swap (int *a, int *b)
{
    int t=*a;
    *a=*b;
    *b=t;
}
void quicksort (int left_bound, int right_bound)
{
    //printf ("begin\n");
    if (left_bound==right_bound-1)
    {
        if (c[left_bound][0]<c[right_bound][0])
        {
            swap(&c[left_bound][0],&c[right_bound][0]);
            swap(&c[left_bound][1],&c[right_bound][1]);
        }
        return;
    }
    if (left_bound==right_bound)
        return;
    int pivot=c[left_bound][0];
    int left_place=left_bound+1;
    int right_place=right_bound;
    while (left_place<right_place)
    {
        if (c[left_place][0]>=pivot)
            {
                ++left_place;
            //    printf ("c1\n");
            }
        else if (c[right_place][0]<pivot)
            {
                --right_place;
          //      printf ("c2\n");
            }
        else
        {
            swap (&c[left_place][0],&c[right_place][0]);
            swap (&c[left_place][1],&c[right_place][1]);
        //    printf ("swap\n");
        }

    }
    if (c[left_place][0]>=pivot)
    {
        swap (&c[left_bound][0],&c[left_place][0]);
        swap (&c[left_bound][1],&c[left_place][1]);
        --left_place;
      //  printf ("qs pt1\n");
    }
    else
    {
        --left_place;
        swap (&c[left_place][0],&c[left_bound][0]);
        swap (&c[left_place][1],&c[left_bound][1]);
    //    printf ("qs pt2\n");
    }
  //  printf("rek\n");
    if (left_place>=left_bound)
        {
            //printf ("v1 lp=%d lb=%d\n",left_place,left_bound);
            //if (left_place==211 && left_bound==203)
              //  for (int i=203;i<=211;i++)
                //    printf ("c[%d][0]=%d\n",i,c[i][0]);
            quicksort(left_bound,left_place);
        }
    if (right_place<=right_bound)
        {
      //      printf ("v2\n");
            quicksort(right_place,right_bound);
        }
}
int main()
{
    int n;
    unsigned long long int S=0;
    unsigned long long int S1=0;
    scanf ("%d",&n);
    for (int i=0;i<n;i++)
    {
        //a[i]=rand();
        scanf ("%d",&a[i]);
        S+=(n*a[i]);
        S1+=2*a[i];
        c[i][0] = a[i];
        c[i][1]=i;
    }
    //printf ("S1=%llu\n",S1);
    for (int i=0;i<n;i++)
    {
        scanf ("%d",&b[i]);
        //b[i]=rand();
        S+=(n*b[i]);
        c[n+i][0]=b[i];
        c[n+i][1]=n+i;
    }
    //for (int i=0;i<2*n;i++)
    //{
        //printf ("%d element %d\n",c[i][0],c[i][1]);
   // }
    //printf ("done input\n");
    int m;
    for (int i=0;i<2*n-1;i++)
    {
          m=(rand ()%(2*n-1-i))+i;
          swap (&c[i][0],&c[m][0]);
          swap (&c[i][1],&c[m][1]);
    }

    quicksort(0,2*n-1);
    //printf ("i'm ok \n");
    for (int i=0;i<2*n;i++)
    {
        //printf ("%d pripada %d\n",c[i][0],c[i][1]);
    }
   // printf ("S=%llu S1=%llu\n",S,S1);
   // printf ("S1=%llu\n",S1);
    int bb=0;//broj koliko puta se B brojevi
    for (int i=0;i<2*n;i++)
    {
        if (c[i][1]<n)
        {
            bb++;
            S1=S1-(2*c[i][0]);
            //printf ("i=%d bb=%d S1=%llu\n",i,bb,S1);
        }
        else
        {

            S=S-S1-(2*bb*c[i][0]);
            //printf ("i=%d bb=%d S1=%llu\n",i,bb,S1);
        }
    }

    printf ("%lld",S);
    return 0;
}
