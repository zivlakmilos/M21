//Filip Vesovic
//Zadatak: Zamena
#include <cstdio>
#include <map>
using namespace std;
map<int,int> mapa;//mapa koja oznacava maksimalno dosadasnje resenje za X
map<int,bool> existt;//mapa koja mi govori da li broj postoji ili ne (koristim je da bih mogao da "zapocnem" dinamiku)
int cifre[11];//skladistim cifre maksimalno 6
int abs(int x)
{
    if(x<0)return -x;
    return x;
}
//vracam iz niza cifara u broj
int getnum(int cur)
{
    int ret=0,pw=1;
    for(int i=0; i<cur; i++)
    {
        ret+=cifre[i]*pw;
        pw*=10;
    }
    return ret;
}
//corner case kad je x=0 handlovan
int solve(int x)
{
    int ret=0;
    int cur=0;
    //broj predstavljam "odpozadi"
    if(x==0)
        cifre[cur++]=0;
    else
    {
        while(x>0)
        {
            cifre[cur++]=x%10;
            x/=10;
        }
    }
    for(int t=0; t<cur; t++)
    {
        int lastdig=cifre[t];//pamtim cifru koja je bila
        for(int i=0; i<=9; i++)
        {
            cifre[t]=i;//postavljam cifru
            int numb=getnum(cur);
            // printf("Probam za %d\n",numb);
            if(existt[numb])//ukoliko je postojao
            {
                int points=mapa[numb]+abs(lastdig-i);//racunam nove poene
                ret=max(ret,points);//updetujem max
            }
        }
        cifre[t]=lastdig;//vracam prethodnu cifru
    }
    return ret;
}
int main()
{
    int sol=0;//ne moze da predje int
    int n;
    scanf("%d",&n);
    for(int i=0; i<n; i++)
    {
        int x;
        scanf("%d",&x);
        mapa[x]=solve(x);//updejtujem resenje mape
        existt[x]=true;//stavljam da x postoji
        //printf("MAPA %d je %d\n",x,mapa[x]);
        sol=max(sol,mapa[x]);//updejtujem sol
    }
    printf("%d\n",sol);
    return 0;
}
