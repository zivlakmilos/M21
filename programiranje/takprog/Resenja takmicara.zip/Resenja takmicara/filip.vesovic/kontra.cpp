// Filip Vesovic
//Zadatak: kontra-zmurka
#include <cstdio>
#include <queue>
#include <algorithm>
#include <cstring>
using namespace std;

char s[1010][1010];
pair<int,pair<int,int> > kids[1000100];
queue<pair<int,int> > q;
queue<int> d;
int n,m;
int dx[]={1,0,-1,0};
int dy[]={0,1,0,-1};
int mind[1010][1010];
int minv[1010][1010];
bool can(int x,int y,int d,int v)
{
    if(x>=0&&x<n&&y>=0&&y<m&&s[x][y]=='0')
    {
        int dist=mind[x][y];
        int vv=minv[x][y];
      //  printf("%d/%d < %d/%d ?\n",d/v,dist/vv);
        int vred1=d/v+((d%v>0)?1:0);
        int vred2=dist/vv+((dist%vv>0)?1:0);
        if(vred1<vred2)
            return true;
        if(vred1==vred2&&d%v<dist%vv)
            return true;
        return false;
    }
    return false;
}
void BFS(int v,int sx,int sy)
{
   // printf("BFS: %d %d %d\n",v,sx,sy);
    q.push(make_pair(sx,sy));
    d.push(0);
    while(!q.empty())
    {
        pair<int,int> cords=q.front();
        int x=cords.first,y=cords.second;
     //   printf("POSETIO %d %d\n",x,y);
        int curd=d.front();
        q.pop();d.pop();

        mind[x][y]=curd;
        minv[x][y]=v;

        for(int i=0;i<4;i++)
        {
            int nx=x+dx[i];
            int ny=y+dy[i];
            int nd=curd+1;
            if(can(nx,ny,nd,v))
            {
                q.push(make_pair(nx,ny));
                d.push(nd);
            }
        }
    }
}
int main()
{

    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
        scanf("%s",s[i]);
    int k;
    scanf("%d",&k);
    for(int i=0;i<k;i++)
    {
        int x,y,v;
        scanf("%d%d%d",&x,&y,&v);
        x--;y--;
        kids[i]=make_pair(v,make_pair(x,y));
    }
    sort(kids,kids+k);
    reverse(kids,kids+k);
      for(int i=0;i<n;i++)
        for(int j=0;j<m;j++)
            minv[i][j]=1,mind[i][j]=1000100;

    for(int i=0;i<k;i++)
    {
        int kidsx=kids[i].second.first;
        int kidsy=kids[i].second.second;
        int kidsv=kids[i].first;
        BFS(kidsv,kidsx,kidsy);
    }
    int mink=0;
    int solx,soly;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            //if(s[i][j]=='1')printf("# ");
            if(s[i][j]=='1')continue;
            int vrdns=mind[i][j]/minv[i][j]+((mind[i][j]%minv[i][j]>0)?1:0);
            if(vrdns>mink)
            {
                mink=vrdns;
                solx=i+1;
                soly=j+1;
            }
           // printf("(%d,%d) ",mind[i][j],minv[i][j]);
      //  printf("%d ",vrdns);
        }
       // printf("\n");
    }
   // printf("%d\n",mink);
    printf("%d %d\n",solx,soly);
    return 0;
}
