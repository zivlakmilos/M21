//Filip Vesovic
//Zadatak Brojanje
#include <cstdio>
#include <iostream>
#include <map>
#include <vector>
#define MAXN 1000100
#define MOD 1000000007
#define MID (left+right)/2
#define INF 1000000100
using namespace std;
int a[MAXN];//niz indeksiran od 1
int ST[MAXN*4],ST2[MAXN*4];//segmetna stabla ST cuva max ali levi a ovo drugo desni
int next[MAXN];//pokazuje na prvog desno veceg od njega
int last[MAXN];//prvog levog veceg od njega
int n;
map<int,int> sols;//cuvam resenja
map<int,int> solexist;//da li postoji
map<int,vector<int> > occurs;//cuvam ponavljanja
map<int,bool> existt;//da li je broj u nizu
void InitTree(int idx,int left,int right)//iniciram obadva segmenta stabla
{
    if(left==right)
    {
        ST[idx]=left;
        ST2[idx]=left;
        return;
    }
    InitTree(2*idx,left,MID);
    InitTree(2*idx+1,MID+1,right);
    int idx1=ST[2*idx],idx2=ST[2*idx+1];
    if(a[idx1]==a[idx2])
    {
        ST[idx]=max(idx1,idx2);
    }
    else if(a[idx1]>a[idx2])
        ST[idx]=idx1;
    else
        ST[idx]=idx2;

    idx1=ST2[2*idx],idx2=ST2[2*idx+1];
    if(a[idx1]==a[idx2])
    {
        ST2[idx]=min(idx1,idx2);
    }
    else if(a[idx1]>a[idx2])
        ST2[idx]=idx1;
    else
        ST2[idx]=idx2;
}
int Query(int idx,int left,int right,int l,int r)
{
    if(l<=left&&right<=r)
        return ST[idx];
    int curidx=-1;
    if(l<=MID)
    {
        int index=Query(2*idx,left,MID,l,r);
        if(curidx==-1)curidx=index;
        else if(a[index]==a[curidx])curidx=max(curidx,index);
        else if(a[index]>a[curidx])curidx=index;
    }
    if(r>MID)
    {
        int index=Query(2*idx+1,MID+1,right,l,r);
        if(curidx==-1)curidx=index;
        else if(a[index]==a[curidx])curidx=max(curidx,index);
        else if(a[index]>a[curidx])curidx=index;
    }
    return curidx;
}
int Query2(int idx,int left,int right,int l,int r)
{
    if(l<=left&&right<=r)
        return ST2[idx];
    int curidx=INF;
    if(l<=MID)
    {
        int index=Query2(2*idx,left,MID,l,r);
        if(curidx==INF)curidx=index;
        else if(a[index]==a[curidx])curidx=min(curidx,index);
        else if(a[index]>a[curidx])curidx=index;
    }
    if(r>MID)
    {
        int index=Query2(2*idx+1,MID+1,right,l,r);
        if(curidx==INF)curidx=index;
        else if(a[index]==a[curidx])curidx=min(curidx,index);
        else if(a[index]>a[curidx])curidx=index;
    }
    return curidx;
}
int initNext(int l,int r,int nextmax)//za svakof trazi prvi veci sa desne strane
{
    int maxidx=Query2(1,1,n,l,r);
   // printf("MAX: %d\n",maxidx);
    next[maxidx]=nextmax;
    if(l<=maxidx-1)initNext(l,maxidx-1,maxidx);
    if(maxidx+1<=r)initNext(maxidx+1,r,nextmax);
}
int initLast(int l,int r,int lastmax)//za svakog trazi prvi veci sa leve strane
{
    int maxidx=Query(1,1,n,l,r);
    if(l<=maxidx-1)
    {
        int beforelastidx=Query(1,1,n,l,maxidx-1);
        if(a[beforelastidx]==a[maxidx])last[maxidx]=beforelastidx;
        else last[maxidx]=lastmax;
    }
    else last[maxidx]=lastmax;
    if(l<=maxidx-1)initLast(l,maxidx-1,lastmax);
    if(maxidx+1<=r)initLast(maxidx+1,r,maxidx);
}

int calc(int x)//izracunava ukoliko vec nismo zapamtili resenje
{
    long long ret=0;
    int max=occurs[x].size();
    for(int i=0;i<max;i++)
    {
        int curx=occurs[x][i];
        int leftt=curx-last[curx];
        int rightt=next[curx]-curx;
        long long tmp=(long long)leftt*rightt;
        ret+=tmp;
      //  printf("CALC: %d za poz %d ukupno %d\n",tmp,curx,ret);
        if(ret>=MOD)ret%=MOD;
    }
    sols[x]=ret%MOD;
    solexist[x]=true;
    return ret%MOD;
}
int main()
{
    scanf("%d",&n);
    for(int i=1; i<=n; i++)
        scanf("%d",&a[i]);

    for(int i=1;i<=n;i++)
    {
        existt[a[i]]=true;
        occurs[a[i]].push_back(i);
    }
    InitTree(1,1,n);

    /*while(1)
    {
        int l,r;
        scanf("%d%d",&l,&r);
        printf("MAX je %d na loc %d\n",a[Query(1,1,n,l,r)],Query(1,1,n,l,r));
    }*/

    a[n+1]=a[0]=1000000100;
    initNext(1,n,n+1);
    initLast(1,n,0);

    /*
    for(int i=1; i<=n; i++)printf("%d ",next[i]);
    printf("\n");
    for(int i=1; i<=n; i++)printf("%d ",last[i]);
    printf("\n");
    */
    int q;
    scanf("%d",&q);
    while(q--)
    {
        int x;
        scanf("%d",&x);
        if(!existt[x])
        {
            printf("0\n");
            continue;
        }
        if(solexist[x])printf("%d\n",sols[x]);
        else printf("%d\n",calc(x));
    }
    return 0;
}
