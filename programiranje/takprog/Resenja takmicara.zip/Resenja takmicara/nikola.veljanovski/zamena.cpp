#include <stdio.h>
#include <cstring>
#include <cstdlib>
#include <iostream>

char niz[100005][9];
bool pocni[100005];
int n, max = 0, duzina, razlika, plus;

void resi(int mesto, char s[9], char zbir)
{
    //printf("%d %s %d\n", mesto, s, zbir);
    
    if(mesto >= n)
    {
        if(zbir > max)
            max = zbir;
    }
    else
    {
        razlika = 0;
        for(int i = 0; i < duzina && razlika < 2; i++)
        {
            if(niz[mesto][i] != s[i])
            {
                plus = niz[mesto][i] - s[i];
                if(plus < 0)
                    plus = 0 - plus;
                razlika++;
            }
        }
    
        if(razlika == 1)
        {
            pocni[mesto] = false;
            resi(mesto+1, niz[mesto], zbir+plus);
        }
        resi(mesto+1, s, zbir);
    }
}

int main()
{
    scanf("%d", &n);
    
    for(int i = 0; i < n; i++)
    {
        pocni[i] = true;
        scanf("%s", niz[i]);
        //if(niz[i][0] == '0')
        //{
        //    niz[i][1] = niz[i][2] = niz[i][3] = niz[i][4] = niz[i][5] = niz[i][6] = niz[i][7] = '0';
        //}
    }
    
    duzina = strlen(niz[0]);
    
    for(int i = 0; i < n-1; i++)
    {
        if(pocni[i])
            resi(i+1, niz[i], 0);
    }
    
    printf("%d", max);
    
    //system("PAUSE");
    //return EXIT_SUCCESS;
    
    return 0;
}
