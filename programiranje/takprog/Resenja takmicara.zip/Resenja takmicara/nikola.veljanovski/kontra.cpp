#include <stdio.h>
#include <cstdlib>
#include <iostream>

char moze[1005][1005];
int poteza[1005][1005], brzina[1005][1005];
int n, m, q, max=-1, maxA=-1, maxB=-1;
int ima = 0;

void resi(int a, int b, int v, int pot, int tr)
{
    //printf("%d %d %d %d %d\n", a, b, v, pot, tr);
    
    if(n * m - ima + 2 < (pot - 1) * v + tr)
    { }
    else
    {
        if(tr == v)
        {
            tr = 0;
            pot++;
        }
        if(pot < poteza[a][b] || poteza[a][b] == -1)
        {
            poteza[a][b] = pot;
            brzina[a][b] = v;
        }
    
        if(a < n && (poteza[a+1][b] > pot || brzina[a+1][b] < v || poteza[a+1][b] == -1) && moze[a+1][b] == '0')
            resi(a+1, b, v, pot, tr+1);
        
        if(a > 1 && (poteza[a-1][b] > pot || brzina[a-1][b] < v || poteza[a-1][b] == -1) && moze[a-1][b] == '0')
            resi(a-1, b, v, pot, tr+1);
        
        if(b < m && (poteza[a][b+1] > pot || brzina[a][b+1] < v || poteza[a][b+1] == -1) && moze[a][b+1] == '0')
            resi(a, b+1, v, pot, tr+1);
        
        if(b > 1 && (poteza[a][b-1] > pot || brzina[a][b-1] < v || poteza[a][b-1] == -1) && moze[a][b-1] == '0')
            resi(a, b-1, v, pot, tr+1);
    }
}

void resiNEMA(int a, int b, int v)
{
    for(int i = 1; i <= n; i++)
    {
        for(int k = 1; k <= m; k++)
        {
            int x, z;
            x = i - a;
            z = k - b;
            if(x < 0) x = -x;
            if(z < 0) z = -z;
            x = x + z;
            x = (x - 1) / v + 1;
            if(poteza[i][k] > x || poteza[i][k] == -1)
            {
                poteza[i][k] = x;
            }
        }
    }
}

int main()
{
    int a, b, v;
    scanf("%d %d", &n, &m);
    for(int i = 1; i <= n; i++)
    {
        scanf("%s", moze[i]+1);
        for(int k = 1; k <= m; k++)
        {
            if(moze[i][k] == '1')
                ima++;
            poteza[i][k] = brzina[i][k] = -1;
        }
    }
    
    scanf("%d", &q);
    
    
    if(ima)
    {
        for(int i = 1; i <= q; i++)
        {
            scanf("%d %d %d", &a, &b, &v);
            resi(a, b, v, 0, v-1);
        }
    }
    
    else
    {
        for(int i = 1; i <= q; i++)
        {
            scanf("%d %d %d", &a, &b, &v);
            resiNEMA(a, b, v);
            poteza[a][b] = 0;
        }
    }
    
    for(int i = 1; i <= n; i++)
    {
        for(int k = 1; k <= m; k++)
        {
            //printf("%d ", poteza[i][k]);
            if((poteza[i][k] > max || max == -1) && poteza[i][k] != -1)
            {
                max = poteza[i][k];
                maxA = i;
                maxB = k;
            }
        }
        //printf("\n");
    }
    
    printf("%d %d", maxA, maxB);
    
    //system("PAUSE");
    //return EXIT_SUCCESS;
    
    return 0;
}
