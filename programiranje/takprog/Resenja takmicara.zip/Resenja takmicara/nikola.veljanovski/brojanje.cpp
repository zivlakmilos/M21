#include <stdio.h>
#include <math.h>
#include <cstdlib>
#include <iostream>

int n, q, d;
int niz[1000005], levo[1000005], desno[1000005], izlaz[1000005];
int broj[1000005];
int konstanta = 1000000007;

int main()
{
    scanf("%d", &n);
    
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &niz[i]);
        levo[i] = desno[i] = 0;
        broj[i] = 0;
        for(int k = i-1; k >= 0; k--)
        {
            if(niz[i] >= niz[k])
            {
                levo[i]+=levo[k]+1;
                k-=levo[k];
            }
            else
                break;
        }
    }
    
    for(int i = n-1; i >= 0; i--)
    {
        for(int k = i+1; k < n; k++)
        {
            if(niz[i] > niz[k])
            {
                desno[i]+=desno[k]+1;
                k+=desno[k];
            }
            else
                break;
        }
    }
    
    /*for(int i = 0; i < n; i++)
        printf("%d ", levo[i]);
    printf("\n");
    for(int i = 0; i < n; i++)
        printf("%d ", desno[i]);
    printf("\n");
    */
    for(int i = 0; i < n; i++)
    {
        levo[i] = levo[i] % konstanta;
        desno[i] = desno[i] % konstanta;
        broj[niz[i]] += levo[i] * desno[i] + levo[i] + desno[i] + 1;
        broj[niz[i]] = broj[niz[i]] % konstanta;
    }
    
    scanf("%d", &q);
    
    for(int i = 0; i < q; i++)
    {
        scanf("%d", &d);
        if(broj[d] > 0)
        {
            izlaz[i] = broj[d];
        }
        else
            izlaz[i] = 0;
    }
    
    for(int i = 0; i < q; i++)
        printf("%d\n", izlaz[i]);
    
    //system("PAUSE");
    //return EXIT_SUCCESS;
    
    return 0;
}
