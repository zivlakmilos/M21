#include <iostream>
#include <stdio.h>
#include <stdlib.h>

#define M 500000
#define nebuloza 10000000

char Q[M];

int main()
{
    int n = 0, r = 0, s = 0;
    scanf("%d %d %d\n", &n, &r, &s );


    int i = 0;
    int x = 0, y = 0;

    bool proslo = false;
    int rosa = nebuloza, sosa = nebuloza;
    int ostr = 0, osts = 0, ost = 0;
    int U = 0, D = 0, L = 0, R = 0;

    for( i = 0; i <= n; ++i )
    {

        if( x == r && y == s )
        {
            proslo = true;
            ost = n - i;
        }

        else if( x == r )
        {
            if( abs( y - s ) < abs( sosa - s ) /*&& n - i - 1 >= abs( y - s )*/ )
            {
                osts = n - i;
                sosa = y;
            }
        }

        else if( y == s )
        {
            if( abs( x - r ) < abs( rosa - r ) /*&& n - i - 1 >= abs( x - r )*/ )
            {
                rosa = x;
                ostr = n - i;
            }
        }


        scanf("%c", &Q[i] );

        switch( Q[i] )
        {
        case 'U':
            ++U;
            ++y;
            break;

        case 'D':
            ++D;
            --y;
            break;

        case 'R':
            ++R;
            ++x;
            break;

        case 'L':
            ++L;
            --x;
            break;
        }
    }

        if( x == r && y == s )
        {
            proslo = true;
            ost = 0;
        }

        else if( x == r )
        {
            if( abs( y - s ) < abs( sosa - s ) /*&& n - i - 1 >= abs( y - s )*/ )
            {
                sosa = y;
                osts = 0;
            }
        }

        else if( y == s )
        {
            if( abs( x - r ) < abs( rosa - r ) /*&& n - i - 1 >= abs( x - r )*/ )
            {
                rosa = x;
                ostr = 0;
            }
        }


    if( proslo == true )
        printf("0");

    else
    {
        int k = 0, q = 0, f = 0;
        if( abs( rosa - r ) < abs( sosa - s ) ) // L    R
        {
            k = rosa - r;
            q = abs(k) / 2;

            if( k < 0 )
            {
                if( L < q )
                    q = L;
                k += 2 * q;
                f = q - k;
                printf("%d", f );
            }
            else
            {
                if( R < q )
                    q = R;
                k -= 2 * q;
                f = q + k;
                printf("%d", f );
            }
 /*           ostr -= f;
            ostr /= 2;
            printf(" %d", ostr + f );*/
        }

        else        // U    D
        {
            k = sosa - s;
            q = abs(k) / 2;
            if( k < 0 )
            {
                if( D < q )
                    q = D;
                k += 2 * q;
                f = q - k;
                printf("%d", f );
            }

            else
            {
                if( U < q )
                    q = U;
                k -= 2 * q;
                f = q + k;
                printf("%d", f );
            }
/*
            osts -= f;
            osts /= 2;
            printf(" %d", osts + f );*/
        }
    }

    int q = 0, k = 0;
    x -= r;
    y -= s;

    q = abs( x / 2 );

    if( x > 0 )
    {
        if( R < q )
            q = R;
        x -= q * 2;
        k += q;
        if( L < q )
            q = L;
    }

    else if( x < 0 )
    {
        if( L < q )
            q = L;
        x += q * 2;
        k += q;
        if( R < q )
            q = D;
    }

    int priv = q;

    q = abs( y / 2 );
    if( y > 0 )
    {
        U += priv;
        if( U < q )
            q = U;
        y -= q * 2;
        k += q;
    }

    else if( y < 0 )
    {
        D += priv;
        if( D < q )
            q = D;
        y += q * 2;
        k += q;
    }
    //k += y - x;
    printf(" %d", k );

//    system("PAUSE");
    return 0;
}
