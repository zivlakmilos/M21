#include <stdio.h>
#include <stdlib.h>

#define M 1000
#define nebuloza 1000000000

int a[M][M];

int Min( int x, int y )
{
    if( x > y )
        return y;
    return x;
}

int n, m, k;

void Popuni( int x, int y, int v )
{
    a[x][y] = 0;

    int i, j;

    for( i = 0; i < n; ++i )
    {
        for( j = 0; j < m; ++j )
        {
            a[i][j] = Min( a[i][j], abs( x - i ) + abs( y - j ) / v );
        }
    }
}

int main()
{
    scanf("%d %d %d", &n, &m, &k );

    int x[k], y[k], v[k];

    int i = 0, j = 0;
    for( i = 0; i < k; ++i )
        scanf("%d %d %d", &x[i], &y[i], &v[i] );

    for( i = 0; i < n; ++i )
    {
        for( j = 0; j < m; ++j )
        {
            a[i][j] = nebuloza;
        }
    }

    for( i = 0; i < k; ++i )
        Popuni( x[i], y[i], v[i] );

    int xmax = 0, ymax = 0;
    for( i = 0; i < n; ++i )
    {
        for( j = 0; j < m; ++j )
        {
            if( a[i][j] > a[xmax][ymax] )
            {
                xmax = i;
                ymax = j;
            }
        }
    }
    printf("%d %d", xmax + 1, ymax + 1 );
    return 0;
}
