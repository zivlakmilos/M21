#include <stdio.h>

#define M 100000
int a[M], b[M];

void quick( int levi, int desni, int* skup );

void Zamena( int x, int y, int* skup )
{
    int temp = skup[x];
    skup[x] = skup[y];
    skup[y] = temp;
}


int main()
{
    int n = 0;
    scanf("%d\n", &n );
    int i = 0, j = 0;

    for( i = 0; i < n; ++i )
        scanf("%d", &a[i] );

    for( i = 0; i < n; ++i )
        scanf("%d", &b[i] );

    quick( 0, n - 1, a );
    quick( 0, n - 1, b );// NERASTUCI 3 2 1 ...

    long long int ds = 0, ls = 0, sum = 0, last = 0, lastsum = 0;
    int levo = 0, desno = 0, istih = 0;
    j = 0;
    i = 0;
    while( b[i] > a[j] )
    {
        sum += b[i] - a[j];
        ++i;
    }
    levo = i;
    ls = sum;

    while( b[i] == a[j] )
        ++i;

    istih = i;

    while( i < n )
    {
        sum += a[j] - b[i];
        ds += a[j] - b[i];
        ++i;
    }

    desno = i - istih;
    last = sum;

    for( i = 1; i < n; ++i )
    {
        if( a[i] == a[i - 1] )
        {
            sum += last;
            continue;
        }

        lastsum = sum;

        ls += levo * ( a[i - 1] - a[i] );

        while( a[i] < b[levo] )
        {
            ls += b[levo] - a[i];
            ds -= a[i - 1] - b[levo];
            ++levo;
        }

        istih = levo;

        while( a[i] == b[istih] )
        {
            ds -= a[i - 1] - b[istih];
            ++istih;
        }

        sum += ls;
        desno = n - istih;
        ds -= desno * ( a[i - 1] - a[i] );
        sum += ds;
        last = sum - lastsum;
    }

    printf("\n%lld", sum );

    return 0;
}


void quick( int levi, int desni, int* skup )
{
    if( levi >= desni )
        return;

    int s = ( levi + desni ) / 2;
    int glavni = skup[s];
    Zamena( levi, s, skup );

    int pivot = levi, i = 0;
    for( i = levi + 1; i <= desni; ++i )
    {
        if( skup[i] > glavni )
            Zamena( i, ++pivot, skup );
    }

    Zamena( levi, pivot, skup );

    quick( levi, pivot - 1, skup );
    quick( pivot + 1, desni, skup );
}
