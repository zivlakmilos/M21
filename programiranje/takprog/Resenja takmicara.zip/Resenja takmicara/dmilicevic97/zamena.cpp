#include <cstdio>
#include <algorithm>
using namespace std;

const int MAX_N = 1e5;

int n;
int brojevi[MAX_N];
/// mark[i][j] - i = bez i-te cifre, j = broj bez i-te cifre
int mark[7][1000000];
int pow10[8];
int dp[MAX_N];
/// prviIznad[i][j] - prvi iznad i takav da se razlikuju na j-toj cifri
int prviIznad[MAX_N][7];
int cifre[MAX_N][7];

void input() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", brojevi + i);

    for (int i = 0; i < 7; i++)
        for (int j = 0; j < 1000000; j++)
            mark[i][j] = -1;

    pow10[0] = 1;
    for (int i = 1; i < 8; i++)
        pow10[i] = pow10[i-1] * 10;
}

int brojCifara() {
    int x = brojevi[0];
    int ret = 0;

    if (x == 0)
        return 1;

    while (x) {
        ret++;
        x /= 10;
    }

    return ret;
}

void popuniCifre() {
    for (int i = 0; i < n; i++) {
        int x = brojevi[i], cnt = 0;
        while (x) {
            cifre[i][cnt++] = x%10;
            x /= 10;
        }
    }
}

void solve() {
    int brojCif = brojCifara();
    popuniCifre();

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < brojCif; j++) {
            int brojBezJteCifre = (brojevi[i] / pow10[j+1]) * pow10[j] + brojevi[i] % pow10[j];
            prviIznad[i][j] = mark[j][brojBezJteCifre];
            mark[j][brojBezJteCifre] = i;
        }
    }

    /*
    for (int i = 0; i < n; i++) {
        printf("%d: ", i);
        for (int j = 0; j < brojCif; j++)
            printf("%d ", prviIznad[i][j]);

        printf("\n");
    }
    printf("\n\n");
    for (int i = 0; i < n; i++, printf("\n"))
        for (int j = 0; j < brojCif; j++)
            printf("%d ", cifre[i][j]);
    printf("\n\n");
    */

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < brojCif; j++)
            if (prviIznad[i][j] != -1) {
               // printf("%d %d ", i, j);
                int diff = abs(cifre[i][j] - cifre[prviIznad[i][j]][j]);
                dp[i] = max(dp[i], dp[prviIznad[i][j]] + diff);
               // printf("%d %d\n", diff, dp[i]);
            }
    }
}

void output() {
    int sol = 0;
    for (int i = 0; i < n; i++)
        sol = max(sol, dp[i]);

    printf("%d\n", sol);
}

int main() {
    input();
    solve();
    output();
    return 0;
}
