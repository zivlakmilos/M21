#include <cstdio>
#include <stack>
#include <map>
#include <utility>
using namespace std;

typedef long long lld;

const int MAX_N = 1e6;
const lld MOD = 1e9 + 7;

int n, q;
int dosadnosti[MAX_N];
map<int, lld> resenje;
int prviLeviVeci[MAX_N], prviDesniVeciIliJednak[MAX_N];

void input() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", dosadnosti + i);
}

lld mod(lld x) {
    return (x < MOD) ? x : (x%MOD);
}

void resi() {
    stack<int> s;
    for (int i = 0; i < n; i++) {
        prviLeviVeci[i] = -1;
        prviDesniVeciIliJednak[i] = n;
    }

    for (int i = 0; i < n; i++) {
        if (s.empty())
            s.push(i);
        else {
            while (!s.empty() && dosadnosti[s.top()] <= dosadnosti[i])
                s.pop();
            if (!s.empty())
                prviLeviVeci[i] = s.top();
            s.push(i);
        }
    }

    while (!s.empty())
        s.pop();
    for (int i = n-1; i > -1; i--) {
        if (s.empty())
            s.push(i);
        else {
            while (!s.empty() && dosadnosti[s.top()] < dosadnosti[i])
                s.pop();
            if (!s.empty())
                prviDesniVeciIliJednak[i] = s.top();
            s.push(i);
        }
    }

/*
    for (int i = 0; i < n; i++)
        printf("%d %d\n", prviLeviVeci[i], prviDesniVeciIliJednak[i]);
    printf("\n\n");
*/
    for (int i = 0; i < n; i++) {
        lld ins = mod((lld)(i - prviLeviVeci[i]) * (prviDesniVeciIliJednak[i] - i));

        map<int, lld>::iterator it = resenje.find(dosadnosti[i]);
        if (it == resenje.end())
            resenje.insert(pair<int, lld>(dosadnosti[i], ins));
        else
            it->second = mod(it->second + ins);
    }
/*
    for (map<int, lld>::iterator it = resenje.begin(); it != resenje.end(); it++)
        printf("%d %lld\n", it->first, it->second);
*/
}

void upiti() {
    scanf("%d", &q);

    int broj;
    while (q--) {
        scanf("%d", &broj);
        printf("%lld\n", resenje.find(broj)->second);
    }
}

int main() {
    input();
    resi();
    upiti();

    return 0;
}
