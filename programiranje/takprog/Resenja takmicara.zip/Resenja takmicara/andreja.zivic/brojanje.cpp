#include <cstdio>
#include <algorithm>

using namespace std;

const int maxn = 100000;

struct par
        {
            int br;
            long long sol;
        } a[maxn];

bool cmp(par a, par b)
{
    if (a.br < b.br)
    {
        long long p = a.sol;
        a.sol = b.sol;
        b.sol = p;
        return true;
    }
    else return false;
}

int n,broj,x1,x2,q,l,r,m,k;
long s;


int main()
{
    scanf("%d", &n);
    for (int i=0; i<n; i++) scanf("%d", &a[i].br);

    for (int j=0; j<n; j++)
    {
        broj = a[j].br;
        s = 0;
        x1 = 0;
        x2 = 0;
        for (int i=0; i<n; i++)
        {
            if (a[i].br>broj)
            {
                s += x1*(x1+1)/2 - x2*(x2+1)/2;
                x1 = 0;
                x2 = 0;
            }
            if (a[i].br == broj)
            {
                s -= x2*(x2+1)/2;
                x1++;
                x2 = 0;
            }
            if (a[i].br<broj)
            {
                x1++;
                x2++;
            }
        }
        s += x1*(x1+1)/2 - x2*(x2+1)/2;
        a[j].sol = s;
    }

    sort( a , a + n , cmp);

    //for (int i=0; i<n; i++) printf("%d ", a[i].br);
    //printf("\n");
    //for (int i=0; i<n; i++) printf("%d ", a[i].sol);


    scanf("%d", &q);

    for (int j=0; j<q; j++)
    {
        scanf("%d", &k);

        l = 0;
        r = n-1;

        while (l<r-1)
        {
            if (k>a[r].br)
            {
                printf("0\n");
                l = r+1;
                continue;
            }
            if (k<a[l].br)
            {
                printf("0\n");
                l = r+1;
                continue;
            }
            if (l == r-1)
            {
                if (a[l].br == k)
                {
                    printf("%lld\n", a[l].sol);
                    l = r+1;
                    continue;
                }
                if (a[r].br == k)
                {
                    printf("%lld\n", a[r].sol);
                    l = r+1;
                    continue;
                }
                printf("0\n");
                l = r+1;
                continue;
            }
            if (a[l].br == k)
            {
                printf("%lld\n", a[l].sol);
                l = r+1;
                continue;
            }
            if (a[r].br == k)
            {
                printf("%lld\n", a[r].sol);
                l = r+1;
                continue;
            }
            m = (l+r)/2;
            if (a[m].br>k) r = m-1;
            if (a[m].br<k) l = m+1;
            if (a[m].br == k)
            {
                printf("%lld\n", a[m].sol);
                l = r+1;
                continue;
            }
            if (a[l].br == k) printf("%lld\n", a[l].sol);
            if (a[r].br == k) printf("%lld\n", a[r].sol);
            if ((a[l].br<k) && (a[r].br>k)) printf("0\n");
            //printf("%d %d %d ", l, m, r);
        }
    }

    return 0;

}
