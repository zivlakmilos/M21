#include <cstdio>

const int maxn = 1e3 + 5;
const int maxk = 1e6 + 5;

int b[maxn][maxn],a[maxn][maxn],x[maxk],y[maxk],v[maxk],sol,solx,soly,n,m,k;
char c;


int minimum(int a, int b)
{
    if (a<b) return a;
    else return b;
}

int maximum(int a, int b)
{
    if (a<b) return b;
    else return a;
}

void bfs(int x, int y, int br)
{
    int kor[maxk];
    int ud[maxk];
    int curr;
    int redn;
    int o[maxn][maxn];
    int redx[maxk];
    int redy[maxk];

    b[x][y] = 0;
    o[x][y] = 1;
    kor[0] = 1;
    ud[0] = 1;
    curr = 0;
    redn = 1;

    redx[0] = x;
    redy[0] = y;

    while ( redn > curr )
    {
        if ((a[redx[curr]-1][redy[curr]] == 0) && (o[redx[curr]-1][redy[curr]] == 0))
        {
            o[redx[curr]-1][redy[curr]] = 1;
            redn++;
            redx[redn] = redx[curr]-1;
            redy[redn] = redy[curr];
            ud[redn] = ud[curr] + 1;
            if (ud[redn] % br == 0) kor[redn] = kor[curr] + 1;
            else kor[redn] = kor[curr];
            b[redx[redn]][redy[redn]] = minimum(kor[redn], b[redx[redn]][redy[redn]]);
        }
        if ((a[redx[curr]+1][redy[curr]] == 0) && (o[redx[curr]+1][redy[curr]] == 0))
        {
            o[redx[curr]+1][redy[curr]] = 1;
            redn++;
            redx[redn] = redx[curr]+1;
            redy[redn] = redy[curr];
            ud[redn] = ud[curr] + 1;
            if (ud[redn] % br == 0) kor[redn] = kor[curr] + 1;
            else kor[redn] = kor[curr];
            b[redx[redn]][redy[redn]] = minimum(kor[redn], b[redx[redn]][redy[redn]]);
        }
        if ((a[redx[curr]][redy[curr]-1] == 0) && (o[redx[curr]][redy[curr]-1] == 0))
        {
            o[redx[curr]][redy[curr]-1] = 1;
            redn++;
            redx[redn] = redx[curr];
            redy[redn] = redy[curr]-1;
            ud[redn] = ud[curr] + 1;
            if (ud[redn] % br == 0) kor[redn] = kor[curr] + 1;
            else kor[redn] = kor[curr];
            b[redx[redn]][redy[redn]] = minimum(kor[redn], b[redx[redn]][redy[redn]]);
        }
        if ((a[redx[curr]][redy[curr]+1] == 0) && (o[redx[curr]][redy[curr]+1] == 0))
        {
            o[redx[curr]][redy[curr]+1] = 1;
            redn++;
            redx[redn] = redx[curr];
            redy[redn] = redy[curr]+1;
            ud[redn] = ud[curr] + 1;
            if (ud[redn] % br == 0) kor[redn] = kor[curr] + 1;
            else kor[redn] = kor[curr];
            b[redx[redn]][redy[redn]] = minimum(kor[redn], b[redx[redn]][redy[redn]]);
        }
        curr++;
    }

}

int main()
{
    scanf("%d %d", &n, &m);

    for (int i=0; i<n; i++)
        for (int j=0; j<=m; j++)
        {
            scanf("%c", &c);
            if (c == '1') a[i][j] = 1;
            if (c == '0') a[i][j] = 0;
        }

    scanf("%d", &k);

    for (int i=0; i<k; i++) scanf("%d %d %d", &x[i], &y[i], &v[i]);

    for (int i=0; i<k; i++)
    {
        //for (int i=0; i<n; i++)
            //for (int j=0; j<m; j++) o[i][j] = 0;

        bfs(x[i],y[i],v[i]);
    }

    for (int i=0; i<n; i++)
        for (int j=0; j<m; j++)
        {
            sol = maximum(sol,b[i][j]);
            solx = i;
            soly = j;
        }

    printf("%d %d", solx, soly);
    return 0;
}
