#include <cstdio>

const int maxn = 1e5+5;
const int maxa = 1e7+5;

int a[maxn],dp[maxa], o[maxa],n,sol;

int f(int a)
{
    int d = 0;
    int p = 0;
    int b = a/10;
    b *= 10;
    int m = a % 10;
    for (int i=0; i<10; i++)
    {
        int c = b + i;
        if ((c != a) && (o[c] == 1))
        {
            p = dp[c] + (m-i);
            if (p>d) d = p;
        }
    }


    int x = 10;

    for (int j = 1; j<7; j++)
    {
        x *= 10;
        b = (a/x);
        b *= x;

        m = a % (x/10);

        b += m;
        m = a%x;
        m /= (x/10);
        //printf("%d %d %d\n", b, m, x);

        for (int i=0; i<10; i++)
        {
            int c = b + i*(x/10);
            //printf("%d %d %d\n", a, c, o[c]);
            if ((c != a) && (o[c] == 1))
            {
                p = dp[c] + (m-i);
                //printf("%d %d\n", p, d);
                if (p>d) d = p;
            }
        }
    }

    o[a] = 1;
    if (d<0) d = 0;
    //printf("%d\n", d);

    return d;
}

int main()
{
    scanf("%d", &n);

    for (int i=0; i<n; i++) scanf("%d", &a[i]);

    dp[a[0]] = 0;
    o[a[0]] = 1;

    //dp[1] = f(a[1]);
    //printf("/n/n");
    //dp[2] = f(a[2]);

    for (int i=1; i<n; i++) dp[a[i]] = f(a[i]);

    //for (int i=0; i<n; i++) printf("%d ", dp[a[i]]);
    //printf("\n");

    for (int i=0; i<n; i++)
        if (sol < dp[a[i]]) sol = dp[a[i]];

    printf("%d", sol);
    return 0;
}
