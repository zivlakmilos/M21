#include <cstdio>
#include <map>
#include <algorithm>
using namespace std;

int n, i, j, x, st, cif, maxi, sol=0, brc, val, a[100005];
map <int, pair<int,int> > hash;

int abs(int _x) { return _x>0 ? _x : -_x; }

int main()
{
    scanf("%d", &n);
    for (i=1; i<=n; i++) scanf("%d", a+i);
    st = 1; brc = 1;
    while (st*10<=a[1]) { st*=10; brc++; }
    if (brc>1) {
    for (i=n; i; i--)
    {
        st = 1;
        maxi = 0;
        for (j=0; j<brc; j++)
        {
            x = (a[i]/(st*10))*st*10 + (a[i]%st);
            x = x*10 + j;
            cif = (a[i]%(st*10))/st;
            if (hash[x].second>0 && hash[x].second<11)
            {
                val = hash[x].first+abs(cif+1-hash[x].second);
                if (val>maxi) maxi = val;
            }
            st *= 10;
        }
        st = 1;
        for (j=0; j<brc; j++)
        {
            x = (a[i]/(st*10))*st*10 + (a[i]%st);
            x = x*10 + j;
            cif = (a[i]%(st*10))/st;
            hash[x] = make_pair(maxi, cif+1);
            st *= 10;
        }
        if (maxi>sol) sol = maxi;
    }
    } else
    { for (i=2; i<=n; i++) sol+=abs(a[i]-a[i-1]); }
    printf("%d", sol);
    return 0;
}
