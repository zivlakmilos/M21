#include<cstdio>
#include <algorithm>
#include <map>
#include <set>
using namespace std;
const int MOD = 1000000007;

int n, i, q, idx1, idx2, x;
long long int prev, curr, uh;
struct node { int val, idx; } a[1000006];
struct dot
{
    int left, right;
    bool operator < (const dot & _x) const
     { return left<_x.left; }
} pom;
bool cmp(node _a, node _b) { return _a.val<_b.val; }
set <dot> s;
set <dot> ::iterator id;
set <dot> ::iterator it;
map <int, int> mapa;

void pomnozi(int _x)
{
    curr += (1LL*_x*(_x+1))/2;
    while (curr>=MOD) curr -= MOD;
}
void podeli(int _x)
{
    curr -= (1LL*_x*(_x+1))/2;
    while (curr<0) curr += MOD;
}

int main()
{
    scanf("%d", &n);
    for (i=0; i<n; i++) { scanf("%d", &a[i].val); a[i].idx = i; }
    sort(a, a+n, cmp);
    prev = 0; curr = 0;
    idx1 = 0; idx2 = 0;
    while (idx1<n)
    {
    while (a[idx2].val==a[idx1].val && idx2<n)
    {
        pom.left = a[idx2].idx;
        id = s.lower_bound(pom);
        if (id != s.begin()) { it = --s.lower_bound(pom); }
        if (id == s.begin())
        {
            if (a[idx2].idx + 1 == id->left)
            {
                pom.left = a[idx2].idx;
                pom.right = id->right;
                podeli(id->right - id->left + 1);
                pomnozi(id->right - id->left + 2);
                s.erase(id);
                s.insert(pom);
            } else
            {
                pom.left = a[idx2].idx;
                pom.right = a[idx2].idx;
                pomnozi(1);
                s.insert(pom);
            }
        } else
        if (id == s.end())
        {
            if (a[idx2].idx - 1 == it->right)
            {
                pom.left = it->left;
                pom.right = a[idx2].idx;
                podeli(it->right - it->left + 1);
                pomnozi(it->right - it->left + 2);
                s.erase(it);
                s.insert(pom);
            } else
            {
                pom.left = a[idx2].idx;
                pom.right = a[idx2].idx;
                pomnozi(1);
                s.insert(pom);
            }
        } else
        {
            if (it->right + 2 == id->left)
            {
                pom.left = it->left;
                pom.right = id->right;
                podeli(id->right - id->left + 1);
                podeli(it->right - it->left + 1);
                pomnozi(pom.right - pom.left + 1);
                s.erase(it);
                s.erase(id);
                s.insert(pom);
            } else
            {
                if (a[idx2].idx + 1 == id->left)
                {
                    pom.left = a[idx2].idx;
                    pom.right = id->right;
                    podeli(id->right - id->left + 1);
                    pomnozi(id->right - id->left + 2);
                    s.erase(id);
                    s.insert(pom);
                } else
                if (a[idx2].idx - 1 == it->right)
                {
                    pom.left = it->left;
                    pom.right = a[idx2].idx;
                    podeli(it->right - it->left + 1);
                    pomnozi(it->right - it->left + 2);
                    s.erase(it);
                    s.insert(pom);
                } else
                {
                    pom.left = a[idx2].idx;
                    pom.right = a[idx2].idx;
                    pomnozi(1);
                    s.insert(pom);
                }
            }
        }
        idx2++;
    }
    uh = curr - prev;
    while (uh<0) uh = uh + MOD;
    mapa[a[idx1].val] = int(uh);
    idx1 = idx2;
    prev = curr;
    }

    scanf("%d", &q);
    while (q--)
    {
        scanf("%d", &x);
        printf("%d\n", mapa[x]);
    }

    return 0;
}
