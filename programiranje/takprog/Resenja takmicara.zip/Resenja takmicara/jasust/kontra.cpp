#include<cstdio>
using namespace std;

int n, m;

int main()
{
    scanf("%d %d", &n, &m);
    printf("%d %d", n, m);

    return 0;
}
