#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <queue>

using namespace std;

struct tragac
{
    int x;
    int y;
    int v;
    int predjen;
};

struct skrivMesto
{
    int skrivenost;
    int v;
};

int n, m, k, tmp;
bool polje[980][980];
skrivMesto skrivenosti[980][980];

void obidji(tragac trazi)
{
    bool obidjen[980][980];
    queue <tragac> put;
    put.push(trazi);
    while(!put.empty())
    {
        tragac tren;
        tragac tmp;
        tren=put.front();
        put.pop();

        if((skrivenosti[tren.x][tren.y].skrivenost>=tren.predjen/tren.v)||(tren.v>skrivenosti[tren.x][tren.y].v))
        {
            skrivenosti[tren.x][tren.y].skrivenost=tren.predjen/tren.v;
            skrivenosti[tren.x][tren.y].v=tren.v;

            if((tren.x>0)&&(!polje[tren.x-1][tren.y])&&(!obidjen[tren.x-1][tren.y]))
            {
                tmp.x=tren.x-1;
                tmp.y=tren.y;
                tmp.v=tren.v;
                tmp.predjen=tren.predjen+1;
                put.push(tmp);
            }
            if((tren.x<n-1)&&(!polje[tren.x+1][tren.y])&&(!obidjen[tren.x+1][tren.y]))
            {
                tmp.x=tren.x+1;
                tmp.y=tren.y;
                tmp.v=tren.v;
                tmp.predjen=tren.predjen+1;
                put.push(tmp);
            }
            if((tren.y>0)&&(!polje[tren.x][tren.y-1])&&(!obidjen[tren.x][tren.y-1]))
            {
                tmp.x=tren.x;
                tmp.y=tren.y-1;
                tmp.v=tren.v;
                tmp.predjen=tren.predjen+1;
                put.push(tmp);
            }
            if((tren.y<m-1)&&(!polje[tren.x][tren.y+1])&&(!obidjen[tren.x][tren.y+1]))
            {
                tmp.x=tren.x;
                tmp.y=tren.y+1;
                tmp.v=tren.v;
                tmp.predjen=tren.predjen+1;
                put.push(tmp);
            }
        }
    }


}

int main()
{
    scanf("%i%i", &n, &m);
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            scanf("%i", &tmp);
            if(tmp==0)
            {
                polje[i][j]=false;
            }
            else
            {
                polje[i][j]=true;
            }
        }
    }

    tragac tr;

    scanf("%i", &k);
    for(int i=0; i<k; i++)
    {
        scanf("%i%i%i", &tr.x, &tr.y, &tr.v);
        tr.x--;
        tr.y--;
        tr.predjen=tr.v-1;
        obidji(tr);
    }

    int maxSkr=-1;
    int maxi, maxj;

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            if((maxSkr<skrivenosti[i][j].skrivenost)&&(!polje[i][j]))
            {
                maxSkr=skrivenosti[i][j].skrivenost;
                maxi=i+1;
                maxj=j+1;
            }
        }
    }

    printf("%i %i\n", maxi, maxj);

    return 0;
}

/*
5 7
0 0 1 0 0 0 0
0 1 0 0 0 0 0
0 0 0 0 1 1 0
0 0 0 0 0 0 0
0 0 0 0 0 0 0
2
1 2 3
4 4 1
*/
