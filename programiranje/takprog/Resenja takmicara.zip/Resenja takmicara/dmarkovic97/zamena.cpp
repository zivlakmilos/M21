#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>

using namespace std;


int duz, n, putl[100001];
const static int maxSize=100000;

struct node
{
    int data;
    int raz;
    node *next;
};

class graf
{
public:
    node cvorovi[maxSize];
    int size;
    graf();
    ~graf();
    void povezi(int, int, int);
    int nadjiPut(int);
};

graf::graf()
{
    for(int i=0; i<maxSize; i++)
    {
        node *tmp;
        tmp = new node;
        cvorovi[i].next=tmp;
        cvorovi[i].next->next=cvorovi[i].next;
    }
}

graf::~graf()
{

}

void graf::povezi(int x, int y, int w)
{
    node *tmp;
    tmp= new node;
    tmp->data=y;
    tmp->raz=w;
    tmp->next=cvorovi[x].next->next;
    cvorovi[x].next->next=tmp;
}

int graf::nadjiPut(int x)
{
    if(putl[x]>0)
    {
        return putl[x];
    }
    int maxPut=0;
    int tmpPut;
    node *tmp;
    tmp=cvorovi[x].next->next;
    while(tmp!=cvorovi[x].next)
    {
        tmpPut=(tmp->raz)+nadjiPut(tmp->data);
        if(tmpPut>maxPut)
        {
            maxPut=tmpPut;
        }
        tmp=tmp->next;
    }
    putl[x]=maxPut;

    return maxPut;

}

int uporediStringove(char a[10], char b[10])
{
    int razlikun, razlika;
    razlikun=0;
    razlika=0;
    for(int i=0; i<duz; i++)
    {
        if(a[i]!=b[i])
        {
            razlika=abs(a[i]-b[i]);
            razlikun++;
        }
    }
    if(razlikun==1)
    {
        return razlika;
    }
    else
    {
        return 0;
    }
}



int main()
{
    char s[100000][8];

    graf gr;

    scanf("%i", &n);
    for(int i=0; i<n; i++)
    {
        scanf("%s", &s[i]);
    }

    duz=strlen(s[n-1]);
    for(int i=0; i<n-1; i++)
    {
        for(int j=i+1; j<n; j++)
        {
            int x;
            x=uporediStringove(s[i], s[j]);
            if(x>0)
            {
                gr.povezi(i, j, x);
            }
        }
    }
    int tmpl;
    int maxl=0;
    for(int i=0; i<n; i++)
    {
        tmpl=gr.nadjiPut(i);
        if(maxl<tmpl)
        {
            maxl=tmpl;
        }
    }

    printf("%i\n", maxl);

    return 0;
}

/*
6
8823
2145
2185
3385
4145
4445
*/
