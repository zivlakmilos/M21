//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
typedef struct
{
    int X, Y;
    long long brzina;
} TRAGAC;
int N, M, K;
TRAGAC T[1001];
int MAPA[1000][1000];
int MAX;
int MI, MJ;
void odrMapu()
{
    int i, j, z;
    MAX = 0;
    for(i = 0; i < N; i++)
    {
        for(j = 0; j < M; j++)
        {
            int m = 99999999;
            for(z = 0; z < K; z++)
            {
                int temp = abs(T[z].Y - j) + abs(T[z].X - i);
                if(temp != 0)
                {
                    if(temp % T[z].brzina == 0)
                    {
                        temp = temp / T[z].brzina;
                    }
                    else
                    {
                        temp = temp / T[z].brzina;
                        temp += 1;
                    }
                }
                else
                {
                    m = 0;
                    break;
                }
                if(temp < m) m = temp;
            }

            MAPA[i][j] = m;
            if(MAPA[i][j] > MAX)
            {
                MAX = MAPA[i][j];
                MI = i;
                MJ = j;
            }
            //printf("%d", MAPA[i][j]);
        }
       // printf("\n");
    }
}
int main()
{
    int i, j;
    scanf("%d %d %d", &N, &M, &K);
    for(i = 0; i < K; i++)
    {
        scanf("%d %d %lld", &T[i].X, &T[i].Y, &T[i].brzina);
        T[i].X -= 1;
        T[i].Y -= 1;
    }
    odrMapu();
    printf("%d %d", MI+1, MJ+1);
    return 0;
}
