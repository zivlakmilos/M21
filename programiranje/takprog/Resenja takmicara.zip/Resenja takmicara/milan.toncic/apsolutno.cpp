//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MAX_A 200002
#define MAX_B 100001
int N;
long A[MAX_A];
long B[MAX_B];
int sum = 0;
int rez = 0;
void raz(int poz)
{
    int i, j = 0;
    sum = 0;
    for(i = poz; i < poz+N; i++)
    {
        sum += abs(A[i] - B[j]);
        j++;
    }
}
int main()
{
    int i, j;
    scanf("%d", &N);
    for(i = 0; i < N; i++)
    {
        scanf("%ld", &A[i]);
        A[i+N] = A[i];
    }
    for(i = 0; i < N; i++)
    {
        scanf("%ld", &B[i]);
    }
    int poz;
    for(i = 0; i < N; i++)
    {
        raz(i);
        rez += sum;
    }
    printf("%d", rez);
    return 0;
}
