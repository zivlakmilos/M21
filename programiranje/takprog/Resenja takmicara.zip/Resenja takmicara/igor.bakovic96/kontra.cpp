#include <cstdio>

int main()
{
	printf("%d %d", 3, 7);
}
