#include <cstdio>

int main()
{
	long n, q, ss=0, r=0;
	long long a[200000], k, sum=0;
	scanf("%ld", &n);
	for (int i=1; i<=n; i++) scanf("%lld", &a[i]);
	scanf("%ld", &q);

	int o=0;

	for (int j=1; j<=q; j++)
	{
		scanf("%lld", &k);
		for (int i=1; i<=n; i++)
		{
			if (a[i]<k)
			{
				ss++;
				if (o>0) sum=sum+r;
			}
			if (a[i]==k)
			{
				o=1;
				r=r+ss+1;
				ss=0;
				sum=sum+r;
			}
			if (a[i]>k)
			{
				ss=0;
				r=0;
			}
		}
		printf("%lld\n", sum);
		ss=0;
		r=0;
		sum=0;
	}

	return 0;
}
