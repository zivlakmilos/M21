#include <cstdio>
#include <algorithm>

int main()
{
	int n,r,c,d,sum=0,maxx=0, a[100000];
	scanf("%d", &n);

	for (int i=1; i<=n; i++) scanf("%d", &a[i]);

	for (int i=1; i<=n; i++)
		{
			c=i+1;
			d=i;
			while (c<n)
			{
			r=abs(a[d]-a[c]);
			while (r % 10 == 0) r=r/10;
			if (r/10==0)
			{
				sum=sum+r;
				d=c;
			}
			c++;
			}

			if (sum>maxx) maxx=sum;
			sum=0;
		}
	printf("%d", maxx);
}
