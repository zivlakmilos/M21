#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;

int main(int argc, char *argv[])
{
    printf("0 0");



    //system("PAUSE");
    return EXIT_SUCCESS;
}
