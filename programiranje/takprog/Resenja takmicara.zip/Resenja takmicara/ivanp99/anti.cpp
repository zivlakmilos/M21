#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <algorithm>


using namespace std;

int map[1000][1000];

int main(int argc, char *argv[])
{
    int n,m,k;
    scanf("%d%d%d",&n,&m,&k);
    int x[k];
    int y[k];
    int v[k];

    for(int i=0;i<k;i++){
            scanf("%d%d%d",&x[i],&y[i],&v[i]);
            //x[i]=i+1; y[i]=i+1; v[i]=i+1;
    }
    //cout<<"radi1 " ;

    //cout<<"radi2 " ;
    int max=0;
    int maxx=0,maxy=0;

    //(abs(i-x[l]+1)+abs(j-y[l]+1)+v[l]-1)/v[l]

    for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                    map[i][j]=n+m;
                    for(int l=0;l<k;l++){
                            if((abs(i-x[l]+1)+abs(j-y[l]+1)+v[l]-1)/v[l]<=map[i][j]){
                                                             map[i][j] = (abs(i-x[l]+1)+abs(j-y[l]+1)+v[l]-1)/v[l];

                                                             }
                            }
                            if(map[i][j]>max){
                                                                         max=map[i][j];
                                                                         maxx=i;
                                                                         maxy=j;
                                                                         }
                            //cout<<map[i][j]<<" ";
                    }
                    //cout<<endl;
    }
    printf("%d %d",maxx+1,maxy+1);
    
    //system("PAUSE");
    return 0;
}
