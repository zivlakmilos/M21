#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <stdio.h>
#include <math.h>

using namespace std;

int a[1000000];
int b[1000000];
    
int main(int argc, char *argv[])
{
    int n;
    
    long long int a1=0;
    long long int a0=0;
    long long int an=0;

    long long int b1=0;
    long long int b0=0;
    long long int bn=0;
    
    scanf("%d",&n);
    //n=100000;



    
    for(int i=0;i<n;i++){
            scanf("%d",&a[i]);
            //a[i]=0;
            an++;
            a1+=(a[i]==1);
            a0+=(a[i]==0);
            an-=(a[i]==1)+(a[i]==0);
    }

    for(int i=0;i<n;i++){
            scanf("%d",&b[i]);
            //b[i]=1;
            bn++;
            b1+=(b[i]==1);
            b0+=(b[i]==0);
            bn-=(b[i]==1)+(b[i]==0);
    }
    
    
    if(an==0 && bn == 0){
             unsigned long long int sum=a1*b0+a0*b1;
             printf("%lld",sum);
             }
    else if(n<=100000){
         long long int sum=0;
         for(int i=0;i<n;i++){
                 for(int j=0;j<n;j++){
                         sum+=abs(a[i]-b[j]);
                 }
         }
         printf("%lld",sum);
    }
    else{
         long long int sum=0;
         for(int i = 0;i<n;i++){
                 for(int j=0;j<n-n%3;j+=3){
                         long long int ah=((a[i]*1000000+a[i])*1000000+a[i]);
                         long long int bh=((b[j]*1000000+b[j+1])*1000000+b[j+2]);
                         sum+=abs(ah-bh)/(int)pow(10,12)%(int)pow(10,6)+abs(ah-bh)/(int)pow(10,6)%(int)pow(10,6)+abs(ah-bh)%(int)pow(10,6);
                         }
         }
         printf("%lld",sum);
    }

    //system("PAUSE");
    return 0;
}
