#include <cstdlib>
#include <iostream>
#include <algorithm>

using namespace std;

int n;
int a[100100];
int poma[100100];
int poma1[100100];
int b[100100];
int zb=0;
int rez;
int zz1,zz2;
int pronasao=0;
long long z[100100];


int main()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
            scanf("%d",&a[i]);
            poma[i]=a[i];
    }
    for(int i=0;i<n;i++)
    {
            scanf("%d",&b[i]);

    }
    
    sort(poma,poma+n);
    sort(b,b+n);
    for(int i=0;i<n;i++)
    {
            if(i>0)
            z[i]=z[i-1]+b[i];
            else
            z[i]=b[i];
    }
    int l=0,d=n-1;
    int p=(d-l)/2;
    
    for(int i=0;i<n;i++)
    {
           
            while(l!=d)
            {
                   if(b[p]>poma[i])
                   {
                                   if(d==p)
                                     break;
                                   d=p;   
                                   p=l+(d-l)/2;
                                  
                                    continue;                            
                   }
                    if(b[p]<=poma[i])
                   {
                                     pronasao++;
                                    
                                     if(l==p)
                                     break;
                                   l=p;   
                                   p=l+(d-l)/2;
                                   if(d==(l+1))
                                   p++;
                                                                             
                   }   
            }
 
           
            poma1[i]=l+1;
            if(pronasao==0)
            poma1[i]=0;
            
            l=0,d=n-1;
            p=(d-l)/2;
            pronasao=0;
            
    }
    for(int i=0;i<n;i++)
    {
            
            rez+=poma[i]*poma1[i]-poma[i]*(n-poma1[i]);
            rez+=z[n-1]-2*z[poma1[i]-1];
            
    }
    
  
    printf("%d",rez);
    
       
    

    return 0;
}
