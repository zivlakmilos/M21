#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;


int b,p;

int v[1010];
int x[1010];
int y[1010];
int n,m,q;

int main()
{
    scanf("%d %d %d",&n,&m,&q);
    
    for(int i=0;i<q;i++)
    {
            scanf("%d %d %d",&x[i],&y[i],&v[i]);
    }
    
   int s[n+100][m+100];
   
   for(int i=0;i<=n;i++)
   for(int j=0;j<=m;j++)
   {
           s[i][j]=n*m;
   }
   
    for(int i=1;i<=n;i++)
    {
            for(int j=1;j<=m;j++)
            {
                    for(int k=0;k<q;k++)
                    {
                            
                            p=abs(x[k]-i)+abs(y[k]-j);
                            if((p%v[k])==0)
                            {
                                        p=p/v[k];
                            }
                            else
                            p=p/v[k]+1;
                            
                          if(p<s[i][j])  
                          s[i][j]=p;
                    }
                    
            } 
    }
    
    
   
   
   
    int max=0;
    int maxx,maxy;
    for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++)
    {
            if(s[i][j]>max)
            {
                           max=s[i][j];
                           maxx=i;
                           maxy=j;
                          
                         
            }
    }
    
   printf("%d %d",maxx,maxy);
    
    
    return 0;
}
