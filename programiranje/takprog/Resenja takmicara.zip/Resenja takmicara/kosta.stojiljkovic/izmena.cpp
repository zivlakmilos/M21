#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;

int n,r,s;
bool prosao=false;
bool nasao=false;
int brR,brL,brU,brD;
char komande[500100];
int x,y;

int pom;

int razX(int a)
{
    return abs(r-a);
}
int razY(int a)
{
    return abs(s-a);
}

int ideDobro(char c)
{
     if(c=='R')
     {
               if(x==r)
               {
                    return 1;   
               }
               else
               {
               if(razX(x+1)>razX(x))
               return 2;
               else
               return 0; 
               }  
     }   
      if(c=='L')
     {
               if(x==r)
               {
                    return 1;   
               }
               else
               {
               if(razX(x-1)>razX(x))
               return 2;
               else
               return 0; 
               }  
     }  
      if(c=='U')
     {
               if(y==s)
               {
                    return 1;   
               }
               else
               {
               if(razY(y+1)>razY(y))
               return 2;
               else
               return 0; 
               }  
     }
           if(c=='D')
     {
               if(y==s)
               {
                    return 1;   
               }
               else
               {
               if(razY(y-1)>razY(y))
               return 2;
               else
               return 0; 
               }  
     }
}
int main()
{
    scanf("%d %d %d",&n,&r,&s);
    getchar();
    
    //unos
    for(int i=0;i<n;i++)
    {
            scanf("%c",&komande[i]);
    }
    //unos

    
 
    int rez=0,pr=0;
    int pom;
    
    for(int i=0;i<n;i++)
    {
            if(!nasao && x==r && y==s)
            {
                      nasao=true;
                      pr=rez;
            }
            
            pom=ideDobro(komande[i]);
            
            if(komande[i]=='R')
            {
                               if(pom==0)
                               {
                                         x++;
                                         continue;
                               }
                                if(pom==1)
                               {
                                         if(ideDobro('U')==0)
                                         {
                                                             y++;
                                                             rez++;
                                                             continue;
                                         }
                                           if(ideDobro('D')==0)
                                         {
                                                             y--;
                                                             rez++;
                                                             continue;
                                         }
                                         x++;
                                         continue;
                                         
                               }
                                if(pom==2)
                               {
                                          x--;
                                         rez++;
                                         continue;
                               }
            }
            if(komande[i]=='L')
            {
                               if(pom==0)
                               {
                                         x--;
                                         continue;
                               }
                                if(pom==1)
                               {
                                          if(ideDobro('U')==0)
                                         {
                                                             y++;
                                                             rez++;
                                                             continue;
                                         }
                                           if(ideDobro('D')==0)
                                         {
                                                             y--;
                                                             rez++;
                                                             continue;
                                         }
                                         x--;
                                         continue;
                                         
                               }
                                if(pom==2)
                               {
                                          x++;
                                         rez++;
                                         continue;
                               }
            }
            if(komande[i]=='U')
            {
                               if(pom==0)
                               {
                                         y++;
                                         continue;
                               }
                                if(pom==1)
                               {
                                          if(ideDobro('R')==0)
                                         {
                                                             x++;
                                                             rez++;
                                                             continue;
                                         }
                                           if(ideDobro('L')==0)
                                         {
                                                             x--;
                                                             rez++;
                                                             continue;
                                         }
                                         y++;
                                         continue;
                                       
                               }
                                if(pom==2)
                               {
                                         y--;
                                         rez++;
                                         continue;
                               }
            }
            if(komande[i]=='D')
            {
                               if(pom==0)
                               {
                                         y--;
                                         continue;
                               }
                                if(pom==1)
                               {
                                         if(ideDobro('R')==0)
                                         {
                                                             x++;
                                                             rez++;
                                                             continue;
                                         }
                                           if(ideDobro('L')==0)
                                         {
                                                             x--;
                                                             rez++;
                                                             continue;
                                         }
                                         y--;
                                         continue;
                               }
                                if(pom==2)
                               {
                                          y++;
                                         rez++;
                                         continue;
                               }
            }
            
    }

   
    printf("%d %d",pr,rez);


    return 0;
}
