#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;

const int MAX_N = 10e+3+10;

struct Broj
{
    char c[10];
};

Broj a[MAX_N];
int dp[MAX_N], n, d;

int abs(int a)
{
    return (a<0)?-a:a;
}

int p(Broj a, Broj b)
{
    int br=0, r=0;
    for (int i=0;i<d;i++)
    {
        if (a.c[i]!=b.c[i])
        {
            r=abs(a.c[i]-b.c[i]);
            br++;
        }

        if (br>1) return -1;
    }

    return r;
}

int main()
{
    scanf("%d", &n);

    for (int i=0;i<n;i++)
    {
        scanf("%s", &a[i].c);
    }

    d=strlen(a[0].c);

    for (int i=1;i<n;i++)
    {
        int maks=0;
        for (int j=i-1;j>=0;j--)
        {
            int r=p(a[i], a[j]);
            if (r>0 && dp[j]+r > maks) { maks=dp[j]+r;}
        }

        dp[i]=maks;
    }

    printf("%d", dp[n-1]);
    return 0;
}
