#include <iostream>
#include <stdio.h>

using namespace std;

const int MAX_N=10e+6+10;
const int mod=10e+9+7;

int a[MAX_N];
int n, q;
long long int sol=0;

void modsol()
{
    while (sol>=mod)
    sol-=mod;
}

void sracunaj(int levo, int desno)
{
    sol+=1LL*(levo+1)*(desno+1);
    modsol();
}

void pronadji(int k, int levo, bool p, int poc)
{
    int desno=0;
    int i=poc;

    if (p)
    {
        while (i<n && a[i]!=k)
        {
            if (a[i]<k)
            levo++;

            else
            {
                levo=0;
            }

            i++;
        }
    }

    int kreni=i+1;
    int j=kreni;

    while (j<n && a[j]!=k)
    {
        if (a[j]<k) desno++;
        else if (a[j]==k)
        {
            sracunaj(levo, desno);
            pronadji(k, desno, false, kreni);
        }
        else
        {
            sracunaj(levo, desno);
            pronadji(k, 0, true, j+1);
        }

        j++;
    }
}

int main()
{
    scanf("%d", &n);
    for (int i=0;i<n;i++)
    {
        scanf("%d", &a[i]);
    }
    scanf("%d", &q);
    for (int i=0;i<q;i++)
    {
        int k;
        scanf("%d", &k);
        sol=0;
        pronadji(k, 0, true, 0);
        printf("%lld\n", sol);
    }

    return 0;
}
