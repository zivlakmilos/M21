#include <iostream>
#include <stdio.h>
#include <queue>

using namespace std;

const int MAX_N=1005;

bool park[MAX_N][MAX_N];
int rast[MAX_N][MAX_N];
int brzine[MAX_N][MAX_N];
bool mark[MAX_N][MAX_N];
char red[MAX_N];
int dx[]={-1, 1, 0, 0};
int dy[]={0, 0, 1, -1};
int n, m, k;

int minimum(int x, int y, int v2, int r, int c)
{
    int v1=brzine[r][c];
    if (x==0 && v1==0) {brzine[r][c]=v2; return y;}
    long long int s1=1LL*y*v1;
    long long int s2=1LL*x*v2;

    if (s1<s2)
    {
        brzine[r][c]=v2;
        return y;
    }

    return x;
}

void BFS(int x, int y, int v)
{
    queue<pair<int, int> > q;
    q.push(make_pair(x, y));

    while (!q.empty())
    {
        pair<int, int> xt=q.front();
        q.pop();
        mark[xt.first][xt.second]=true;

        int r=xt.first;
        int c=xt.second;

        for (int i=0;i<4;i++)
        {
            int r1=r-dx[i];
            int c1=c-dy[i];
            if (r1>=0 && r1<n && c1>=0 && c1<m && !mark[r1][c1] && !park[r1][c1])
            {
                rast[r1][c1]=minimum(rast[r1][c1], rast[r][c]+1, v, r1, c1);
                q.push(make_pair(r1, c1));
                mark[r1][c1]=true;
            }
        }
    }
}

int main()
{
    scanf("%d%d", &n, &m);
    for (int i=0;i<n;i++)
    {
        scanf("%s", red);
        for (int j=0;j<m;j++)
        {
            if (red[j]==1)  park[i][j]=true;
        }
    }
    scanf("%d", &k);

    for (int i=0;i<k;i++)
    {
        int x, y, v;
        scanf("%d%d%d", &x, &y, &v);
        x--; y--;
        BFS(x, y, v);
    }

    int mr=0, mc=0, maks=rast[0][0];

    for (int i=0;i<n;i++)
    {
        for (int j=0;j<m;j++)
        {
            if (rast[i][j]>maks){ maks=rast[i][j]; mr=i; mc=j; }
        }
    }

    printf("%d %d", mr+1, mc+1);

    return 0;
}
