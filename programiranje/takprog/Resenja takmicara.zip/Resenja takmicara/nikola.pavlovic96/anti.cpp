#include <cstdio>
#include <queue>
#include <algorithm>
using namespace std;

struct polje
{
    int minl;
    bool chk;
    int idt;
    polje()
    {
        chk=true;
        idt=-1;
    }
};
struct trkac
{
    int x,y,v;
};
queue<int> xs, ys, tids;
trkac trkaci[1001];
int n,m;
int n_abs(int x){if(x<0) return -x; else return x;}
int dist(int x, int y, int tid)
{
    int d = n_abs(x-trkaci[tid].x)+n_abs(y-trkaci[tid].y);
    int v=trkaci[tid].v;
    int nk=d/v;
    if(d%v!=0) nk++;
    return nk;
}
bool betterDistance(int x, int y, int tid1, int tid2)
{
    if(tid2==-1) return true;
    int d1=dist(x,y,tid1);
    int d2=dist(x,y,tid2);
    if(d1!=d2) return d1<d2;
    return trkaci[tid1].v>trkaci[tid2].v;
}
polje p[1001][1001];
void nextPolje(int x, int y, int tid)
{
    if(x>0 && x<=n && y>0 && y<=m && (p[x][y].chk || dist(x,y, tid)<p[x][y].minl))
    {
        p[x][y].chk=false;
        p[x][y].minl=dist(x,y,tid);
        p[x][y].idt=tid;
        xs.push(x);
        ys.push(y);
        tids.push(tid);
    }
}
void tryPolje(int x, int y, int tid)
{
    nextPolje(x+1, y, tid);
    nextPolje(x-1, y, tid);
    nextPolje(x, y+1, tid);
    nextPolje(x, y-1, tid);
}
bool tcmp(trkac t1, trkac t2){return t1.v>t2.v;}
int main()
{
    scanf("%d", &n);
    scanf("%d", &m);
    int k;
    scanf("%d", &k);
    for(int i=1;i<=k;i++)
    {
        scanf("%d", &trkaci[i].x);
        scanf("%d", &trkaci[i].y);
        scanf("%d", &trkaci[i].v);
    }
    sort(&trkaci[1], &trkaci[k+1], tcmp);
    for(int i=1;i<=k;i++)
    {
        nextPolje(trkaci[i].x, trkaci[i].y, i);
        while(!xs.empty())
        {
            int cx=xs.front();
            int cy=ys.front();
            int ct=tids.front();
            xs.pop();
            ys.pop();
            tids.pop();
            tryPolje(cx, cy, ct);
        }
    }
    int lm=0;
    int bx, by;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            if(p[i][j].minl>lm)
            {
                lm=p[i][j].minl;
                bx=i;
                by=j;
            }
        }
    }
    printf("%d %d", bx, by);
    return 0;
}
