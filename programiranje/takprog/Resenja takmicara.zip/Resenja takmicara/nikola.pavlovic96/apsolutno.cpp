#include <cstdio>
#include <algorithm>
using namespace std;

long long a[100001], b[100001];
long long sumB[100001];
long long n_abs(long long x){if(x<0) return -x; else return x;}
int main()
{
    long long n;
    scanf("%lld", &n);
    for(long long i=1;i<=n;i++)
    {
        scanf("%lld", &a[i]);
    }
    for(long long i=1;i<=n;i++)
    {
        scanf("%lld", &b[i]);
    }
    sort(&a[1], &a[n+1]);
    sort(&b[1], &b[n+1]);
    sumB[0]=0;
    for(long long i=1;i<=n;i++)
    {
        sumB[i]=sumB[i-1]+b[i];
    }
    long long lp=0, rp=0;
    long long z=0;
    for(long long i=1;i<=n;i++)
    {
        while(b[lp]<a[i] && lp<n) lp++;
        if(b[lp]>=a[i]) lp--;
        while(b[rp]<=a[i] && rp<n) rp++;
        long long sumManjih=sumB[lp];
        long long sumVecih;
        if(rp<n) sumVecih=sumB[n]-sumB[rp-1];
        else
        {
            if(b[rp]<a[i])
            {
                sumVecih=0;
                rp=n+1;
            }
            else
            {
                sumVecih=sumB[n]-sumB[n-1];
                rp=n;
            }
        }
        z+=((a[i]*lp)-sumManjih)+(sumVecih - a[i]*(n-rp+1));
    }
    printf("%lld", z);
    return 0;
}
