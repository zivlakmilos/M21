#include <cstdio>

using namespace std;

int n,r,s;
char q[500009];
int nl=0, nr=0, nu=0, nd=0;
int n_abs(int x){if(x<0) return -x; else return x;}

int getOffset(int off1, int off2, int ad1, int ad2, int ads1, int ads2)
{
    int nz=ad1;
    if(ad2>nz) nz=ad2;
    if(off1==off2 && nz>=off1) return nz;
    if(off1%2!=off2%2) return -1;
    if(off1>=nz) off1-=nz;
    else
    {
        nz=off1;
        off1=0;
    }
    if(off2>=nz) off2-=nz;
    else
    {
        off1+=nz;
        nz=off2;
        off2=0;
        off1-=nz;
    }
    if(off1%2!=0)
    {
        off1++;
        off2++;
        nz--;
    }
    if(ad2>ad1)ad2-=nz;
    else ad1-=nz;
    bool didBorrow;
    if(ad1*2<off1)
    {
        if(ad1*2+ads2*2<off1) return -1;
        off2+=(off1-ad1*2);
        didBorrow=true;
    }
    if(ad2*2<off2)
    {
        if(didBorrow || ad2*2+ads1*2<off2) return -1;
        off1+=(off2-ad2*2);
    }
    return off1/2+off2/2+nz;
}
int minOffset(int x, int y, int k)
{
    if(x==r && y==s) return 0;
    int dx=n_abs(x-r);
    int dy=n_abs(y-s);
    if(x>=r && y>=s)
    {
        return getOffset(dx, dy, nr, nu, nl, nd);
    }
    else if(x>=r && y<s)
    {
        return getOffset(dx, dy, nr, nd, nl, nu);
    }
    else if(x<r && y<s)
    {
        return getOffset(dx, dy, nl, nd, nr, nu);
    }
    else
    {
        return getOffset(dx, dy, nl, nu, nr, nd);
    }
}
int main()
{
    scanf("%d", &n);
    scanf("%d", &r);
    scanf("%d", &s);
    scanf("%s", q);
    int x=0, y=0;
    int minOff=1000000;
    for(int i=1;i<=n;i++)
    {
        char k=q[i-1];
        if(k=='L') {x--; nl++;}
        if(k=='R') {x++; nr++;}
        if(k=='U') {y++; nu++;}
        if(k=='D') {y--; nd++;}
        int r=minOffset(x,y,i);
        if(r!=-1 && r<minOff) minOff=r;
    }
    printf("%d %d", minOff, minOffset(x,y,n));
    return 0;
}
