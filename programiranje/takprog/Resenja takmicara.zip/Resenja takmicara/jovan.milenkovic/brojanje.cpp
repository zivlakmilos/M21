#include <cstdio>
#include <algorithm>
using namespace std;
long long k;
struct A{
long long broj,lv,dv,dos;
} a[1000003],b[1000003];

struct STEK{
long long broj,index;
} stek[1000003];


bool cmp(struct A x, struct A y)
{
    return x.broj<y.broj;
}

long long bs(long long x)
{
    long long l,d,s;
    l=0;
    d=k-1;
    while(l<=d)
    {
        s=(l+d)/2;
        if(b[s].broj==x)
            return b[s].dos;
        else if(b[s].broj<x)
            l=s+1;
        else
            d=s-1;
    }
    return 0;
}
int main()
{
    long long i,n,q,steklen,j,x;
    scanf("%lld",&n);
    for(i=0;i<n;i++)
        scanf("%lld",&a[i].broj);

    a[0].lv=1;
    stek[0].broj=a[0].broj;
    stek[0].index=0;
    steklen=1;

    for(i=1;i<n;i++)
    {
        for(j=steklen-1;j>=0;j--)//idem kroz stek unazad i racunam lv
        {
            if(a[i].broj>=stek[j].broj)//ako je a vece od broja u steku, skidam broj sa steka
                steklen--;
            else
            {
                a[i].lv=i-stek[j].index;
                stek[steklen].broj=a[i].broj;
                stek[steklen].index=i;
                steklen++;
                break;
            }
        }
        if(steklen==0)
        {
            a[i].lv=i+1;
            stek[0].broj=a[i].broj;
            stek[0].index=i;
            steklen=1;
        }
    }


    for(i=0;i<n;i++)
       stek[i].index=stek[i].broj=0;


    a[n-1].dv=1;
    stek[0].broj=a[n-1].broj;
    stek[0].index=n-1;
    steklen=1;
    for(i=n-2;i>=0;i--)
    {
        for(j=steklen-1;j>=0;j--)//idem kroz stek unazad i racunam dv
        {
            if(a[i].broj>stek[j].broj)//ako je a vece od broja u steku, skidam broj sa steka
                steklen--;
            else
            {
                a[i].dv=stek[j].index-i;
                stek[steklen].broj=a[i].broj;
                stek[steklen].index=i;
                steklen++;
                break;
            }
        }
        if(steklen==0)
        {
            a[i].dv=n-i;
            stek[0].broj=a[i].broj;
            stek[0].index=i;
            steklen=1;
        }
    }

    for(i=0;i<n;i++)
        a[i].dos=a[i].lv*a[i].dv;
    sort(a,a+n,cmp);

    b[0].broj=a[0].broj;
    b[0].dos=a[0].dos;
    k=1;
    for(i=1;i<n;i++)
    {
        if(a[i].broj==a[i-1].broj)
            b[k-1].dos+=a[i].dos;
        else
        {
            b[k].broj=a[i].broj;
            b[k].dos=a[i].dos;
            k++;
        }
    }

    scanf("%lld",&q);
    for(i=0;i<q;i++)
    {
        scanf("%lld",&x);
        printf("%lld\n",bs(x)%1000000007);
    }
    return 0;
}
