#include <cstdio>
#include <cstdlib>
char s[10000];
int main()
{
    int i,j,k,n,m,x,y,v,max,d,q,pom,solx,soly;
    scanf("%d %d\n",&n,&m);
    for(i=0;i<n;i++)
        scanf("%s",s);

    scanf("%d",&q);
    max=0;
    for(i=0;i<q;i++)
    {
        scanf("%d %d %d",&x,&y,&k);
        for(j=1;j<=n;j++)
            for(k=1;k<=m;k++)
            {
                d=abs(x-k)+abs(y-j);
                pom=d/v;
                if(d%v!=0)
                    pom++;
                if(pom>max)
                {
                    max=pom;
                    solx=k;
                    soly=j;
                }
            }
    }
    printf("%d %d",solx,soly);
    return 0;
}
