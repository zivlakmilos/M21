#include <cstdio>
#include <cstdlib>
char a[100000][10];
int sol[10000000];//resenja za sve moguce brojeve
bool mark[10000000];
int main()
{
    int i,j,k,n,x,max,len,tmp,pom;
    scanf("%d\n",&n);
    for(i=0;i<n;i++)
    {
        scanf("%s",a[i]);
        x=len=j=0;
        while(a[i][j]!='\0')
        {
            len++;
            x*=10;
            x+=a[i][j]-48;
            j++;
        }
        mark[x]=true;
        max=0;
        tmp=1;

        for(k=0;k<len;k++)//idem po stepenu
        {
            for(j=0;j<10;j++)//idem po ciframa
            {
                if(j==0 && k==len-1)
                    continue;
                pom=x+(j-(a[i][len-1-k]-48))*tmp;//jedan od 40 brojeva
                if(mark[pom]==true)
                    if(sol[pom]+abs(pom-x)/tmp>max)
                        max=sol[pom]+abs(pom-x)/tmp;
            }
            tmp*=10;
        }
        sol[x]=max;
    }
    max=0;
    for(i=0;i<n;i++)
    {
        x=j=0;
        while(a[i][j]!='\0')
        {
            x*=10;
            x+=a[i][j]-48;
            j++;
        }
        if(sol[x]>max && mark[x]==true)
            max=sol[x];
    }
    printf("%d",max);
    return 0;
}
