#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;
struct tacka
{
       int x, y;
};
char Q[500005];
tacka put[500005];
int tc(tacka a, tacka b)
{
    return abs(a.x-b.x)+abs(a.y-b.y);
}
int main(int argc, char *argv[])
{
    int n, izmena=0;
    tacka des;
    scanf("%d%d%d", &n, &des.x, &des.y);
    scanf("%s", &Q);
    put[0].x=0;
    put[0].y=0;
    int min_tc=tc(des, put[0]), min_t=0;
    for(int i=1; i<=n; ++i)
    {
            put[i]=put[i-1];
            if(Q[i-1]=='U')
            {
                           ++put[i].y;
                           
            }
            if(Q[i-1]=='D')
            {
                           --put[i].y;
            }
            if(Q[i-1]=='L')
            {
                           --put[i].x;
            }
            if(Q[i-1]=='R')
            {
                           ++put[i].x;
            }
            if(tc(put[i], des)<=min_tc)
            {
                          min_tc=tc(put[i], des);
                          min_t=i;
            }
    }
    int d_x=des.x-put[min_t].x, d_y=des.y-put[min_t].y;
    //minimalizovanje razlike...
    if(d_x>0&&d_y>0)
    {
                     for(int i=0; i<min_t&&d_x>1; ++i)
                     {
                             if(Q[i]=='L')
                             {
                                      ++izmena;
                                      d_x-=2;   
                             }
                     }
                     for(int i=0; i<min_t&&d_y>1; ++i)
                     {
                             if(Q[i]=='D')
                             {
                                      ++izmena;
                                      d_y-=2;   
                             }
                     }
                     izmena+=abs(d_x)+abs(d_y);
    }
    if(d_x<0&&d_y>0)
    {
                     for(int i=0; i<min_t&&d_x<-1; ++i)
                     {
                             if(Q[i]=='R')
                             {
                                      ++izmena;
                                      d_x+=2;   
                             }
                     }
                     for(int i=0; i<min_t&&d_y>1; ++i)
                     {
                             if(Q[i]=='D')
                             {
                                      ++izmena;
                                      d_y-=2;   
                             }
                     }
                     izmena+=abs(d_x)+d_y;//ovo dobro proveri-naravno da nije dobro
    }
    if(d_x<0&&d_y<0)
    {
                     for(int i=0; i<min_t&&d_x<-1; ++i)
                     {
                             if(Q[i]=='R')
                             {
                                      ++izmena;
                                      d_x+=2;   
                             }
                     }
                     for(int i=0; i<min_t&&d_y<-1; ++i)
                     {
                             if(Q[i]=='U')
                             {
                                      ++izmena;
                                      d_y+=2;   
                             }
                     }
                     izmena+=abs(d_x)+abs(d_y);//ovo dobro proveri
    }
    if(d_x>0&&d_y<0)
    {
                     for(int i=0; i<min_t&&d_x>1; ++i)
                     {
                             if(Q[i]=='L')
                             {
                                      ++izmena;
                                      d_x-=2;   
                             }
                     }
                     for(int i=0; i<min_t&&d_y<-1; ++i)
                     {
                             if(Q[i]=='U')
                             {
                                      ++izmena;
                                      d_y+=2;   
                             }
                     }
                     izmena+=abs(d_x)+abs(d_y);//ovo dobro proveri
    }

    printf("%d", izmena);
    return EXIT_SUCCESS;
}
