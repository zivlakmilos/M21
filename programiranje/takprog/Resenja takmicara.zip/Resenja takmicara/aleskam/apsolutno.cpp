#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <algorithm>
using namespace std;
int a[100005], b[100005], c[200005], n;
bool ao[200005];
void spoji()
{
     int il=0, id=0;
     while(il<n&&id<n)
     {
                      if(a[il]<b[id])
                      {
                                     c[il+id]=a[il];
                                     ao[il+id]=true;
                                     ++il;
                      }
                      else
                      {
                          c[il+id]=b[id];
                          ao[il+id]=false;
                          ++id;
                      }
     }
     while(il<n)
     {
                c[il+id]=a[il];
                ao[il+id]=true;
                ++il;        
     }
     while(id<n)
     {
     c[il+id]=b[id];
     ao[il+id]=false;
     ++id;
     }
     return;
}
int main(int argc, char *argv[])
{
    
    scanf("%d", &n);
    for(int i=0; i<n; ++i)
    scanf("%d", &a[i]);
    for(int i=0; i<n; ++i)
    scanf("%d", &b[i]);
    long long int Sp=0, Sn=0, Bp=0,Bn=0, Sr=0;
    sort(a, a+n);
    sort(b, b+n); 
    spoji();
    for(int i=0; i<n; ++i)
    Sp+=b[i];
    Bp=n;
    for(int i=0; i<2*n; ++i)
    {
            if(ao[i])
            {
                     Sr+=Sp-Bp*c[i]+Bn*c[i]-Sn;
            }
            else
            {
                Sp-=c[i];
                Sn+=c[i];
                --Bp;
                ++Bn;
            }
            
    }
    printf("%lld", Sr);
    return EXIT_SUCCESS;
}
