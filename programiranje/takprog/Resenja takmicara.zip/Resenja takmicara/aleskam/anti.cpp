#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <queue>
using namespace std;
struct tragac
{
       int v, x, y;
};
int n, m, k, matrica[1005][1005];
bool park[1005][1005];
tragac tragaci[1005];
queue<tragac> red;
int tc(tragac a, tragac b)
{
    return abs(a.x-b.x)+abs(a.y-b.y);
}
int inside(tragac x)
{
    if(x.x>0&&x.x<m-1&&x.y>0&&x.y<n-1)
    {
         return 0;
    }
    else if(x.x==0&&x.y>0&&x.y<n-1)
    {
         return 1;
    }
    else if(x.x==m-1&&x.y<n-1&&x.y>0)
    {
         return 2;
    }
    else if(x.y==0&&x.x<m-1&&x.x>0)
    {
         return 3;
    }
    else if(x.y==n-1&&x.x<m-1&&x.x>0)
    {
         return 4;
    }
    else if(x.x==0&&x.y==0)
    {
         return 5;
    }
    else if(x.x==m-1&&x.y==0)
    {
         return 6;
    }
    else if(x.x==0&&x.y==n-1)
    {
         return 7;
    }
    return 8;
    
}
int d(tragac a, tragac b)
{
    if(tc(a, b)%b.v==0)
    {
             return tc(a, b)/b.v;
    }
    return tc(a, b)/b.v+1;
}
tragac possible(int x)
{
     for(int i=0; i<n; ++i)
     for(int j=0; j< m; ++j)
     park[j][i]=false;
     for(int i=0; i<k; ++i)
     {
             red.push(tragaci[i]);
             park[tragaci[i].x][tragaci[i].y]==1;
             while(!red.empty())
             {
                      tragac tmp=red.front();
                      red.pop();
                      int slucaj=inside(tmp);
                      if(slucaj==0)
                      {
                                   if(!park[tmp.x+1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            ++t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x-1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            --t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y+1])
                                   {
                                                            tragac t=tmp;
                                                            ++t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y-1])
                                   {
                                                            tragac t=tmp;
                                                            --t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }           
                      }
                      if(slucaj==1)
                      {
                                 if(!park[tmp.x+1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            ++t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y+1])
                                   {
                                                            tragac t=tmp;
                                                            ++t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y-1])
                                   {
                                                            tragac t=tmp;
                                                            --t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }  
                      }
                      if(slucaj==2)
                      {
                                   if(!park[tmp.x-1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            ++t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y+1])
                                   {
                                                            tragac t=tmp;
                                                            ++t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y-1])
                                   {
                                                            tragac t=tmp;
                                                            --t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }  
                      }
                      if(slucaj==3)
                      {
                                   if(!park[tmp.x+1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            ++t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x-1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            --t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y+1])
                                   {
                                                            tragac t=tmp;
                                                            ++t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   
                      }
                      if(slucaj==4)
                      {
                                   if(!park[tmp.x+1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            ++t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x-1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            --t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   
                                   if(!park[tmp.x][tmp.y-1])
                                   {
                                                            tragac t=tmp;
                                                            --t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }  
                      }
                      if(slucaj==5)
                      {
                                   if(!park[tmp.x+1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            ++t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y+1])
                                   {
                                                            tragac t=tmp;
                                                            ++t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
 
                      }
                      if(slucaj==6)
                      {
                                   if(!park[tmp.x-1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            --t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y+1])
                                   {
                                                            tragac t=tmp;
                                                            ++t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                      }
                      if(slucaj==7)
                      {
                                   if(!park[tmp.x+1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            ++t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y-1])
                                   {
                                                            tragac t=tmp;
                                                            --t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   } 
                      }
                      if(slucaj==8)
                      {
                                   
                                   if(!park[tmp.x-1][tmp.y])
                                   {
                                                            tragac t=tmp;
                                                            --t.x;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   }
                                   if(!park[tmp.x][tmp.y-1])
                                   {
                                                            tragac t=tmp;
                                                            --t.y;
                                                            if(d(t,tragaci[i])<x)
                                                            red.push(t);
                                   } 
                      }
             }
     }
     
     for(int i=0; i<m; ++i)
     for(int j=0; j<n; ++j)
     if(!park[i][j])
     {
                    tragac tmp;
                    tmp.x=i;
                    tmp.y=j;
                    tmp.v=1;
                    return tmp;
     }
     tragac tmp;
     tmp.v=0;
     return tmp;
}
int main(int argc, char *argv[])
{
    
    scanf("%d%d%d", &n, &m, &k);
    
    for(int i=0; i<k; ++i)
    {
            scanf("%d%d%d", &tragaci[i].y, &tragaci[i].x, &tragaci[i].v);
            --tragaci[i].x;
            --tragaci[i].y;
    }
    /*long long int gornja=m*n, donja=0;
    tragac primer;
    while(true)
    {
               printf("%lld%lld", gornja, donja);
               if(gornja==1+donja)
               break;
               int mid=(gornja+donja)/2;
               tragac dj=possible(mid);
               if(dj.v==0)
               {
                                     gornja=mid;
               }
               else
               {
                                      donja=mid;
                                      primer.x=dj.x;
                                      primer.y=dj.y;
               }
    }
    printf("%d%d", primer.y+1, primer.x+1);*/
    int min=1000000000;
    tragac primer;
    for(int i=0; i<n; ++i)
    for(int j=0; j<m; ++j)
    {
            int max=0;
            tragac s;
            s.x=j;
            s.y=i;
            for(int l=0; l<k; ++l)
         {
            if(d(s, tragaci[i])>max)
            max=d(s, tragaci[i]);
         }
         if(max<min)
         {min=max;
         primer=s;
         }
    }
    printf("%d%d", primer.y+1, primer.x+1);
    return EXIT_SUCCESS;
}
