#include <cstdlib>
#include <cstdio>
#include <memory.h>

const int MaxN = 1000100;
const int MaxK = 1000010;

int n, k, a[MaxN], r[MaxN], sorted[MaxN], c[MaxK];

int main() {

	FILE* inFile = fopen("magacin.in", "r");
	FILE* outFile = fopen("magacin.out", "w");

	fscanf(inFile, "%d%d", &n, &k);
	for (int i = 1; i <= n; i++)
		fscanf(inFile, "%d", &a[i]);

	long long sum = 0;
	for (int i = 1; i <= n; i++) {
		r[i] = a[i] % k;
		sum += a[i] / k;
	}
	
	// sortiramo niz ostataka counting sortom
	memset(c, 0, sizeof(c));
	for (int i = 1; i <= n; i++)
		c[ r[i] ]++;
	for (int i = 1; i < k; i++)
		c[i] = c[i] + c[i - 1];
	for (int i = n; i >= 1; i--) {
		sorted[ c[ r[i] ] ] = r[i];
		c[ r[i] ]--;
	}

	int position = sum % n;

	if (position == 0)
		fprintf(outFile, "%d\n", sorted[n] - sorted[1]);
	else
		fprintf(outFile, "%d\n", sorted[position] + k - sorted[position + 1]);

	fclose(inFile);
	fclose(outFile);

	return 0;
}
