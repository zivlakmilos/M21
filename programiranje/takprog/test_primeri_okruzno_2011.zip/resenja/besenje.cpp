/*
  Author: Andreja Ilic, PMF Nis
  e-mail: andrejko.ilic@gmail.com
  Complexity: O(n * 30)
*/
#include<stdio.h>
#include<string.h>
#define MAX_LEN 35

int n, m, sol;
char state [MAX_LEN], word [MAX_LEN], pom;
bool guess [26];

	int main()
	{
		FILE *in = fopen ("besenje.in", "r");
		FILE *out = fopen ("besenje.out", "w");

		sol = 0;
		for (int i = 0; i < 26; i++)
			guess [i] = false;

		// Unos stanja i upitanih slova
		fscanf (in, "%d %d\n", &n, &m);
		for (int i = 0; i < m; i++)
		{
			fscanf (in, "%c", &pom);
			guess [pom - 'A'] = true;
			fscanf (in, "%c", &pom);
		}

		fscanf (in, "%s", &state);
		int stateLen = strlen(state);

		// Ispitivanje svake reci pojedinacno
		for (int i = 0; i < n; i++)
		{
			fscanf (in, "%s", &word);
			int wordLen = strlen(word);
			
			// Jednakost duzina
			if (stateLen != wordLen)
				continue;

			// Poklapanje sa stanjem i upitanim slovima
			bool ok = true;
			for (int i = 0; i < stateLen; i++)
			{
				// Poklapanje sa slovima iz stanja
				if ((state [i] != '-') && (state [i] != word [i]))
				{
					ok = false;
					break;
				}

				// Ukoliko je nepoznato slovo u stanju, nije smelo biti upitano
				if ((state [i] == '-') && (guess [word [i] - 'A']))
				{
					ok = false;
					break;
				}
			}

			if (ok)
				sol++;
		}

		fprintf (out, "%d\n", sol);

		fclose(out);
		fclose(in);

		return 0;
	}