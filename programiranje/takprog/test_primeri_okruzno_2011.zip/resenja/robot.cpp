#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string>

using namespace std;

const int MAX_K = 8;

const int XS[] = {0, 1, 0, -1};
const int YS[] = {1, 0, -1, 0};

int k, n;
string blok[MAX_K];


int dx[MAX_K];
int dy[MAX_K];
int ds[MAX_K];

int perm[MAX_K];
bool ubacen[MAX_K];


void izracunajPomeraje()
{
    for(int i = 0; i < k; i++)
    {
        int x = 0;
        int y = 0;
        int s = 0;
        
        for(int j = 0; j < n; j++)
            if(blok[i][j] == 'P')
            {
                x += XS[s];
                y += YS[s];
                
            }
            
            else if(blok[i][j] == 'L')
            {
                s += 3;
                if(s >= 4)
                    s -= 4;
            }
            else
            {
                s += 1;
                if(s >= 4)
                    s -= 4;
            }
            
        dx[i] = x;
        dy[i] = y;
        ds[i] = s;
        
    }
    
    
    
    
    
}

bool proveri()
{
    int s = 0;
    int x = 0;
    int y = 0;
    for(int i = 0; i < k; i++)
    {
        int tx = dx[perm[i]];
        int ty = dy[perm[i]];
        for(int j = 0; j < s; j++)
        {
            int t = tx;
            tx = ty;
            ty = -1 * t;
        }
            
        x += tx;
        y += ty;
        s += ds[perm[i]];
        if(s > 3)
            s -= 4;
    }
    return (x == 0 && y == 0);  
 
    
}

int permutacije(int t)
{
    
   if(t == k)
        if(proveri())
            return 1;
        else return 0;

    int broj = 0;
    for(int i = 0; i < k; i++)
        if(!ubacen[i])
        {
            perm[t] = i;
            ubacen[i] = true;
            broj += permutacije(t + 1);
            ubacen[i] = false;
        }
    return broj;
}


int main()
{
    
    FILE *fin = fopen("robot.in", "r");
    fscanf(fin, "%d %d", &k, &n);
    for(int i = 0; i < k; i++)
    {
        char c = getc(fin);
        while(c != 'P' && c != 'L' && c != 'D')
            c = getc(fin);
            
        blok[i] = "";
        while(c == 'P' || c == 'L' || c == 'D')
        {
            blok[i] += c;
            c = getc(fin);
        }    
        
    }
    fclose(fin);
    
    

    izracunajPomeraje();
    for(int i = 0; i < k; i++)
        ubacen[i] = false;
    int r = permutacije(0);
    
    
    
    FILE *fout = fopen("robot.out", "w");
    fprintf(fout, "%d\n", r);
    fclose(fout);
    
    
    
}
