#include <stdio.h>
#include <stdlib.h>

using namespace std;

const int maxN = 100;

int n, m, k, res;
int tabla[maxN][maxN];
int ti, tj, s, l;
int di[8] = {-1, -1, 0, 1, 1, 1, 0, -1};
int dj[8] = {0, 1, 1, 1, 0, -1, -1, -1};

int main() {
    freopen("osm.in", "r", stdin);
    freopen("osm.out", "w", stdout);
  
    scanf("%d%d", &n, &m);
    for (int i = 0; i < n; i++) 
        for (int j = 0; j < m; j++) 
            scanf("%d", &(tabla[i][j]));
    
    res = n * m;
            
    scanf("%d", &k);
    for (int t = 0; t < k; t++) {
        scanf("%d%d%d%d", &ti, &tj, &s, &l);
        s--; ti--; tj--;
        for (int tl = 0; tl < l; tl++) {
            if (tabla[ti][tj] >= 0) {
               tabla[ti][tj] = -1;
               res--;                
            }
            ti += di[s];
            tj += dj[s];    
        }
    }        
        
    printf("%d\n", res);
    for (int i = 0; i < n; i++) 
        for (int j = 0; j < m; j++) 
            if (tabla[i][j] >= 0) 
               printf("%d\n", tabla[i][j]);

    return 0;   
}
