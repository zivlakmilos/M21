#include <stdlib.h>
#include <stdio.h>
#include <string.h>

const int test_value = 5;

int main() {

	FILE* out = fopen("mastilo.out", "r");
	FILE* sol = fopen("mastilo.sol", "r");
	FILE* score = fopen("score.tmp", "w");
	
	char s1[1010], s2[1010];
	int a, b;
	bool ok = true;

	while (! feof(sol) && ok) {
		if (fscanf (sol, "%s", s1) > 0) {
			if (! feof(out)) {
				fscanf (out, "%s", s2);
				ok = (strcmp(s1, s2) == 0);
			}
			else 
				ok = false;
		}
	}

	fprintf (score, "%d\n", (ok ? test_value : 0));

	fclose(out);
	fclose(sol);
	fclose(score);

	return 0;
}
