#include <stdlib.h>
#include <stdio.h>

const int test_value = 10;

int main() {
	FILE* out = fopen("sumhem.out", "r");
	FILE* sol = fopen("sumhem.sol", "r");
	FILE* score = fopen("score.tmp", "w");
	
	long long a, b;
	bool ok = true;

    fscanf (sol, "%lld", &a);
    if (! feof(out)) {
		fscanf (out, "%lld", &b);
		ok = (a == b);
	}
	else 
		ok = false;
	
	fprintf (score, "%d\n", (ok ? test_value : 0));

	fclose(out);
	fclose(sol);
	fclose(score);

	return 0;
}
