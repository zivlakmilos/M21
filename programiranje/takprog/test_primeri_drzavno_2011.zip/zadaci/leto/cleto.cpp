#include <stdlib.h>
#include <stdio.h>

const int test_value = 5;

int main() {
	FILE* out = fopen("leto.out", "r");
	FILE* sol = fopen("leto.sol", "r");
	FILE* score = fopen("score.tmp", "w");
	
	int a, b;
	bool ok = true;

    fscanf (sol, "%d", &a);
    if (! feof(out)) {
		fscanf (out, "%d", &b);
		ok = (a == b);
	}
	else 
		ok = false;
	
	fprintf (score, "%d\n", (ok ? test_value : 0));

	fclose(out);
	fclose(sol);
	fclose(score);

	return 0;
}
