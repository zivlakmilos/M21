#include <stdlib.h>
#include <stdio.h>

const int test_value = 10;

int main() {

	FILE* out = fopen("racuni.out", "r");
	FILE* sol = fopen("racuni.sol", "r");
	FILE* score = fopen("score.tmp", "w");
	
	long long a, b;
	bool ok = true;

	while (! feof(sol) && ok) {
		if (fscanf (sol, "%lld", &a) > 0) {
		if (! feof(out)) {
			fscanf (out, "%lld", &b);
			ok = (a == b);
		}
		else 
			ok = false;
	}}

	fprintf (score, "%d\n", (ok ? test_value : 0));

	fclose(out);
	fclose(sol);
	fclose(score);

	return 0;
}
