#include <iostream>
#include <cstdio>
#include <fstream>
#include <vector>
#include <cmath>
#include <time.h>
#define ffor(_a,_f,_t) for(int _a=(_f),__t=(_t);_a<__t;_a++)
#define all(_v) (_v).begin() , (_v).end()
#define sz size()
#define pb push_back
#define SET(__set, val) memset(__set, val, sizeof(__set))
#define FOR(__i, __n) ffor (__i, 0, __n)

using namespace std;

const int MAXN = 30000;
const int MAXK = 30;

struct recipe{
  int id, idx;
  recipe(){
  }
  
  recipe(int _id, int _idx){
    id = _id;
    idx = _idx;
  }
  
  friend bool operator <(const recipe &a, const recipe &b){
    return a.id < b.id;
  }
};

int val[MAXN][MAXK];

recipe recipes[MAXN];

long long sum[MAXN][MAXK];

int main(){
  char filein[32] = "racuni.in";
  char fileout[32] = "racuni.out";
  FILE *fin;
  FILE *fout;
  
  fin = fopen(filein, "r");
  fout = fopen(fileout, "w");
    
  int n, k, id;
  fscanf(fin, "%d %d", &n, &k);
  FOR (i, n){
    fscanf(fin, "%d", &id);
    recipes[i] = recipe(id, i);
    FOR (j, k)
      fscanf(fin, "%d", &val[i][j]);
  }
  
  sort(recipes, recipes + n);
  int idx = 0, j, cntIds = 0;
  while (idx < n){
    FOR (i, k)
      sum[cntIds][i] = 0LL;
    j = idx;
    while (j < n && recipes[idx].id == recipes[j].id){
      FOR (i, k)
        sum[cntIds][i] += val[recipes[j].idx][i];
      j++;
    }
    idx = j;
    cntIds++;
  }
  
  long long ret[k];
  ret[0] = 1LL << 60LL;
  FOR (i, cntIds){
    bool found = false;
    FOR (j, k)
      if (ret[j] > sum[i][j]){
        found = true;
        break;
      }
      else if (ret[j] < sum[i][j])
        break;
    if (found)
      FOR (j, k)
        ret[j] = sum[i][j];
  }

  FOR (i, k)
    fprintf(fout, "%lld ", ret[i]);

  fprintf(fout, "\n");
  fclose(fin);
  fclose(fout);
  return 0;
}
