#include <stdlib.h>
#include <stdio.h>
#include <algorithm>

using namespace std;

const int maxN = 5000;

typedef struct { int t, index; } Mesto;
bool compareMesta(Mesto const& m1, Mesto const& m2) {
    return (m1.t > m2.t);
}
typedef struct { int b, e, index; } Interval;
bool compareIntervali(Interval const& i1, Interval const& i2) {
    return (i1.e < i2.e) || (i1.e == i2.e && i1.b > i2.b);
}

int n, p;
Mesto mesta[maxN];
Interval intervali[maxN];

int res;

int intervaluDodeljen[maxN], tmp[maxN];

void ucitajPodatke() {
    freopen("leto.in", "r", stdin);
    scanf("%d", &n); 
    for (int i = 0; i < n; i++) {
        scanf("%d", &(mesta[i].t));
        mesta[i].index = i;
    }
    scanf("%d", &p);
    for (int i = 0; i < p; i++) {
        scanf("%d%d", &(intervali[i].b), &(intervali[i].e));    
        intervali[i].b--;
        intervali[i].e--;
    }
}

void sortirajMesta() {
    sort(mesta, mesta + n, compareMesta);
}
void sortirajIntervale() {
    sort(intervali, intervali + p, compareIntervali);
}

bool uIntervalu(int mesto, int interval) {
    return intervali[interval].b <= mesto && mesto <= intervali[interval].e;
}
     
int probajDaDodas(int mesto) {
    int interval = 0;
    while (interval < p) {
        tmp[interval] = intervaluDodeljen[interval];
        if (uIntervalu(mesto, interval))
            if (tmp[interval] == -1) {
               tmp[interval] = mesto;
               return interval;                  
            } 
            else if (tmp[interval] > mesto) {
                int pom = tmp[interval];
                tmp[interval] = mesto;
                mesto = pom;
            }
        interval++;      
    }
    return -1;
}
   
void resi() {
	for (int i = 0; i < p; i++)
		intervaluDodeljen[i] = -1;
    for (int i = 0; i < n; i++) {
		int dodatU = probajDaDodas(mesta[i].index);
		if (dodatU != -1) {
			res += mesta[i].t;
			for (int j = 0; j <= dodatU; j++)
				intervaluDodeljen[j] = tmp[j];
		}
    }
}
     
void sacuvajResenje() {    
    freopen("leto.out", "w", stdout);
    printf("%d\n", res);
}

int main() {
    ucitajPodatke();
    sortirajMesta();
    sortirajIntervale();

    resi();
    sacuvajResenje();

    return 0;
}	 

