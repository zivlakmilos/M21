#include <stdlib.h>
#include <stdio.h>
#include <algorithm>

using namespace std;

const int maxN = 5000;

typedef struct { int t, index; } Mesto;
bool compareMesta(Mesto const& m1, Mesto const& m2) {
    return (m2.t < m1.t);
}
typedef struct { int b, e, index; } Interval;
class compareIntervaliPoKraju {
public:
  bool operator() (Interval const& i1, Interval const& i2) const {
     return (i1.e > i2.e);
  } };

int n, p;
Mesto mesta[maxN];
Interval intervali[maxN];

int lUzeliPozicije;
int uzeliPozicije[maxN];

bool uzeli[maxN];
bool iskoristiliInterval[maxN];

void ucitajPodatke() {
    freopen("leto.in", "r", stdin);
    scanf("%d", &n); 
    for (int i = 0; i < n; i++) {
        scanf("%d", &(mesta[i].t));
        mesta[i].index = i;
    }
    scanf("%d", &p);
    for (int i = 0; i < p; i++) {
        scanf("%d%d", &(intervali[i].b), &(intervali[i].e));    
        intervali[i].b--;
        intervali[i].e--;
    }
}

void sortirajMesta() {
    sort(mesta, mesta + n, compareMesta);
}
     
bool uIntervalu(int tacka, int interval) {
     return intervali[interval].b <= tacka && intervali[interval].e >= tacka;     
}     
     
bool moze() {
	for (int i = 0; i < n; i++)
		uzeli[i] = false;
    for (int i = 0; i <= lUzeliPozicije; i++)
        uzeli[mesta[uzeliPozicije[i]].index] = true;

	for (int i = 0; i < p; i++)
        iskoristiliInterval[i] = false;

	for (int i = 0; i < n; i++) 
        if (uzeli[i]) {
            int t = -1;
		    for (int j = 0; j < p; j++) 
		        if (uIntervalu(i, j) && !iskoristiliInterval[j] && (t == -1 || intervali[t].e > intervali[j].e)) 
                    t = j;
            if (t == -1) return false;
		    iskoristiliInterval[t] = true;
        }

    return true;
}
     
void resi() {
    lUzeliPozicije = 0;
    for (int i = 0; i < n; i++) {
		uzeliPozicije[lUzeliPozicije] = i;
		if (moze())
 	          lUzeliPozicije++;
    }
}

     
int getResenje() {
	int res = 0;
	for (int i = 0; i < lUzeliPozicije; i++)
		res += mesta[uzeliPozicije[i]].t;
	return res;
}
void sacuvajResenje() {
    freopen("leto.out", "w", stdout);
    printf("%d\n", getResenje());
}

int main() {
    ucitajPodatke();
    sortirajMesta();

    resi();
    
    sacuvajResenje();

    return 0;
}	 
