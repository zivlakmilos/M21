#include <cstdlib>
#include <cstdio>

const int MaxN = 1010;
const int inf = 1000000000;

const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};

int n, m, t, color;
char s[MaxN];
bool a[MaxN][MaxN], tmp[MaxN][MaxN];
int Qx[MaxN*MaxN], Qy[MaxN*MaxN];
int d[MaxN][MaxN];

bool inside(int x, int y) {
	return (0 <= x && x < n && 0 <= y && y < m);
}

void initialStep() {
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++) {
			tmp[i][j] = false;
			if (!a[i][j])
				for (int k = 0; k < 4; k++)
					if (inside(i + dx[k], j + dy[k]))
						tmp[i][j] = tmp[i][j] || a[ i + dx[k] ][ j + dy[k] ];
		}
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			a[i][j] = tmp[i][j];
}

void BFS() {
	int first = -1, last = 0;
	int x, y, x1, y1;

	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			if (a[i][j]) {
				Qx[last] = i;  Qy[last] = j;
				d[i][j] = 0;
				last++;
			}
			else d[i][j] = inf;

	while (first < last - 1) {
		first++;
		x = Qx[first]; y = Qy[first];
		for (int i = 0; i < 4; i++) {
			x1 = x + dx[i];  y1 = y + dy[i];
			if (inside(x1, y1) && d[x1][y1] == inf) {
				d[x1][y1] = d[x][y] + 1;
				Qx[last] = x1;  Qy[last] = y1;
				last++;
			}
		}
	}
}

int main() {

	FILE* inFile = fopen("mastilo.in", "r");
	FILE* outFile = fopen("mastilo.out", "w");

	fscanf(inFile, "%d%d%d", &n, &m, &t);
	for (int i = 0; i < n; i++) {
		fscanf(inFile, "%s", s);
		for (int j = 0; j < m; j++)
			a[i][j] = (s[j] == '1');
	}

	initialStep();
	BFS();

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			if (d[i][j] > t - 1)
				color = 0;
			else
				color = (t - d[i][j]) % 2;
			if (color == 0) fprintf(outFile, "0");
			else fprintf(outFile, "1");
		}
		fprintf(outFile, "\n");
	}

	fclose(inFile);
	fclose(outFile);
	return 0;
}