#include <stdlib.h>
#include <stdio.h>
#include <algorithm>

using namespace std;

const int maxN = 5000;

typedef struct { int t, index; } Mesto;
bool compareMesta(Mesto const& m1, Mesto const& m2) {
    return (m2.t < m1.t);
}
typedef struct { int b, e; } Interval;
bool compareIntervali(Interval const& i1, Interval const& i2) {
    return (i1.b < i2.b);
}
class compareIntervaliPoKraju {
public:
  bool operator() (Interval const& i1, Interval const& i2) const {
     return (i1.e > i2.e);
  } };

int n, p;
Mesto mesta[maxN];
Interval intervali[maxN];

int lUzeliPozicije;
int uzeliPozicije[maxN];

bool uzeli[maxN];

void ucitajPodatke() {
    freopen("leto.in", "r", stdin);
    scanf("%d", &n); 
    for (int i = 0; i < n; i++) {
        scanf("%d", &(mesta[i].t));
        mesta[i].index = i;
    }
    scanf("%d", &p);
    for (int i = 0; i < p; i++) {
        scanf("%d%d", &(intervali[i].b), &(intervali[i].e));    
        intervali[i].b--;
        intervali[i].e--;
    }
}

void sortirajMesta() {
    sort(mesta, mesta + n, compareMesta);
}
void sortirajIntervale() {
    sort(intervali, intervali + p, compareIntervali);
}
/*
bool moze() {
    priority_queue< Interval, vector<Interval>, compareIntervaliPoKraju > hip;
	for (int i = 0; i < n; i++)
		uzeli[i] = false;
    for (int i = 0; i <= lUzeliPozicije; i++)
        uzeli[mesta[uzeliPozicije[i]].index] = true;

	int tek = 0;
	for (int i = 0; i < n; i++) {
		while (tek < p && intervali[tek].b <= i) {
			hip.push(intervali[tek]);
			tek++;
		}
		if (uzeli[i]) {
			while (!hip.empty() && hip.top().e < i)
				hip.pop();
			if (hip.empty())
				return false;
			hip.pop();
		}
	}

    return true;
}*/


Interval hip[maxN + 1];
int lhipa;     
     
void pushHip(Interval interval) {
     lhipa++;
     hip[lhipa] = interval;
     int i = lhipa, j;
     Interval pom;
     while (i > 1) {
          j = i >> 1;
          if (hip[j].e > hip[i].e) {
              pom = hip[i];
              hip[i] = hip[j];
              hip[j] = pom;
              i = j;         
          } else i = 0;
     }
}
void popHip() {
     hip[1] = hip[lhipa];
     lhipa--;
     if (lhipa <= 1) return;
     int i = 1, j, tmp = 2;
     Interval pom;
     while (tmp <= lhipa) {
         j = i;
         if (hip[j].e > hip[tmp].e) j = tmp;
         tmp++;
         if (tmp <= lhipa && hip[j].e > hip[tmp].e) j = tmp;
         if (j != i) {
              pom = hip[i];
              hip[i] = hip[j];
              hip[j] = pom;
              i = j;   
         }
         else i = lhipa + 1;     
         tmp = i << 1;  
     }     
}
     
     
bool moze() {
    lhipa = 0;
	for (int i = 0; i < n; i++)
		uzeli[i] = false;
    for (int i = 0; i <= lUzeliPozicije; i++)
        uzeli[mesta[uzeliPozicije[i]].index] = true;

	int tek = 0;
	for (int i = 0; i < n; i++) {
		while (tek < p && intervali[tek].b <= i) {
			pushHip(intervali[tek]);
			tek++;
		}
		if (uzeli[i]) {
			while (lhipa > 0 && hip[1].e < i)
				popHip();
			if (lhipa == 0)
				return false;
			popHip();
		}
	}

    return true;
}
     
void resi() {
    lUzeliPozicije = 0;
    for (int i = 0; i < n; i++) {
		uzeliPozicije[lUzeliPozicije] = i;
		if (moze())
            lUzeliPozicije++;
    }
}

     
int getResenje() {
	int res = 0;
	for (int i = 0; i < lUzeliPozicije; i++)
		res += mesta[uzeliPozicije[i]].t;
	return res;
}
void sacuvajResenje() {
    freopen("leto.out", "w", stdout);
    printf("%d\n", getResenje());
}

int main() {
    ucitajPodatke();
    sortirajMesta();
    sortirajIntervale();

    resi();
    sacuvajResenje();

    return 0;
}	


