#include <iostream>
#include <cstdio>
#include <fstream>
#include <vector>
#include <cmath>
#include <time.h>
#define ffor(_a,_f,_t) for(int _a=(_f),__t=(_t);_a<__t;_a++)
#define all(_v) (_v).begin() , (_v).end()
#define sz size()
#define pb push_back
#define SET(__set, val) memset(__set, val, sizeof(__set))
#define FOR(__i, __n) ffor (__i, 0, __n)

using namespace std;

const int MAXN = 30000;
const int MAXK = 30;

int id[MAXN], val[MAXN][MAXK];
int done[MAXN];

long long sum[MAXN][MAXK];

int main(){
  char filein[32] = "racuni.in";
  char fileout[32] = "racuni.out";
  FILE *fin;
  FILE *fout;
  
  fin = fopen(filein, "r");
  fout = fopen(fileout, "w");
    
  int n, k;
  fscanf(fin, "%d %d", &n, &k);
  FOR (i, n){
    fscanf(fin, "%d", &id[i]);
    FOR (j, k)
      fscanf(fin, "%d", &val[i][j]);
  }

  int cnt = 0;
  SET(done, 0);
  FOR (i, n){
    if (done[i])
      continue;
    FOR (j, k)
      sum[cnt][j] = val[i][j];
    ffor (i1, i + 1, n)
      if (id[i] == id[i1]){
        done[i1] = true;
        FOR (j, k)
          sum[cnt][j] += val[i1][j];
      }
    cnt++;
  }
  
  long long ret[k];
  ret[0] = 1LL << 60LL;
  FOR (i, cnt){
    bool found = false;
    FOR (j, k)
      if (ret[j] > sum[i][j]){
        found = true;
        break;
      }
      else if (ret[j] < sum[i][j])
        break;
    if (found)
      FOR (j, k)
        ret[j] = sum[i][j];
  }

  FOR (i, k)
    fprintf(fout, "%lld ", ret[i]);

  fprintf(fout, "\n");
  fclose(fin);
  fclose(fout);
  return 0;
}
