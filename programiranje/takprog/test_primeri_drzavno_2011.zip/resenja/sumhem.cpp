/*
	Problem: Dat je niz a duzine n <= 100.000 prirodnih brojeva manjih od 2^31. 
	Naci sumu Hemingovih rastojanja svaka dva broja a [i] i a [j], gde je i < j.
	Hemingovo rastojanje za dva broja se definise kao broj bitova na kojima se ti brojevi razlikuju.

	Resenje: Kvadratno resenje u O (32 n^2) donosi 40 poena. 
	Za linearno resenje O (32 n) je potrebno primetiti da svaki bit mozemo posmatrati nezavisno.
	Za i-ti bit, 0 <= i <= 31, neka count predstavlja koliko brojeva imaju 1 na i-toj poziciji.
	Tada na ukupnu sumu dodajemo tacno count * (n - count).
	U resenju koristimo neoznacene brojeve sa 64 bita i idemo do bita najvece tezine.

	Autor: Aleksandar Ilic
*/

#include <stdio.h>
#define MAXN 100001

unsigned int a [MAXN];
int n;
long long sum;

long long check ()
{
	long long sum = 0;	
	for (int i = 0; i < n; i++)
		for (int j = i + 1; j < n; j++)
		{
			unsigned int x = a [i] ^ a [j];
			while (x > 0)
			{
				sum++;
				x = x & (x - 1);
			}
		}
	return sum;
}

int main ()
{
	FILE *in = fopen ("sumhem.in", "r");
	fscanf (in, "%d", &n);
	for (int i = 0; i < n; i++)
		fscanf (in, "%d", &a [i]);
	fclose (in);
	
	int max = a [0];
	for (int i = 0; i < n; i++)
		if (max < a [i])
			max = a [i];
	int max_bit = 1;
	while ((max_bit < 32) && (max > (1 << max_bit)))
		max_bit++;

	sum = 0;
	unsigned int pow = 1;
	for (int i = 0; i < max_bit; i++)
	{
		int count = 0;
		for (int j = 0; j < n; j++)
			if ((a [j] & pow) != 0)
				count++;
		sum = sum + (long long)count * (long long)(n - count);
		pow = pow << 1;
	}
	//printf ("%lld %lld\n", sum, check ());

	FILE *out = fopen ("sumhem.out", "w");
	fprintf (out, "%lld\n", sum);
	fclose (out);
	return 0;
}
