#include <cstdlib>
#include <cstdio>

const int MaxN = 1010;

const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};

int n, m, t, curr, prev;
bool a[MaxN][MaxN][2];
char s[MaxN], color;

bool inside(int x, int y) {
	return (0 <= x && x < n && 0 <= y && y < m);
}


int main() {
	FILE* inFile = fopen("mastilo.in", "r");
	FILE* outFile = fopen("mastilo.out", "w");

	fscanf(inFile, "%d%d%d", &n, &m, &t);
	for (int i = 0; i < n; i++) {
		fscanf(inFile, "%s", s);
		for (int j = 0; j < m; j++) 
			a[i][j][0] = (s[j] == '1');
	}

	curr = 0;
	prev = 1;
	for (int num = 0; num < t; num++) {
		curr = 1 - curr;
		prev = 1 - prev;
		for (int i = 0; i < n; i++)
			for (int j = 0; j < m; j++) {
				a[i][j][curr] = false;
			if (!a[i][j][prev])
				for (int k = 0; k < 4; k++)
					if (inside(i + dx[k], j + dy[k]))
						a[i][j][curr] = a[i][j][curr] || a[ i + dx[k] ][ j + dy[k] ][ prev ];
		}
	}

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			color = (a[i][j][curr] ? '1' : '0');
			fprintf(outFile, "%c", color);
		}
		fprintf(outFile, "\n");
	}

	fclose(inFile);
	fclose(outFile);
	return 0;
}