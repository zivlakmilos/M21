/*
  Autor: Vanja Petrovic Tankovic
*/
#include <cstdio>
#include <algorithm>

#define INF 1000000000000ll
#define MAXN 100001

using namespace std;

int n,k,niz[MAXN];
long long razlika[MAXN],resenje;

int main()
{
  freopen("papirici.in","r",stdin);
  freopen("papirici.out","w",stdout);  
 
  scanf("%d %d",&n,&k);
  for (int i=0; i<n; i++)
    scanf("%d",&niz[i]);
  sort(niz,niz+n);    
  
  if (k==2)
    for (int i=0; i<n; i+=2)
      resenje+=(long long)niz[i+1]-niz[i];
  else    
  {
    razlika[0]=INF;
    razlika[1]=(long long)niz[1]-niz[0];
    razlika[2]=(long long)niz[2]-niz[0];
    for (int i=3; i<n; i++)
      if (razlika[i-2]-niz[i-1]<razlika[i-3]-niz[i-2])
        razlika[i]=(long long)niz[i]-niz[i-1]+razlika[i-2];
      else
        razlika[i]=(long long)niz[i]-niz[i-2]+razlika[i-3];  
    resenje=razlika[n-1]; 
  }
  
  printf("%u",resenje);
  return 0;  
}
