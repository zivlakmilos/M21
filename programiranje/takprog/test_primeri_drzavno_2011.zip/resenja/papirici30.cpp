#include <stdlib.h>
#include <stdio.h>
#include <algorithm>

using namespace std;

const int maxN = 100000;
const int besk = 1 << 30;
bool compare(int const& v1, int const& v2) {
    return (v1 < v2);
}

int n, k;
int v[maxN];

int mind[maxN + 1];

void ucitajPodatke() {
    freopen("papirici.in", "r", stdin);
    scanf("%d%d", &n, &k); 
    for (int i = 0; i < n; i++) 
        scanf("%d", &(v[i]));
    sort(v, v + n, compare);
}

 int minn(int a, int b) {
     if (a < b) return a; else return b;     
}

void resi() {
    mind[0] = 0;
    for (int i = 0; i < n; i++) {
        mind[i + 1] = besk;
        for (int j = 1; j < k && j < i + 1; j++)
            mind[i + 1] = minn(mind[i + 1], mind[i - j] + v[i] - v[i - j]);    
    }
}
     
void sacuvajResenje() {    
    freopen("papirici.out", "w", stdout);
    printf("%d\n", mind[n]);
}

int main() {
    ucitajPodatke();
    resi();
    sacuvajResenje();
    return 0;
}	 

